param($pspath,
$projectName,
$sharedPath,
$otexe,
$otws,
$OTRunName,
$WebApplicationurl,
$OTScenarioCollectionName,
$OTLogsFolder,
$OTServer,
$BusinessUnit,
$userName,
$password,
$dashboardProjectName,
$IsZephyrChangeRequired)

#$pspath ='D:\temp\Test\OdessaTestTemplate.ps1'
#$projectName='AVT'
#$sharedPath='\\lwdelapp-004\Websites\AVT\LessorPortal'
#$otexe='\\lwdeljob-004\e$\DeliveryDevops\GitProjects\AVT\Binaries\Odessa.exe'
#$otws='\\lwdeljob-004\DeliveryDevops\GitProjects\AVT'
#$OTRunName='AVT_Automation'
#$WebApplicationurl='http://avtautomation.del4.odessadev.local'
#$OTScenarioCollectionName='Avtech_E2E'
#$OTLogsFolder='\\lwdeljob-004\DeliveryDevops\GitProjects\OTLogs'
#$OTServer='LWDELJOB-004'
#$BusinessUnit='AvTech'
#$userName='Security.admin'
#$password='a'
if($dashboardProjectName -eq '') {
  throw 'Dashboard project name cannot be empty.' 
}
function ChangeToLocalPath{
  param($path)
  Write-Host $path
  $url = [System.Uri]::new($path)
  $p = $url.AbsolutePath.Remove(0,1).Replace("/","\").Replace("$",":")
  return $p
  #return $path
}

$pspath = $pspath + '\OdessaTestTemplate.ps1'

$otexe = ChangeToLocalPath $otexe

$content = Get-Content -path $pspath -Raw

$content =$content -replace "##PROJECTNAME##", "'$projectName'"
$content =$content -replace "##SHAREDPATH##", "'$sharedPath'"
$content =$content -replace "##OTEXE##", "'$otexe'"
$content =$content -replace "##OTWS##", "'$otws'"
$content =$content -replace "##OTRUNNAME##", "'$OTRunName'"
$content =$content -replace "##APPURL##", "'$WebApplicationurl'"
$content =$content -replace "##COLLECTION##", "'$OTScenarioCollectionName'"
$content =$content -replace "##LOGFOLDER##", "'$OTLogsFolder'"
$content =$content -replace "##OTSERVER##", "'$OTServer'"
$content =$content -replace "##BU##", "'$BusinessUnit'"
$content =$content -replace "##USER##", "'$userName'"
$content =$content -replace "##PASSWORD##", "'$password'"
$content =$content -replace "##DPNAME##", "'$dashboardProjectName'"
$content =$content -replace "##ZephyrChange##", "'$IsZephyrChangeRequired'"


Set-Content -Path $pspath -Value $content