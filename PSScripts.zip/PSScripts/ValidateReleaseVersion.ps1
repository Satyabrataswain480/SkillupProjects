﻿Param (

[parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
[string]$ReleaseVesion,
[parameter (Mandatory=$true, position=1, ParameterSetName='Database')]
[string]$SQLServer,
[parameter (Mandatory=$true, position=2, ParameterSetName='Database')]
[string]$DatabaseName,
[parameter (Mandatory=$true, position=3, ParameterSetName='Database')]
[string]$DB_UserName,
[parameter (Mandatory=$true, position=4, ParameterSetName='Database')]
[string]$DB_Password,
[parameter (Mandatory=$true, position=5, ParameterSetName='Database')]
[string]$IsSQLMI,
[parameter (Mandatory=$false, position=6, ParameterSetName='Database')]
[string]$IsNewReleaseVersion

)

# Get ReleaseviersionNumber or ProjectVersion based on the FRWK Version used by Project teams. 
if($IsSQLMI -eq 1)
{
    if($IsNewReleaseVersion -eq 1)
    {
        $ReleaseVersionNumber = invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query 'select top 1 ProjectVersion from releaseversions order by ID desc'  -QueryTimeout 65500
    }
    else
    {
        $ReleaseVersionNumber = invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query 'select top 1 VersionNumber from releaseversions order by ID desc'  -QueryTimeout 65500
    }
}
else
{
    if($IsNewReleaseVersion -eq 1)
    {
        $ReleaseVersionNumber = invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query 'select top 1 ProjectVersion from releaseversions order by ID desc'  -QueryTimeout 65500
    }
    else
    {
        $ReleaseVersionNumber = invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query 'select top 1 VersionNumber from releaseversions order by ID desc'  -QueryTimeout 65500
    }
}

if($IsNewReleaseVersion -eq 1)
{
    Write-Host "ReleaseVersion (ProjectVersion) In $DatabaseName DB:" $ReleaseVersionNumber.ProjectVersion
}
else
{
    Write-Host "ReleaseVersion In $DatabaseName DB:" $ReleaseVersionNumber.VersionNumber
}

if($IsNewReleaseVersion -eq 1)
{
    if($ReleaseVesion -eq $ReleaseVersionNumber.ProjectVersion)
    {
        Write-Host "The Release Version (ProjectVersion) is matching" 
    }
    else
    {
        throw "The Release Version (ProjectVersion): $ReleaseVesion script was not part of the release content. Please include the same under DML folder."
    }
}
else
{
    if($ReleaseVesion -eq $ReleaseVersionNumber.VersionNumber)
    {
        Write-Host "The Release Version is matching" 
    }
    else
    {
        throw "The Release Version: $ReleaseVesion script was not part of the release content. Please include the same under DML folder."
    }
}

