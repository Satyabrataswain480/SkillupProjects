#Import-Module SQLPS -DisableNameChecking
#  'lwdeldb-002' 'Banorte_Test' '\\lwdeldb-002\Backup\DB\' 'Lwdelbuild-001' 'BNT_Gated' '\\LWDelbuild-001\DB\' 
Param(
$SQLInstance,
$DBName,
$RestoreServer,
$GatedDBName,
$DBbackupPath,
$BackupPath,
$DBbackupPath_Local

)



#$timeStamp = Get-Date -format yyyy_MM_dd_HHmmss 

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null 

function RestoreDatabase{
param([string]$dbname, [string]$database, [string]$backupPath)

$NewDataPath = ''
$NewLogPath = ''
$relocate = @()
$BackupFile = "$backupPath"
#write-host $BackupFile
$dbfiles = Invoke-Sqlcmd -ServerInstance $database -Database tempdb -Query "RESTORE FILELISTONLY FROM DISK='$BackupFile';"

$defaultLocation = Invoke-Sqlcmd -ServerInstance $database -Database MASTER -Query "SELECT physical_name FROM sys.database_files;"
$count = 0;
foreach($path in $defaultLocation){
    $p = Split-Path -Path $path.ItemArray
    if($count -eq 0){
        $NewDataPath = $p
    }else{
        $NewLogPath = $p
    }
    $count++
}
write-host $NewDataPath
write-host $NewLogPath

foreach($dbfile in $dbfiles){
  if($dbfile.Type -eq 'L'){
    $name = $dbname +"_log.ldf"
    $newfile = Join-Path -Path $NewLogPath -ChildPath $name
    Write-Host $newfile
  } else {
    $name = $dbname +".mdf"
    $newfile = Join-Path -Path $NewDataPath -ChildPath $name
    Write-Host $newfile
  }
  $relocate += New-Object Microsoft.SqlServer.Management.Smo.RelocateFile ($dbfile.LogicalName,$newfile)
}

Restore-SqlDatabase -ServerInstance $database `
-Database $dbname `
-RelocateFile $relocate `
-BackupFile "$BackupFile" `
-ReplaceDatabase `
-RestoreAction Database `
-Verbose

}
$SQLInstance
$srv = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $SQLInstance 
$dbs = New-Object Microsoft.SqlServer.Management.Smo.Database 
$dbs = $srv.Databases 


$DBbackupPath = $DBbackupPath +"\"
$BackupPath = $BackupPath +"\"
$DBbackupPath1 = $DBbackupPath

$DBbackupPath = $DBbackupPath + $DBName + ".bak"
write-host $DBbackupPath

Write-host '************  DB Backup Started  **************'

Backup-SqlDatabase -ServerInstance $SQLInstance -Database $DBName -BackupFile $DBbackupPath

Write-host '************  DB Backup Completed  **************'

Write-host '************  Copy Backup Started  **************'

if($DBbackupPath1 -ne $BackupPath){
    Copy-Item -Path $DBbackupPath -Destination $BackupPath -Force -recurse
}

Write-host '************  Copy Backup Completed  **************'

$RestorePath = $DBbackupPath_Local +'/' + $DBName + ".bak"
Write-Host  $RestorePath

Write-host '************  DB Restore Started  **************'

RestoreDatabase -dbname $GatedDBName -database $RestoreServer -backupPath $RestorePath

Write-host '************  DB Restore Completed  **************'

sleep -Seconds 20

## Deleting backups

$DBbackupPath
$backupPath
$backupPath = $backupPath + '*'

Remove-Item -Path $DBbackupPath -Force
Remove-Item -Path $backupPath -recurse -Force

