﻿param(
    [parameter(Mandatory=$true, position=1)]
    [string]$dbname,
    [parameter(Mandatory=$true, position=2)]
    [string]$DbServer,
    [parameter(Mandatory=$true, position=3)]
    [string]$backupPath,
    [parameter(Mandatory=$true, position=4)]
    [string]$TargetDbName,
    [parameter(Mandatory=$true, position=5)]
    [string]$RestoreServer,
    [parameter(Mandatory=$true, position=6)]
    [int]$Trigger

)

if ($Trigger -eq 1) {
     
    #Write-host 'Restoring the Default DB ( LEN_MasterGold )' -ForegroundColor Green
    #$dateTime = Get-Date -Format _dd_MM_yyyy_HH_mm_ss
    $backUpFileName = $dbname 
    Write-Host "Backup Path : $backupPath" -ForegroundColor Green
    Write-Host "Backup File Name : $backUpFileName.bak" -ForegroundColor Green

    function global:DBBackup {
        $query = @"
USE master
BACKUP DATABASE [$dbname] TO DISK = N'$backupPath\$backUpFileName.bak' WITH NOFORMAT, NOINIT, NAME = N'$dbname Database Backup', SKIP, NOREWIND, NOUNLOAD, COMPRESSION, STATS = 10
"@
        Invoke-Sqlcmd -ServerInstance $DbServer -Database $dbname -Query $query -ConnectionTimeout 77777 -QueryTimeout 64444 -Verbose
    }

    DBBackup

    # If Db already exists
    $DbExistQuery = "SELECT COUNT(*) FROM sys.databases WHERE name = '$TargetDbName'"
    $exist = Invoke-Sqlcmd -ServerInstance $RestoreServer -Database 'master' -Query $DbExistQuery -QueryTimeout 65500 -ErrorAction Stop

    if ($exist.Column1 -eq 1) {
        Write-Host '*** Db already Exist, Sessions will be killed and Db will be taken offline ***'
        $databaseStatus = (Invoke-Sqlcmd -ServerInstance $RestoreServer -Database 'master' -Query "SELECT state_desc FROM sys.databases WHERE name = '$TargetDbName';" -QueryTimeout 65500 -ErrorAction Stop).state_desc

        if ($databaseStatus -eq 'OFFLINE') {
            $query = "ALTER DATABASE $TargetDbName SET ONLINE WITH NO_WAIT;"
            Invoke-Sqlcmd -ServerInstance $RestoreServer -Database 'master' -Query $query -QueryTimeout 65500 -ErrorAction Stop
        }

        # Kill Session
        $InsertQuery = @"
USE master;
DECLARE @DatabaseName NVARCHAR(100)
SET @DatabaseName = '$TargetDbName'

DECLARE @KillConnections NVARCHAR(MAX) = ''
SELECT @KillConnections = @KillConnections + 'Kill ' + CAST(spid AS NVARCHAR) + ';'
FROM sys.sysprocesses
WHERE DBID = DB_ID(@DatabaseName)

EXEC (@KillConnections)
GO
"@
        Invoke-Sqlcmd -ServerInstance $RestoreServer -Database $TargetDbName -Query $InsertQuery -QueryTimeout 65500 -ErrorAction Stop
        Write-Host '*** Sessions are Killed Now ***'

        $query = "ALTER DATABASE $TargetDbName SET OFFLINE WITH NO_WAIT"
        Invoke-Sqlcmd -ServerInstance $RestoreServer -Database $TargetDbName -Query $query -QueryTimeout 65500 -ErrorAction Stop
        Write-Host '*** $TargetDbName is now OFFLINE ***'
    } else {
        Write-Host '*** Db Does not exist. New Db will be restored *** '
    }

    $ServerDefaultPath = @"
SELECT 
SERVERPROPERTY('InstanceDefaultDataPath') AS InstanceDefaultDataPath,
SERVERPROPERTY('InstanceDefaultLogPath') AS InstanceDefaultLogPath
"@
    $defaultPath = Invoke-Sqlcmd -ServerInstance $RestoreServer -Query $ServerDefaultPath -QueryTimeout 65500 -ErrorAction Stop

    $InstanceDefaultDataPath = $defaultPath.InstanceDefaultDataPath + $TargetDbName + '.mdf'
    Write-host '*** DATA Path -- ' $InstanceDefaultDataPath ' ***'

    $InstanceDefaultLogPath = $defaultPath.InstanceDefaultLogPath + $TargetDbName + '.ldf'
    Write-host '*** LOG Path -- ' $InstanceDefaultLogPath ' ***'

    $XTPDefaultPath = $defaultPath.InstanceDefaultDataPath + $TargetDbName + '.ndf'
    Write-host '*** XTP Path -- ' $XTPDefaultPath ' ***'

    # Getting the Logical Data,Log and XTP File name
    $logicalNameQuery = "RESTORE FILELISTONLY FROM DISK = '$backupPath\$backUpFileName.bak';"
    $logicalNamefromBackup = Invoke-Sqlcmd -ServerInstance $RestoreServer -Query $logicalNameQuery -QueryTimeout 65500 -ErrorAction Stop

    $LogicalDataFileNameFromBackup = $logicalNamefromBackup | Where-Object { $_.Type -eq 'D' }
    $LogicalDataFileNameFromBackup = $LogicalDataFileNameFromBackup.LogicalName
    Write-host '*** LogicalDataFileNameFromBackup --' $LogicalDataFileNameFromBackup ' ***'

    $LogicalLogFileNameFromBackup = $logicalNamefromBackup | Where-Object { $_.Type -eq 'L' }
    $LogicalLogFileNameFromBackup = $LogicalLogFileNameFromBackup.LogicalName
    Write-host '*** LogicalLogFileNameFromBackup --' $LogicalLogFileNameFromBackup ' ***'

    $AdditionalLogicalFileNameFromBackup = $logicalNamefromBackup | Where-Object { $_.Type -eq 'S' }
    $AdditionalLogicalFileNameFromBackup = $AdditionalLogicalFileNameFromBackup.LogicalName
    Write-host '*** AdditionalLogicalFileNameFromBackup --' $AdditionalLogicalFileNameFromBackup ' ***'

    # Framing the Restore Query
    if (!([string]::IsNullOrEmpty($AdditionalLogicalFileNameFromBackup))) {
        Write-Host "*** Its 2022 Instance ***"
        $RestoreScript = @"
USE master;
RESTORE DATABASE $TargetDbName
FROM DISK = '$backupPath\$backUpFileName.bak'
WITH
    MOVE '$LogicalDataFileNameFromBackup' TO '$InstanceDefaultDataPath',
    MOVE '$LogicalLogFileNameFromBackup' TO '$InstanceDefaultLogPath',
    MOVE '$AdditionalLogicalFileNameFromBackup' TO '$XTPDefaultPath',
    REPLACE, keep_cdc;
"@
    } else {
        $RestoreScript = @"
USE master;
RESTORE DATABASE $TargetDbName
FROM DISK = '$backupPath\$backUpFileName.bak'
WITH
    MOVE '$LogicalDataFileNameFromBackup' TO '$InstanceDefaultDataPath',
    MOVE '$LogicalLogFileNameFromBackup' TO '$InstanceDefaultLogPath',
    REPLACE;
"@
    }

    Write-host '*** Restore Query --' $RestoreScript ' ***'

    Invoke-Sqlcmd -ServerInstance $RestoreServer -Query $RestoreScript -QueryTimeout 65500 -ErrorAction Stop
}
else {
    Write-Host "Default Backup and restore part is skipped" -ForegroundColor Yellow

    Write-Host "Restoring the Mentioned DB backup" -ForegroundColor Green


     Write-host '************  DB Restore Started  **************'

     Restore-SqlDatabase -ServerInstance 'LWDEMO-001' -Database 'LEN_CodeCoverage' -BackupFile '\\oti-fs\Lenovo\Backups\FIT-dontTouch\SND_PayOff_DB\LEN_MasterGold.bak' -ReplaceDatabase

     Write-host '************  DB Restore Completed  **************'
}