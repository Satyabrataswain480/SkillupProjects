﻿param(
$Publish_Path
)

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$Publish_Path = $Publish_Path + $currentDate + "\"
$Publish_Path

Remove-Item -Path $Publish_Path -Include *.pdb -Force -Recurse

