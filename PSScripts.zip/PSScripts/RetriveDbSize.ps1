﻿function GetSqlInstance{
Param(
 $ServerName
)

$Username = 'ODESSAPDC01\Devops.Admin'
$Password = ConvertTo-SecureString -AsPlainText 'Password@123' -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Username,$Password 

  $LocalInstances = @()
  [array]$Captions = Get-WmiObject win32_service -Credential $Credential -ComputerName $ServerName |
    where {
      $_.Name -match "mssql*" -and 
      $_.PathName -match "sqlservr.exe"
    } | foreach {$_.Caption}

  foreach ($Caption in $Captions) {
    if ($Caption -eq "MSSQLSERVER") {
      $LocalInstances += "MSSQLSERVER"
    } else {
      $Temp = $Caption |
        foreach {$_.split(" ")[-1]} |
          foreach {$_.trimStart("(")} |
            foreach {$_.trimEnd(")")}
      if($Temp -eq "MSSQLSERVER"){ $LocalInstances += "$ServerName" }
      else { $LocalInstances += "$ServerName\$Temp" }
    }
  }

  return $localInstances

}

function InsertDetails{
Param(
 $server
)
    
   try{
    
    [System.Reflection.Assembly]::LoadWithPartialName(“Microsoft.SqlServer.SMO”) | out-null
    $SMOserver = New-Object (‘Microsoft.SqlServer.Management.Smo.Server’) -argumentlist $Server

    foreach ($db in $SMOserver.Databases) {
    $sizeGB = [math]::Round($db.Size / 1024, 2)
    $dataSpaceUsageGB = [math]::Round($db.DataSpaceUsage / 1024, 2)
    $indexSpaceUsageGB = [math]::Round($db.IndexSpaceUsage / 1024, 2)
    $spaceAvailableGB = [math]::Round($db.SpaceAvailable / 1024, 2)

    $query = "Insert into DatabaseDistribution (LogDate, DbInstance, DbName, DbSize)
    values(GETDATE(), '$($server)', '$($db.Name)', '$($sizeGB)')"

    $query

    

    Invoke-Sqlcmd -Query $query -Database Dashboard_Prod -ServerInstance LWDELBUILD-001 -Username DashboardDBUser -Password Samsung@1234
    #Write-Host "$($db.Name) : Size=$sizeGB GB, DataSpaceUsage=$dataSpaceUsageGB GB, IndexSpaceUsage=$indexSpaceUsageGB GB, SpaceAvailable=$spaceAvailableGB GB"
    }
    }
    catch{
    
    }finally{
    
    }

    
}



$servers = @('LWDELDB-001', 'LWDELDB-002','LWDELDB-003', 'LWDELDB-004','LWDELDB-005')

$query = "delete from DatabaseDistribution"
Invoke-Sqlcmd -Query $query -Database Dashboard_Prod -ServerInstance LWDELBUILD-001 -Username DashboardDBUser -Password Samsung@1234

foreach($server in $servers){
    $instances = GetSqlInstance $server

    Write-Host "------------------------------"
    Write-Host "Starting with $($server)"
    
    foreach($instance in $instances){
        Write-Host "Instance Name: $($instance)"
        InsertDetails $instance
    }

    Write-Host "------------Completed----------------"
}


