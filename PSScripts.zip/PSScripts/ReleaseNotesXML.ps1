﻿Param (

[parameter (Mandatory=$true, position=0, ParameterSetName='Version')]
[string]$StorageAccountName,
[parameter (Mandatory=$true, position=1, ParameterSetName='Version')]
[string]$ContainerName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Version')]
[string]$ReleaseVersion,
[parameter (Mandatory=$true, position=3, ParameterSetName='Version')]
[string]$ProjectCode,
[parameter (Mandatory=$true, position=4, ParameterSetName='Version')]
[string]$PackageFolder,
[parameter (Mandatory=$true, position=5, ParameterSetName='Version')]
[string]$CustomerPortal,
[parameter (Mandatory=$true, position=6, ParameterSetName='Version')]
[string]$Database,
[parameter (Mandatory=$true, position=7, ParameterSetName='Version')]
[string]$DocPortal,
[parameter (Mandatory=$true, position=8, ParameterSetName='Version')]
[string]$LessorPortal,
[parameter (Mandatory=$true, position=9, ParameterSetName='Version')]
[string]$License,
[parameter (Mandatory=$true, position=10, ParameterSetName='Version')]
[string]$MigrationTool,
[parameter (Mandatory=$true, position=11, ParameterSetName='Version')]
[string]$PricingService,
[parameter (Mandatory=$true, position=12, ParameterSetName='Version')]
[string]$Reports,
[parameter (Mandatory=$true, position=13, ParameterSetName='Version')]
[string]$SqlServices,
[parameter (Mandatory=$true, position=14, ParameterSetName='Version')]
[string]$TValueBinaries,
[parameter (Mandatory=$true, position=15, ParameterSetName='Version')]
[string]$UserManual,
[parameter (Mandatory=$true, position=16, ParameterSetName='Version')]
[string]$VendorPortal, 
[parameter (Mandatory=$true, position=17, ParameterSetName='Version')]
[string]$WebAPI,
[parameter (Mandatory=$true, position=18, ParameterSetName='Version')]
[string]$WebServices,
[parameter (Mandatory=$true, position=19, ParameterSetName='Version')]
[string]$WindowsService,
[parameter (Mandatory=$true, position=20, ParameterSetName='Version')]
[string]$ToEmail,
[parameter (Mandatory=$true, position=21, ParameterSetName='Version')]
[string]$ReleaseDate,
[parameter (Mandatory=$true, position=22, ParameterSetName='Version')]
[string]$ReleaseTime,
[parameter (Mandatory=$true, position=23, ParameterSetName='Version')]
[string]$COTicket,
[parameter (Mandatory=$true, position=24, ParameterSetName='Version')]
[string]$AppSettingsConfig,
[parameter (Mandatory=$true, position=25, ParameterSetName='Version')]
[string]$Package_Source_Path,
[parameter (Mandatory=$false, position=26, ParameterSetName='Version')]
[string]$SSISPackages,
[parameter (Mandatory=$false, position=27, ParameterSetName='Version')]
[string]$IsCustomerPortal,
[parameter (Mandatory=$false, position=28, ParameterSetName='Version')]
[string]$WebandJobConfig,
[parameter (Mandatory=$false, position=29, ParameterSetName='Version')]
[string]$WebAPIConfig,
[parameter (Mandatory=$false, position=30, ParameterSetName='Version')]
[string]$PartnerPortal,
[parameter (Mandatory=$false, position=31, ParameterSetName='Version')]
[string]$Portal,
[parameter (Mandatory=$false, position=32, ParameterSetName='Version')]
[string]$IsHotFix,
[parameter (Mandatory=$false, position=33, ParameterSetName='Version')]
[string]$IsDataFix,
[parameter (Mandatory=$false, position=34, ParameterSetName='Version')]
[string]$IsRestartRequired
)

try
{

    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 

    $RelDir = $Package_Source_Path + $currentDate

    $ReleaseNotesPath = $RelDir + '\ReleaseNotes'

    if(Test-Path $ReleaseNotesPath)
    {
        $NotificationXMLFile = $ReleaseNotesPath + '\Notifications.xml'
        New-Item $NotificationXMLFile -ItemType File 
    }

    $XMLBody='<?xml version="1.0" encoding="utf-8"?>
      <Configs>
      <ReleaseVariables>
       <add key="StorageAccountName" value="" />
       <add key="ContainerName" value="" />
       <add key="ReleaseVersion" value="" />
       <add key="ProjectCode" value="" />
       <add key="PackageFolder" value="" />
       <add key="CustomerPortal" value="" />
       <add key="PartnerPortal" value="" />
       <add key="Database" value="" />
       <add key="DocPortal" value="" />
       <add key="LessorPortal" value="" />
       <add key="License" value="" />
       <add key="MigrationTool" value="" />
       <add key="PricingService" value="" />
       <add key="Reports" value="" />
       <add key="SqlServices" value="" />
       <add key="TValueBinaries" value="" />
       <add key="UserManual" value="" />   
       <add key="WebAPI" value="" />   
       <add key="WebServices" value="" />
       <add key="WindowsService" value="" />
       <add key="ToEmail" value="" />
       <add key="ReleaseDate" value="" />
       <add key="ReleaseTime" value="" />
       <add key="COTicket" value="" />
       <add key="AppSettingsConfig" value="" />
       <add key="SSISPackages" value="" />
       <add key="WebandJobConfig" value="" />
       <add key="WebAPIConfig" value="" />
    </ReleaseVariables>
    </Configs>'

    if(Test-Path $NotificationXMLFile)
    {
        Set-Content $NotificationXMLFile $XMLBody

        [XML]$config = Get-Content $NotificationXMLFile

        foreach($f in $config.Configs.ReleaseVariables.add)
        {
            if ($f.key -eq 'StorageAccountName')
            {
                $f.value = $StorageAccountName        
            }
            if ($f.key -eq 'ContainerName')
            {
                $f.value = $ContainerName        
            }
            if ($f.key -eq 'ReleaseVersion')
            {
                $f.value = $ReleaseVersion        
            }
            if ($f.key -eq 'ProjectCode')
            {
                $f.value = $ProjectCode        
            }
            if ($f.key -eq 'PackageFolder')
            {
                $f.value = $PackageFolder        
            }
            if ($f.key -eq 'CustomerPortal')
            { 
                $f.value = $CustomerPortal        
            }
            if ($f.key -eq 'PartnerPortal')
            { 
                $f.value = $PartnerPortal        
            }
            if ($f.key -eq 'Database')
            {
                $f.value = $Database        
            }
            if ($f.key -eq 'DocPortal')
            {
                $f.value = $DocPortal        
            }
            if ($f.key -eq 'LessorPortal')
            {
                $f.value = $LessorPortal        
            }
            if ($f.key -eq 'License')
            {
                $f.value = $License        
            }
            if ($f.key -eq 'MigrationTool')
            {
                $f.value = $MigrationTool        
            }
            if ($f.key -eq 'PricingService')
            {
                $f.value = $PricingService        
            }
            if ($f.key -eq 'Reports')
            {
                $f.value = $Reports        
            }
            if ($f.key -eq 'SqlServices')
            {
                $f.value = $SqlServices        
            }
            if ($f.key -eq 'TValueBinaries')
            {
                $f.value = $TValueBinaries        
            }
            if ($f.key -eq 'UserManual')
            {
                $f.value = $UserManual        
            }
            if ($f.key -eq 'WebAPI')
            {
                $f.value = $WebAPI        
            }
            if ($f.key -eq 'WebServices')
            {
                $f.value = $WebServices        
            }
            if ($f.key -eq 'WindowsService')
            {
                $f.value = $WindowsService        
            }
            if ($f.key -eq 'ToEmail')
            {
                $f.value = $ToEmail        
            }
            if ($f.key -eq 'ReleaseDate')
            {
                $f.value = $ReleaseDate        
            }
            if ($f.key -eq 'ReleaseTime')
            {
                $f.value = $ReleaseTime        
            }
            if ($f.key -eq 'COTicket')
            {
                $f.value = $COTicket        
            }
            if ($f.key -eq 'AppSettingsConfig')
            {
                $f.value = $AppSettingsConfig        
            }
            if ($f.key -eq 'SSISPackages')
            {
                $f.value = $SSISPackages        
            }
            if ($f.key -eq 'WebandJobConfig')
            {
                $f.value = $WebandJobConfig        
            }
            if ($f.key -eq 'WebAPIConfig')
            {
                $f.value = $WebAPIConfig        
            }
        }

        $config.Save($NotificationXMLFile)
    }
}
catch 
{
    throw $_.Exception.Message
}