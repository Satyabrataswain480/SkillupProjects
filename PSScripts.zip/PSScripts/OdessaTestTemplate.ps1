﻿$timeStamp = Get-Date -format yyyy_MM_dd_HHmmss
$projectName=##PROJECTNAME##
$sharedPath=##SHAREDPATH##
$otexe = ##OTEXE##
$otws=##OTWS##
$OTRunName=##OTRUNNAME##
$WebApplicationurl=##APPURL##
$OTScenarioCollectionName=##COLLECTION##
$OTLogsFolder=##LOGFOLDER##
$OTServer=##OTSERVER##
$BusinessUnit=##BU##
$userName =##USER##
$password = ##PASSWORD##
$dashboardProjectName = ##DPNAME##
$IsZephyrChangeRequired = ##ZephyrChange##
$psLogpath = '\\lwdeljob-004\DeliveryDevops\GitProjects\Logs'
$psLogFileName = "$psLogpath\$projectName" +'_'+ $timeStamp+"_log.txt"
Start-Transcript -Append $psLogFileName



function encryptKey($plaintext){
    
    $plainBytes = [System.Text.Encoding]::UTF8.GetBytes($plaintext)
    $publicKey="<RSAKeyValue><Modulus>u/+n2bHHccEVCZ6USiENsWb8Nl9YtTICf1nv62UQiv4kynsrAAgysUuE5IsnoYb1XfcTgjLEa3riUP0WoOIIBi4MfDSWgpPTglYjwCxovF5GU3cAiBBN28q6w/d1dQqaPJ1kUyRSCkYjaH7l2Pq3AO+bjFRsWz1VyR8m4WBtB0U=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
    $provider=[System.Security.Cryptography.RSACryptoServiceProvider]::new(1024) 
    $provider.PersistKeyInCsp = $false;
    $provider.FromXmlString($publicKey)
    $cipher=$provider.Encrypt($plainBytes,$true)
    return [System.Convert]::ToBase64String($cipher)
 }

 write-host $otexe
 write-host $otws 
 write-host $OTRunName
 write-host $WebApplicationurl
 write-host $OTScenarioCollectionName
 write-host $OTLogsFolder
 write-host $OTServer

 $userName 
 $password = encryptKey($password)
              
function Run-OTScenarios{
param(
  [string]$OTExe, [string]$OTRunName, [string]$WebApplicationurl, [string]$OTWorkspace, [string]$OTScenarioCollectionName, [string]$OTLogsFolder, [string]$userName, [string]$password, [string]$bu
)
    $logfile = $OTLogsFolder+"\$OTRunName"+"_Execute.txt"
    try
    {
        Write-Host "With runname as $OTRunName going to start on $WebApplicationurl under workspace $OTWorkspace to run collection named $OTScenarioCollectionName"
        write-host $bu
         
        $arguments = "-Operation Execute -DeploymentPath $WebApplicationurl -WorkingDirectory $OTWorkspace -Scenarios $OTScenarioCollectionName -Collection true -RunName $OTRunName -LogsFolder $OTLogsFolder"
        if($userName -ne 'defaultUser#'){
            $arguments =$arguments + " -UserName $userName -Password $password"
        }
        if($bu -ne 'defaultBU#') {
          $arguments = $arguments + " -BusinessUnit $bu"
        }
         if($IsZephyrChangeRequired -eq 'true') {
          $arguments = $arguments + " -UpdateExecutionToZephyr false -ZephyrTestCycleKey """
        }
        Write-Host $OTExe
        Write-Host $arguments
        
        Start-Process $OTExe $arguments -Wait
        
        
        write-host "OT has been scheduled successfully" -f Green

    }
    catch
    {
      Write-Host "##error## occurred:"
      throw $_
    }
}  

function UpdateDashboard{
param(
  [string]$project, [string]$runName, [string]$sharedPath
)
$params = @{
 "projectName"=$project;
 "runName"=$runName;
 "sharedPath"=$sharedPath;
}
$uri='http://lwdelbuild-001:8090/ot/create'
$body = ConvertTo-Json -InputObject $params
$body
Invoke-WebRequest -Headers @{"Content-Type" = "application/json"} -Uri $uri -Method POST -Body $body

} 

Run-OTScenarios $otexe $OTRunName $WebApplicationurl $otws $OTScenarioCollectionName $OTLogsFolder $userName $password $BusinessUnit
 UpdateDashboard $dashboardProjectName $OTRunName $sharedPath
  