﻿Param (

[parameter (Mandatory=$true, position=1, ParameterSetName='email')]
[string]$BuildRelease,
[parameter (Mandatory=$true, position=2, ParameterSetName='email')]
[string]$Groupemail,
[parameter (Mandatory=$true, position=3, ParameterSetName='email')]
[string]$StartEnd,
[parameter (Mandatory=$true, position=4, ParameterSetName='email')]
[string]$QAStaging,
[parameter (Mandatory=$true, position=5, ParameterSetName='email')]
[string]$ProjectName

)

function GenerateDotReport
{

   if($StartEnd -eq 'Start')
   {
     $global:MailBody += "<br>Hi Team,"
     $global:MailBody += "<br><br>" + $QAStaging + " deployment is going to start. " + $QAStaging + " site will be unavailable for few mins."
    
   }
   else #Completed
   {

     $global:MailBody += "<br>Hi Team,"
     $global:MailBody += "<br>" + $QAStaging + " deployment has been completed successfully.You can start testing."
   
   }
  
         $global:MailBody += "<br><br>Regards," 
         $global:MailBody += "<br>Devops Team</br><br>"

        
         # Send-Email -smtpServer mail.odessatech.in -from 'Delivery_Devops@odessainc.com'  -to  $Groupemail 
          $From = 'Delivery_Devops@odessainc.com'
          $Subject = $ProjectName + ' Build \ Release Email Notification'   #Change
          $Body = $global:MailBody

            $email = New-Object System.Net.Mail.MailMessage $From, $Groupemail, $Subject, $Body
            #$email.To.Add($To)
            $email.isBodyhtml = $true
            $smtp = new-object Net.Mail.SmtpClient('mail.odessatech.in',25)
            $smtp.Credentials = New-Object System.Net.NetworkCredential("no-reply@odessatech.in", "password-1"); 
            #$smtp.Port = 587
            $smtp.Send($email)
         
         
         
         
         ########################################################################################################
       
         
        $global:MailBody=''
}
    
GenerateDotReport
$global:MailBody = ''
 



