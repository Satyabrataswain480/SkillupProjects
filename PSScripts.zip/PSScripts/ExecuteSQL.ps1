Param (
$SQLServer,
$DatabaseNames,
$FolderPath,
$fromBuild = '0'
)



if(!(Test-path $FolderPath))
{
   $FolderPath
   write-host 'DBScripts is not applicable.'
   return

}

$DatabaseList = $DatabaseNames.Split(',')

foreach ($DatabaseName in $DatabaseList) {
    # Trim any leading/trailing whitespace from the database name
    $DatabaseName = $DatabaseName.Trim()

##FW script execution
if($fromBuild -eq '2'){ 
    # Get ReleaseviersionID
    $ReleaseVersionId= invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Query 'select top 1 id from releaseversions order by ID desc'  -QueryTimeout 65500
    #Get all scripts name from db
    $Getreleasescript=invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Query 'Select ReleaseScriptName from ReleaseVersionDetails order by ID'  -QueryTimeout 65500

    foreach ($ScriptFile in (get-childitem -path $FolderPath -filter "*.sql"))
    {
       # check dbscript name with filename  
       foreach ($DBScript in $Getreleasescript)
       {
          $BaseScriptFile= $ScriptFile.BaseName
          if($BaseScriptFile -eq $DBScript.ReleaseScriptName)
          {
             $TobeExecute=1;
             break
          }
          else
          {
              $TobeExecute=0;
          }
       }
   
      ##Verify if $TobeExecute=0 then execute script
      if($TobeExecute -eq 0)
       {
        # Get ReleaseviersionID
         $ReleaseVersionId= invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Query 'select top 1 id from releaseversions order by ID desc'  -QueryTimeout 65500
         write-host 'Versionid ' $ReleaseVersionId.id
         $ReleaseVersionId1 = $ReleaseVersionId.id
         $SQLFilename = $ScriptFile.BaseName

         write-host "SQL File Name: $SQLFilename"


          ##Execute product\FRWK Actual Script
          $SQLFilenameExecute = $FolderPath +'\' + $ScriptFile.Name
          write-host 'SQL Script Path - ' $SQLFilenameExecute
          invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -InputFile  $SQLFilenameExecute -QueryTimeout 65500 -ErrorAction Stop
          ##

          ## Update ReleaseVersionDetails table
          $InsertQuery = "INSERT INTO [dbo].[ReleaseVersionDetails] ([ReleaseScriptName],[IsExecuted],[CreatedById],[CreatedTime],[UpdatedById],[UpdatedTime],[ReleaseVersionId]) VALUES ('" + $SQLFilename + "',1,1,GETDATE(),null,null,$ReleaseVersionId1)"
          invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Query $InsertQuery  -QueryTimeout 65500 -ErrorAction Stop
        }
        else
        {
          write-host 'Script Already Executed - ' $ScriptFile
        }
    }
    return
}
if($fromBuild -eq '3')
{
    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
    $FolderPath = $FolderPath + "\" + $currentDate + "\"
    $FolderPath = $FolderPath + 'Database\DBScripts\'
# Check if folder not available
if(!(Test-Path $FolderPath))
{
    write-host "$FolderPath not found"
   return
}
$DbScriptSourceDDL = $FolderPath+ "DDL"
$DbScriptSourceDDL
    # Get ReleaseviersionID
    $ReleaseVersionId= invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Query 'select top 1 id from releaseversions order by ID desc'  -QueryTimeout 65500
    #Get all scripts name from db
    $Getreleasescript=invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Query 'Select ReleaseScriptName from ReleaseVersionDetails order by ID'  -QueryTimeout 65500

#DDL Execution

    if( (Get-ChildItem $DbScriptSourceDDL  |Measure-Object).Count -eq 0)
    {
            write-host "No files"
    }
    else
    {
        
        foreach ($filename in get-childitem -path $DbScriptSourceDDL -filter "*.sql")
        {
            try
            {
                $regex = '^[1-3][0-9]{3}_.{1,31}\.sql$'
                $found = $filename -match $regex
                Write-Host "$filename : $found"
                if($found -eq $false)
                {
                    throw "$filename have incorrect filename. Please follow the naming convention mentioned in readme file."
                }
               $PWFile = $filename.BaseName.SubString(0,1)

                if($PWFile -lt "3") # Framework \ product
                {   
                   $ScriptFile= $filename.BaseName
                   $ScriptFile

                       if(!([string]::IsNullOrEmpty($Getreleasescript)))
                       { 
                           # check dbscript name with filename  
                           foreach ($DBScript in $Getreleasescript)
                           {
                             if($ScriptFile -eq $DBScript.ReleaseScriptName)
                              {
                                 $TobeExecute=1;
                                 break
                              }
                              else
                              {
                                  $TobeExecute=0;
                              }
                           }
                       }
                       else
                       {
                            $TobeExecute=0;
                       }
   
                      ##Verify if $TobeExecute=0 then execute script
                      if($TobeExecute -eq 0)
                      {
                        
                         $ReleaseVersionId1 = $ReleaseVersionId.id
                        
                          invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -InputFile  $filename.fullname -QueryTimeout 65500 -ErrorAction Stop
                       
                          ## Update ReleaseVersionDetails table
                          $InsertQuery = "INSERT INTO [dbo].[ReleaseVersionDetails] ([ReleaseScriptName],[IsExecuted],[CreatedById],[CreatedTime],[UpdatedById],[UpdatedTime],[ReleaseVersionId]) VALUES ('" + $ScriptFile + "',1,1,GETDATE(),null,null,$ReleaseVersionId1)"
                          invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Query $InsertQuery  -QueryTimeout 65500 -ErrorAction Stop
                          
                        }
                    
                    else
                    {
                      write-host 'Script Already Executed - ' $ScriptFile
                    }
       
                } 
                else  # Project script exec
                {
                    Write-Host 'Executing project scripts'
                    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -InputFile $filename.fullname -QueryTimeout 65500
                    write-host $filename.fullname
                 }
                
            
            }
            catch 
            {
               throw $_.Exception.Message
            }
       
         }
    }

##DML
$DbScriptSourceDML = $FolderPath + 'DML'
    if( (Get-ChildItem $DbScriptSourceDML  |Measure-Object).Count -eq 0)
    {
            write-host "No files"
    }
    else
    {
        write-host $DMLPath
        foreach ($filename in get-childitem -path $DbScriptSourceDML -filter "*.sql")
        {
            try
            {
            
                invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -InputFile $filename.fullname -QueryTimeout 65500
                write-host $filename.fullname
            }
            catch 
            {
               throw $_.Exception.Message
            }
       
         }
    }
return	
}

if($fromBuild -eq '1'){
    if( (Get-ChildItem $FolderPath  |Measure-Object).Count -eq 0 )
    {
        write-host "No sql scripts found..."
    }
    else {
        foreach ($filename in get-childitem -path  $FolderPath -filter "*.sql")
        {
            $filename
            invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -InputFile $filename.fullname -QueryTimeout 65500 -ErrorAction Stop
            write-host 'Executed SQL file - ' + $filename 
        }

    }

    return
}

}

