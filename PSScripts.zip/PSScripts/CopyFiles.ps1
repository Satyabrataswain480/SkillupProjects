param(
    [string] $source,
    [string] $destination,
	[string] $wildcart = '*',
    [string] $clear = '0'
)


    if (Test-Path -Path $source){
        if((Test-Path -Path $destination) -eq $false){
            New-Item -Path $destination -ItemType directory    
        }
        if($clear -eq '1'){
            remove-item -Path $destination -Exclude *.config,*.bat, OpenXmlPowerTools.dll -Force -Recurse
        } elseIf($clear -eq '2'){
            remove-item -Path $destination -Exclude "OpenXmlPowerTools.dll" -Force -Recurse
        }
        if($wildcart -eq 'na' -or $wildcart -eq 'NA'){
            Copy-Item -Exclude "OpenXmlPowerTools.dll" -Path $source -Destination $destination -Recurse -force
        }else {
            Copy-Item -Exclude "OpenXmlPowerTools.dll" -Path $source\$wildcart -Destination $destination -Recurse -force
        }
    }
    else{
        Write-Host "$source not found."
    }