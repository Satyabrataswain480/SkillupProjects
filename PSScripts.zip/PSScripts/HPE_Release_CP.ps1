﻿##  This script will create Release contant
Param  (
[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Build_Path,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Release_Path,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$Artifact_Build_Path,
[parameter (Mandatory=$false, position=3, ParameterSetName='Release')]
[string]$PackageReference,
[parameter (Mandatory=$false, position=4, ParameterSetName='Release')]
[string]$IsCustomerPortal,
[parameter (Mandatory=$false, position=5, ParameterSetName='Release')]
[string]$IsDotNet7Upgraded = '0',
[parameter (Mandatory=$false, position=6, ParameterSetName='Release')]
[string]$IsDotNet7 = '0'
)

##  Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir = $Release_Path + $currentDate

if($PackageReference -eq '1')
{    
  $packagePath = 'C:\Users\devops.admin\.nuget\packages'
  write-host 'Package Reference Path: ' $packagePath
}
else
{
  $packagePath = $Build_Path + '\Packages'
}

if($PackageReference -eq '1')
{
    #Get the Current Fx version configured for LeaseWave solution
    $BuildProjData = [xml]( Get-Content  "$Build_Path\Build.proj"); 
    $FrameworkVersion = $BuildProjData.Project.ChildNodes.Item(0).FrameworkVersion
    $FRWKFolders = $packagePath + '\odessa.framework\' + $FrameworkVersion
    $FRWKABSPath = $FRWKFolders
    write-host 'FRWK Path: ' $FRWKABSPath
}
else
{
    $FRWKFolders = Get-childitem -Path $packagePath -Filter 'lw.Framework*'
    $FRWKABSPath = $null
}

if($PackageReference -eq '0')
{
    if($FRWKFolders.count -gt 1)
    {
      write-host 'Multiple framework folders found. keep only latest one'
      throw
    }
    else
    {
      $FRWKABSPath = $FRWKFolders.FullName
      write-host $FRWKABSPath
    }
}

if(!(Test-path -Path $RelDir))
{
   New-Item -Name $currentDate -ItemType Directory -Path $Release_Path
} 
else
{
  Remove-Item -Path $RelDir -Recurse -Force
  New-Item -Name $currentDate -ItemType Directory -Path $Release_Path
}

##  Creating Root FOlder
if($IsCustomerPortal -eq '1')
{
    New-Item -Name 'CustomerPortal'  -ItemType Directory -Path $RelDir
}
else
{
    New-Item -Name 'WebApp'  -ItemType Directory -Path $RelDir
}
New-Item -Name 'Database'  -ItemType Directory -Path $RelDir
New-Item -Name 'WebAPI'  -ItemType Directory -Path $RelDir
#New-Item -Name 'DocPortal'  -ItemType Directory -Path $RelDir
New-Item -Name 'Reports'  -ItemType Directory -Path $RelDir
New-Item -Name 'WindowsService'  -ItemType Directory -Path $RelDir
#New-Item -Name 'ReleaseNotes'  -ItemType Directory -Path $RelDir

### Creating Sub Folders
if($IsCustomerPortal -eq '1')
{
    $LP = $RelDir + '\CustomerPortal'
}
else
{
    $LP = $RelDir + '\WebApp'
}
New-Item -Name 'App_Data'  -ItemType Directory -Path $LP

### Creating Sub FOlders
$DBScripts = $RelDir + '\Database'
New-Item -Name 'DBScripts\DDL'  -ItemType Directory -Path $DBScripts
New-Item -Name 'DBScripts\DML'  -ItemType Directory -Path $DBScripts
   
$Reports = $RelDir + '\Reports'
New-Item -Name 'RDLs'  -ItemType Directory -Path  $Reports
New-Item -Name 'ReportHelper'  -ItemType Directory -Path  $Reports

### Creating WbAPI\DomainAssemblies
$WebAPI = $RelDir + '\WebAPI'
New-Item -Name 'DomainAssemblies'  -ItemType Directory -Path $WebAPI
New-Item -Name 'App_Data'  -ItemType Directory -Path $WebAPI

#DocPortal not needed for latest FRWK
# write-host 'Preparing DocPortal...'
# $SourceDocportal = $FRWKABSPath + '\Tools\LW.Docportal\'
# $DestDocportal = $RelDir + '\Docportal\'
# if(Test-Path $SourceDocportal)
# {
#     robocopy $SourceDocportal $DestDocportal /E /copyall
# }
# write-host 'Completed Docportal...'


### Fill FRWK folders
write-host 'Preparing WindowsService...'
if($IsDotNet7Upgraded -eq '1')
{
    if($IsDotNet7 -eq '1')
    {
        $SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\net7.0\'
    }
    else
    {
        $SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\net48\'
    }
}
else
{
    $SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\'
}

write-host 'WindowsService Source path: ' $SourceWindowService
$DestWindowService = $RelDir + '\WindowsService\'

robocopy $SourceWindowService $DestWindowService /E /copyall

##Copy Lw.Domain dll's
$Window0 = $Artifact_Build_Path + '\Lw.Domain.Extension.dll'
$Window1 = $Artifact_Build_Path + '\Lw.Domain.Project.Extension.dll'
$Window2 = $Artifact_Build_Path + '\Lw.Domain.Project.Resource.dll'
$Window3 = $Artifact_Build_Path + '\Lw.Domain.Resource.dll'

$Window4 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AspNet.TelemetryCorrelation.dll'
$Window5 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.Agent.Intercept.dll'
$Window6 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.DependencyCollector.dll'
$Window7 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.DependencyCollector.pdb'
$Window8 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.PerfCounterCollector.dll'
$Window9 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.PerfCounterCollector.pdb'
$Window10 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.ServerTelemetryChannel.dll'
$Window11 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.ServerTelemetryChannel.pdb'
$Window12 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.Web.dll'
$Window13 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.Web.pdb'
$Window14 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.WindowsServer.dll'
$Window15 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.WindowsServer.pdb'
$Window16 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.ApplicationInsights.dll'
$Window17 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.ApplicationInsights.pdb'

$Window18 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\System.Diagnostics.DiagnosticSource.dll'
$Window19 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Azure.dll'
$Window20 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.AzureAppConfiguration.dll'
$Window21 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Base.dll'
$Window22 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Environment.dll'
$Window23 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.UserSecrets.dll'


if(!([string]::IsNullOrEmpty($Window0)) -and (Test-path $Window0)){
    Copy-Item $Window0 $DestWindowService
}
if(!([string]::IsNullOrEmpty($Window1)) -and (Test-path $Window1)){
    Copy-Item $Window1 $DestWindowService
}
if(!([string]::IsNullOrEmpty($Window2)) -and (Test-path $Window2)){
    Copy-Item $Window2 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window3)) -and (Test-path $Window3)){
    Copy-Item $Window3 $DestWindowService 
}


if(!([string]::IsNullOrEmpty($Window4)) -and (Test-path $Window4)){
    Copy-Item $Window4 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window5)) -and (Test-path $Window5)){
    Copy-Item $Window5 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window6)) -and (Test-path $Window6)){
    Copy-Item $Window6 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window7)) -and (Test-path $Window7)){
    Copy-Item $Window7 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window8)) -and (Test-path $Window8)){
    Copy-Item $Window8 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window9)) -and (Test-path $Window9)){
    Copy-Item $Window9 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window10)) -and (Test-path $Window10)){
    Copy-Item $Window10 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window11)) -and (Test-path $Window11)){
    Copy-Item $Window11 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window12)) -and (Test-path $Window12)){
    Copy-Item $Window12 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window13)) -and (Test-path $Window13)){
    Copy-Item $Window13 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window14)) -and (Test-path $Window14)){
    Copy-Item $Window14 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window15)) -and (Test-path $Window15)){
    Copy-Item $Window15 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window16)) -and (Test-path $Window16)){
    Copy-Item $Window16 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window17)) -and (Test-path $Window17)){
    Copy-Item $Window17 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window18)) -and (Test-path $Window18)){
    Copy-Item $Window18 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window19)) -and (Test-path $Window19)){
    Copy-Item $Window19 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window20)) -and (Test-path $Window20)){
    Copy-Item $Window20 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window21)) -and (Test-path $Window21)){
    Copy-Item $Window21 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window22)) -and (Test-path $Window22)){
    Copy-Item $Window22 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window23)) -and (Test-path $Window23)){
    Copy-Item $Window23 $DestWindowService 
}




##Copy Tavalue to WindowService bin folder

$SourceTValue1 = $Artifact_Build_Path + '\TValue6.dll'
$SourceTvalue2 = $Artifact_Build_Path + '\Tvalue6Engine2.dll'

if(!([string]::IsNullOrEmpty($SourceTValue1)) -and (Test-path $SourceTValue1)){
    copy-item $SourceTValue1 $DestWindowService
}
if(!([string]::IsNullOrEmpty($SourceTValue2)) -and (Test-path $SourceTValue2)){
    copy-item $SourceTValue2 $DestWindowService
}

write-host 'Completed WindowsService...'

write-host 'Preparing WebAPI...'

if($IsDotNet7Upgraded -eq '1')
{
    if($IsDotNet7 -eq '1')
    {
        $SourceWebAPI = $FRWKABSPath + '\Tools\Lw.WebApi\net7.0\'
    }
    else
    {
        $SourceWebAPI = $FRWKABSPath + '\Tools\Lw.WebApi\net48\'
    }
}
else
{
    $SourceWebAPI = $FRWKABSPath + '\Tools\Lw.WebApi\'
}
$DestWebAPI = $RelDir + '\WebAPI\'
write-host 'Before RoboCopy Web API Source Path...' $SourceWebAPI
if(Test-Path $SourceWebAPI)
{
  robocopy $SourceWebAPI $DestWebAPI /E /copyall  
}
write-host 'After RoboCopy Web API Source Path...' $SourceWebAPI

##Copy LW.dll's
$SourceWebAPIDomain1 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Extension.dll'
$SourceWebAPIDomain2 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Resource.dll'
$SourceWebAPIDomain3 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Project.Extension.dll'
$SourceWebAPIDomain4 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Project.Resource.dll'
$SourceWebAPIDomain5 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AspNet.TelemetryCorrelation.dll'
$SourceWebAPIDomain6 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.Agent.Intercept.dll'
$SourceWebAPIDomain7 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.DependencyCollector.dll'
$SourceWebAPIDomain8 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.DependencyCollector.pdb'
$SourceWebAPIDomain9 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.PerfCounterCollector.dll'
$SourceWebAPIDomain10 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.PerfCounterCollector.pdb'
$SourceWebAPIDomain11 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.ServerTelemetryChannel.dll'
$SourceWebAPIDomain12 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.ServerTelemetryChannel.pdb'
$SourceWebAPIDomain13 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.Web.dll'
$SourceWebAPIDomain14 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.Web.pdb'
$SourceWebAPIDomain15 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.WindowsServer.dll'
$SourceWebAPIDomain16 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.WindowsServer.pdb'
$SourceWebAPIDomain17 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.ApplicationInsights.dll'
$SourceWebAPIDomain18 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.ApplicationInsights.pdb'



if(Test-path $SourceTValue1){
$SourceTValue1 = $Artifact_Build_Path + '\TValue6.dll'
$SourceTvalue2 = $Artifact_Build_Path + '\Tvalue6Engine2.dll'
}
        

$DestWebAPI_bin = $DestWebAPI + 'bin\'

write-host $SourceWebAPIDomain1
write-host $DestWebAPI_bin

if(Test-path $SourceWebAPIDomain1){
   if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain1 $DestWebAPI_bin 
   }
}
if(Test-path $SourceWebAPIDomain2){
   if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain2 $DestWebAPI_bin 
   }
}
if(Test-path $SourceWebAPIDomain3){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain3 $DestWebAPI_bin 
    }
}
if(Test-path $SourceWebAPIDomain4){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain4 $DestWebAPI_bin 
   }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain5)) -and (Test-path $SourceWebAPIDomain5)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain5 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain6)) -and (Test-path $SourceWebAPIDomain6)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain6 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain7)) -and (Test-path $SourceWebAPIDomain7)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain7 $DestWebAPI_bin
    } 
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain8)) -and (Test-path $SourceWebAPIDomain8)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain8 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain9)) -and (Test-path $SourceWebAPIDomain9)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain9 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain10)) -and (Test-path $SourceWebAPIDomain10)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain10 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain11)) -and (Test-path $SourceWebAPIDomain11)){
    if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain11 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain12)) -and (Test-path $SourceWebAPIDomain12)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain12 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain13)) -and (Test-path $SourceWebAPIDomain13)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain13 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain14)) -and (Test-path $SourceWebAPIDomain14)){
    if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain14 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain15)) -and (Test-path $SourceWebAPIDomain15)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain15 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain16)) -and (Test-path $SourceWebAPIDomain16)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain16 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain17)) -and (Test-path $SourceWebAPIDomain17)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain17 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain18)) -and (Test-path $SourceWebAPIDomain18)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain18 $DestWebAPI_bin 
    }
}

if(!([string]::IsNullOrEmpty($SourceTValue1)) -and (Test-path $SourceTValue1))
{
    if(Test-path $DestWebAPI_bin)
    {
        copy-item $SourceTValue1 $DestWebAPI_bin         
    }
}
if(!([string]::IsNullOrEmpty($SourceTValue2)) -and (Test-path $SourceTValue2))
{
    if(Test-path $DestWebAPI_bin)
    {
        copy-item $SourceTValue2 $DestWebAPI_bin 
    }
}

##Copy WebAPi \ DomainAssemblies
$SourceDomainAs1 = $Artifact_Build_Path + '\Lw.Domain.dll'
$SourceDomainAs2 = $Artifact_Build_Path + '\LW.Domain.PDB'
$WebAPIDestiation = $RelDir + '\WebAPI\DomainAssemblies\'

Copy-Item $SourceDomainAs1 $WebAPIDestiation
Copy-Item $SourceDomainAs2 $WebAPIDestiation

write-host 'Completed WebAPI...'


if ($lastexitcode -lt 8) { $lastexitcode = 0 }

