##  This script will zip the folders using 7 Zip and paste it in a different folder. 
Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Package_Source_Path,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Release_Content_Path,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$Package_Destination_Path,
[parameter (Mandatory=$true, position=3, ParameterSetName='Release')]
[string]$ReleaseVersion,
[parameter (Mandatory=$false, position=4, ParameterSetName='Release')]
[string]$WebandJobConfig,
[parameter (Mandatory=$false, position=5, ParameterSetName='Release')]
[string]$WebAPIConfig,
[parameter (Mandatory=$false, position=6, ParameterSetName='Release')]
[string]$WSProject
)

function ZipFolders([String] $SourcePath, [String] $DestPath){
    if (-not (test-path "$env:ProgramFiles\7-Zip\7z.exe")) {throw "$env:ProgramFiles\7-Zip\7z.exe needed"}
    [string]$7ZipExePath = "C:\Program Files\7-zip\7z.exe";
    [Array]$arguments = "a", "-tzip", "$DestPath", "$SourcePath";
    & $7ZipExePath $arguments;
}

## Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 

$RelDir = $Package_Source_Path + $currentDate

$DestDir = $Release_Content_Path 

Write-Host "Source Directory:" $RelDir

Write-Host "Intermediate Directory:" $DestDir

Write-Host "Destination Directory:" $Package_Destination_Path

$Include = "AppSettings.config", "ConnectionStrings.config", "Lw.WindowsServices.exe.config", "Web.config", "ApplicationInsights.config"

if(Test-Path $RelDir)
{
    #Get-ChildItem $RelDir -Include $Include -Recurse | Remove-Item -Recurse

    $CustomerPortal = $RelDir + '\CustomerPortal\'
    if(Test-Path $CustomerPortal)
    {
        Get-ChildItem $CustomerPortal -Include $Include -Recurse | Remove-Item -Recurse
    }

    $PartnerPortal = $RelDir + '\PartnerPortal\'
    if(Test-Path $PartnerPortal)
    {
        Get-ChildItem $PartnerPortal -Include $Include -Recurse | Remove-Item -Recurse
    }

    $DocPortal = $RelDir + '\DocPortal\'
    if(Test-Path $DocPortal)
    {
        Get-ChildItem $DocPortal -Include $Include -Recurse | Remove-Item -Recurse
    }

    $LessorPortal = $RelDir + '\LessorPortal\'
    if(Test-Path $LessorPortal)
    {
        Get-ChildItem $LessorPortal -Include $Include -Recurse | Remove-Item -Recurse        
    }

    $MigrationTool = $RelDir + '\MigrationTool\'
    if(Test-Path $MigrationTool)
    {
        Get-ChildItem $MigrationTool -Include $Include -Recurse | Remove-Item -Recurse
    }

    $PricingService = $RelDir + '\PricingService\'
    if(Test-Path $PricingService)
    {
        Get-ChildItem $PricingService -Include $Include -Recurse | Remove-Item -Recurse
    }

    $VendorPortal = $RelDir + '\VendorPortal\'
    if(Test-Path $VendorPortal)
    {
        Get-ChildItem $VendorPortal -Include $Include -Recurse | Remove-Item -Recurse
    }

    $WebAPI = $RelDir + '\WebAPI\'
    if(Test-Path $WebAPI)
    {
        Get-ChildItem $WebAPI -Include $Include -Recurse | Remove-Item -Recurse        
    }

    $WebServices = $RelDir + '\WebServices\'
    if(Test-Path $WebServices)
    {
        Get-ChildItem $WebServices -Include $Include -Recurse | Remove-Item -Recurse
    }

    $WindowsService = $RelDir + '\WindowsService\'
    if(Test-Path $WindowsService)
    {
        Get-ChildItem $WindowsService -Include $Include -Recurse | Remove-Item -Recurse        
    }
}

if(Test-Path $DestDir)
{
   Get-ChildItem $DestDir -Recurse | Remove-Item -Force -Recurse 
} 
else
{
   throw "Release Content Path was not Shared/Configured"
}

if(Test-Path $Package_Destination_Path)
{
   $tmpPackDestPath = $Package_Destination_Path + '\*'
   Remove-Item $tmpPackDestPath -Recurse -Force
}

if(Test-Path $RelDir)
{
    $TempSourceDir = $RelDir + '\*'
    Copy-Item  $TempSourceDir $DestDir -Force -Recurse
    $TempServicePath = $DestDir + '\WindowsService'
    if(Test-Path $TempServicePath)
    {
       Remove-Item $TempServicePath -Recurse -Force
    }
}

$WindowsService = $RelDir + '\WindowsService\*'

if(Test-Path $WindowsService)
{
    if($WSProject -eq 'Lenovo')
    {
       New-Item -Name 'WindowsService' -ItemType Directory -Path $DestDir
       $NewDestDir = $DestDir + 'WindowsService'
    }
    else
    {
       New-Item -Name 'WindowsServices' -ItemType Directory -Path $DestDir
       $NewDestDir = $DestDir + 'WindowsServices'
    }
    Write-Host $NewDestDir

    if(Test-Path $NewDestDir)
    {
       Write-Host 'Copying windows Services'
       Copy-Item  $WindowsService $NewDestDir -Force -Recurse
       Write-Host 'Copying windows Services Completed'     
       Get-ChildItem $NewDestDir -Filter *.bat -Recurse  | Remove-Item -Recurse  

       #Crete Temp Folder for copying Domain dll
       $DomainTempDestDir = $NewDestDir + '\DomainAssemblies'
       New-Item -Name 'temp' -ItemType Directory -Path $DomainTempDestDir
       $SourceTempPath = $RelDir + '\WindowsService\DomainAssemblies\*'
       $ActualTempPath = $DomainTempDestDir + '\temp'
       
       Write-Host 'Source Temp Path:' $SourceTempPath
       Write-Host 'Actual Temp Path:' $ActualTempPath
       if(Test-Path $ActualTempPath)
       {
            Copy-Item  $SourceTempPath $ActualTempPath -Force -Recurse
       }
    }    
}
else
{
    New-Item -Name 'WindowsServices' -ItemType Directory -Path $DestDir
}

$PacakgePath = $DestDir + '\*'


New-Item -Name $ReleaseVersion -ItemType Directory -Path $Package_Destination_Path

$TempPackagePath = $Package_Destination_Path + '\' + $ReleaseVersion 

Copy-Item  $PacakgePath $TempPackagePath -Force -Recurse

#Barath's changes starts from here...


$ConfigPath = $TempPackagePath + '\Config'
$SourceConfigPath = "\\lwdelbuild-002\Scripts\Devops\ConfigSource"
$emptyJsonFile = "\\lwdelbuild-002\Scripts\Devops\ConfigSource\Config\App\AppSettings.Json"

# Check if source and destination folder paths exist
if (!(Test-Path -Path $SourceConfigPath)) {
    Write-Host "Config Source folder path '$SourceConfigPath' does not exist." -ForegroundColor Red
    exit
}
if (!(Test-Path -Path $ConfigPath)) {
    Write-Host "config's folder path '$ConfigPath' does not exist." -ForegroundColor Red
    exit
}

# Copy missing root folders instead of moving
$sourceFolderItems = Get-ChildItem -Path $SourceConfigPath -Directory

foreach ($item in $sourceFolderItems) {
    $itemName = $item.Name
    $destinationPath = Join-Path -Path $ConfigPath -ChildPath $itemName

    if (!(Test-Path -Path $destinationPath)) {
        Write-Host "Copying folder '$itemName' to destination."
        Copy-Item -Path $item.FullName -Destination $destinationPath -Recurse -Force
    } else {
        Write-Host "'$itemName' already exists in destination. Skipping..."
    }
}

# Check subfolders in the destination
$destinationFolderItems = Get-ChildItem -Path $ConfigPath -Directory

foreach ($destinationItem in $destinationFolderItems) {
    $rootFolder = $destinationItem.Name
    $sourceRootFolder = Join-Path -Path $SourceConfigPath -ChildPath $rootFolder

    $requiredSubfolders = @('App', 'JobServices', 'WebAPI')

    foreach ($subfolder in $requiredSubfolders) {
        $destinationSubfolderPath = Join-Path -Path $destinationItem.FullName -ChildPath $subfolder
        $sourceSubfolderPath = Join-Path -Path $sourceRootFolder -ChildPath $subfolder

        if (!(Test-Path -Path $destinationSubfolderPath)) {
            Write-Host "Copying subfolder '$subfolder' from '$sourceRootFolder' to '$destinationItem.FullName'."
            Copy-Item -Path $sourceSubfolderPath -Destination $destinationSubfolderPath -Recurse -Force
        } else {
            Write-Host "'$subfolder' already exists in '$destinationItem.FullName'. Skipping..."
        }

        # Add empty JSON file if subfolder is empty
        if ((Get-ChildItem -Path $destinationSubfolderPath).Count -eq 0) {
            Write-Host "Subfolder '$subfolder' is empty. Copying JSON file from '$emptyJsonFile' to '$destinationSubfolderPath'."
            Copy-Item -Path $emptyJsonFile -Destination (Join-Path -Path $destinationSubfolderPath -ChildPath "theJson.json") -Force
        }
    }
}

Write-Host "Configs Folder structure updated..."

#Barath's changes ends here...


if(Test-Path $Package_Destination_Path)
{
   ZipFolders $TempPackagePath $Package_Destination_Path\$ReleaseVersion.zip
}

if(Test-Path $TempPackagePath)
{
    $TempPackagePath = $Package_Destination_Path + '\' + $ReleaseVersion + '\'
    Remove-Item $TempPackagePath -Recurse -Force -Exclude '*.zip'
}