﻿#$EnvName - Config, Dev, INTSTAGING, PROD, QA, SAN, SIT, Staging, UAT
Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$WebandJobConfig,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$WebAPIConfig,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$EnvName,
[parameter (Mandatory=$true, position=3, ParameterSetName='Release')]
[string]$ReleasePath

)

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 

$ReleasePath = $ReleasePath + $currentDate + '\'

Write-Host "Drop Location: " $ReleasePath

# Web.config and Lw.WindowsServices.Exe.config files for Lessor Portal

if($WebandJobConfig -eq 'Y' -or $WebandJobConfig -eq 'y')
{
    $LPPath = $ReleasePath + 'LessorPortal/'
    $WSPath = $ReleasePath + 'WindowsService/'
    #UAT
    if($EnvName -eq 'UAT')
    {
        $UATApp = $ReleasePath + 'Config/UAT/App/*'
        $Include = "web.config"
        if(Test-Path $UATApp)
        {
            Copy-item -Path $UATApp $LPPath -Include $Include -Recurse -Force
        }
        $UATJob = $ReleasePath + 'Config/UAT/JobServices/*'
        $Include = "Lw.WindowsServices.exe.config"
        if(Test-Path $UATJob)
        {
            Copy-item -Path $UATJob $WSPath -Include $Include -Recurse -Force
        }        
    }

    #Config
    if($EnvName -eq 'Config')
    {
        $ConfigApp = $ReleasePath + 'Config/Config/App/*'
        $Include = "web.config"
        if(Test-Path $ConfigApp)
        {
            Copy-item -Path $ConfigApp $LPPath -Include $Include -Recurse -Force
        }
        $ConfigJob = $ReleasePath + 'Config/Config/JobServices/*'
        $Include = "Lw.WindowsServices.exe.config"
        if(Test-Path $ConfigJob)
        {
            Copy-item -Path $ConfigJob $WSPath -Include $Include -Recurse -Force
        }        
    }

    #INTSTAGING
    if($EnvName -eq 'INTSTAGING')
    {
        $INTSTAGINGApp = $ReleasePath + 'Config/INTSTAGING/App/*'
        $Include = "web.config"
        if(Test-Path $INTSTAGINGApp)
        {
            Copy-item -Path $INTSTAGINGApp $LPPath -Include $Include -Recurse -Force
        }
        $INTSTAGINGJob = $ReleasePath + 'Config/INTSTAGING/JobServices/*'
        $Include = "Lw.WindowsServices.exe.config"
        if(Test-Path $INTSTAGINGJob)
        {
            Copy-item -Path $INTSTAGINGJob $WSPath -Include $Include -Recurse -Force
        }        
    }

    #PROD
    if($EnvName -eq 'PROD')
    {
        $PRODApp = $ReleasePath + 'Config/PROD/App/*'
        $Include = "web.config"
        if(Test-Path $PRODApp)
        {
            Copy-item -Path $PRODApp $LPPath -Include $Include -Recurse -Force
        }
        $PRODJob = $ReleasePath + 'Config/PROD/JobServices/*'
        $Include = "Lw.WindowsServices.exe.config"
        if(Test-Path $PRODJob)
        {
            Copy-item -Path $PRODJob $WSPath -Include $Include -Recurse -Force
        }        
    }

    #QA
    if($EnvName -eq 'QA')
    {
        $QAApp = $ReleasePath + 'Config/QA/App/*'
        $Include = "web.config"
        if(Test-Path $QAApp)
        {
            Copy-item -Path $QAApp $LPPath -Include $Include -Recurse -Force
        }
        $QAJob = $ReleasePath + 'Config/QA/JobServices/*'
        $Include = "Lw.WindowsServices.exe.config"
        if(Test-Path $QAJob)
        {
            Copy-item -Path $QAJob $WSPath -Include $Include -Recurse -Force
        }        
    }

    #SAN
    if($EnvName -eq 'SAN')
    {
        $SANApp = $ReleasePath + 'Config/SAN/App/*'
        $Include = "web.config"
        if(Test-Path $SANApp)
        {
            Copy-item -Path $SANApp $LPPath -Include $Include -Recurse -Force
        }
        $SANJob = $ReleasePath + 'Config/SAN/JobServices/*'
        $Include = "Lw.WindowsServices.exe.config"
        if(Test-Path $SANJob)
        {
            Copy-item -Path $SANJob $WSPath -Include $Include -Recurse -Force
        }        
    }

    #SIT
    if($EnvName -eq 'SIT')
    {
        $SITApp = $ReleasePath + 'Config/SIT/App/*'
        $Include = "web.config"
        if(Test-Path $SITApp)
        {
            Copy-item -Path $SITApp $LPPath -Include $Include -Recurse -Force
        }
        $SITJob = $ReleasePath + 'Config/SIT/JobServices/*'
        $Include = "Lw.WindowsServices.exe.config"
        if(Test-Path $SITJob)
        {
            Copy-item -Path $SITJob $WSPath -Include $Include -Recurse -Force
        }        
    }

    #STAGING
    if($EnvName -eq 'STAGING')
    {
        $STAGINGApp = $ReleasePath + 'Config/STAGING/App/*'
        $Include = "web.config"
        if(Test-Path $STAGINGApp)
        {
            Copy-item -Path $STAGINGApp $LPPath -Include $Include -Recurse -Force
        }
        $STAGINGJob = $ReleasePath + 'Config/STAGING/JobServices/*'
        $Include = "Lw.WindowsServices.exe.config"
        if(Test-Path $STAGINGJob)
        {
            Copy-item -Path $STAGINGJob $WSPath -Include $Include -Recurse -Force
        }        
    }
    #Dev
    if($EnvName -eq 'Dev')
    {
        $DevApp = $ReleasePath + 'Config/Dev/App/*'
        $Include = "web.config"
        if(Test-Path $DevApp)
        {
            Copy-item -Path $DevApp $LPPath -Include $Include -Recurse -Force
        }
        $DevJob = $ReleasePath + 'Config/Dev/JobServices/*'
        $Include = "Lw.WindowsServices.exe.config"
        if(Test-Path $DevJob)
        {
            Copy-item -Path $DevJob $WSPath -Include $Include -Recurse -Force
        }        
    }
}
else
{
    $ConfigPath = $ReleasePath + 'Config/*'
    $exclude = "*WebAPI*"
    $Include = "web.config", "Lw.WindowsServices.exe.config"
    if(Test-Path $ConfigPath)
    {
        get-childitem $ConfigPath\*.* -recurse | where-object{$_.fullname -notlike $exclude} | Remove-Item -Include $Include -Recurse -Force
    }
}

# Web.config files for Web API

if($WebAPIConfig -eq 'Y' -or $WebAPIConfig -eq 'y')
{
    $APIPath = $ReleasePath + 'WebAPI/'
    #UAT
    if($EnvName -eq 'UAT')
    {
        $UATApp = $ReleasePath + 'Config/UAT/WebAPI/*'
        $Include = "web.config"
        if(Test-Path $UATApp)
        {
            Copy-item -Path $UATApp $APIPath -Include $Include -Recurse -Force
        }                
    }

    #Config
    if($EnvName -eq 'Config')
    {
        $ConfigApp = $ReleasePath + 'Config/Config/WebAPI/*'
        $Include = "web.config"
        if(Test-Path $ConfigApp)
        {
            Copy-item -Path $ConfigApp $APIPath -Include $Include -Recurse -Force
        }
    }

    #INTSTAGING
    if($EnvName -eq 'INTSTAGING')
    {
        $INTSTAGINGApp = $ReleasePath + 'Config/INTSTAGING/WebAPI/*'
        $Include = "web.config"
        if(Test-Path $INTSTAGINGApp)
        {
            Copy-item -Path $INTSTAGINGApp $APIPath -Include $Include -Recurse -Force
        }
    }

    #PROD
    if($EnvName -eq 'PROD')
    {
        $PRODApp = $ReleasePath + 'Config/PROD/WebAPI/*'
        $Include = "web.config"
        if(Test-Path $PRODApp)
        {
            Copy-item -Path $PRODApp $APIPath -Include $Include -Recurse -Force
        }                
    }

    #QA
    if($EnvName -eq 'QA')
    {
        $QAApp = $ReleasePath + 'Config/QA/WebAPI/*'
        $Include = "web.config"
        if(Test-Path $QAApp)
        {
            Copy-item -Path $QAApp $APIPath -Include $Include -Recurse -Force
        }
    }

    #SAN
    if($EnvName -eq 'SAN')
    {
        $SANApp = $ReleasePath + 'Config/SAN/WebAPI/*'
        $Include = "web.config"
        if(Test-Path $SANApp)
        {
            Copy-item -Path $SANApp $APIPath -Include $Include -Recurse -Force
        }                
    }

    #SIT
    if($EnvName -eq 'SIT')
    {
        $SITApp = $ReleasePath + 'Config/SIT/WebAPI/*'
        $Include = "web.config"
        if(Test-Path $SITApp)
        {
            Copy-item -Path $SITApp $APIPath -Include $Include -Recurse -Force
        }
    }

    #STAGING
    if($EnvName -eq 'STAGING')
    {
        $STAGINGApp = $ReleasePath + 'Config/STAGING/WebAPI/*'
        $Include = "web.config"
        if(Test-Path $STAGINGApp)
        {
            Copy-item -Path $STAGINGApp $APIPath -Include $Include -Recurse -Force
        }               
    }

    #Dev
    if($EnvName -eq 'Dev')
    {
        $DevApp = $ReleasePath + 'Config/Dev/WebAPI/*'
        $Include = "web.config"
        if(Test-Path $DevApp)
        {
            Copy-item -Path $DevApp $APIPath -Include $Include -Recurse -Force
        }               
    }
}
else
{
    $ConfigPath = $ReleasePath + 'Config/*'
    $exclude = "*WebAPI*"
    $Include = "web.config"
    if(Test-Path $ConfigPath)
    {
        get-childitem $ConfigPath\*.* -recurse | where-object{$_.fullname -like $exclude} | Remove-Item -Include $Include -Recurse -Force
    }
}