﻿Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Source,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Destination,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$Module,
[parameter (Mandatory=$false, position=3, ParameterSetName='Release')]
[string]$IsEMMLayer, 
[parameter (Mandatory=$false, position=4, ParameterSetName='Release')]
[string]$IsProjectCoreLayer

)

##  Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir = $Destination + $currentDate


##Lessorportal copy
if($Module -eq '1')  #Lessorportal
{
    $LessorPortal = $RelDir + '\LessorPortal\'
    if($IsEMMLayer -eq '1')
    {
        $Source1 = $Source + '\_PublishedWebsites\Lw.LessorPortal.Region\'
    }    
    elseif($IsProjectCoreLayer -eq '1')
    {
        $Source1 = $Source + '\_PublishedWebsites\Lw.LessorPortal.ProjectCore\'
    }
    else
    {
        $Source1 = $Source + '\_PublishedWebsites\Lw.LessorPortal.Project\'
    }
    
    
    write-host 'Starting lessorportal copy.'
    robocopy $Source1 $LessorPortal /E /copyall
    write-host 'Completed lessorportal copy.'

    $LWSource = $Source + '\Lw.LessorPortal.Project.Resource.dll'
    $LWRSource = $Source + '\Lw.LessorPortal.Region.Resource.dll'
    $LWPCRSource = $Source + '\Lw.LessorPortal.ProjectCore.Resource.dll'

    ## Copy Lw.LessorPortal.Project.Resource.dll
    
    $LWBin =  $LessorPortal + '\bin\'
    if(!([string]::IsNullOrEmpty($LWSource)) -and (Test-path $LWSource))
    {
      Copy-Item  $LWSource $LWBin
    }
    if(!([string]::IsNullOrEmpty($LWRSource)) -and (Test-path $LWRSource))
    {
      Copy-Item  $LWRSource $LWBin
    }
    if(!([string]::IsNullOrEmpty($LWPCRSource)) -and (Test-path $LWPCRSource))
    {
      Copy-Item  $LWPCRSource $LWBin
    }

   if($IsRegionLayer -eq '1')
   {
        
   }
   else
   {
       #Copy Config files to WebAPI
        $LessorPortalConnConfig = $RelDir + '\LessorPortal\ConnectionStrings.config'
        $LessorPortalAppConfig = $RelDir + '\LessorPortal\AppSettings.config'
   }

   $WebAPIPath = $RelDir + '\WebAPI\' 
   if(($LessorPortalConnConfig) -and (Test-path $LessorPortalConnConfig))
   {
       copy-item $LessorPortalConnConfig $WebAPIPath -Force 
   }
   if(($LessorPortalAppConfig) -and (Test-path $LessorPortalAppConfig))
   {
        copy-item $LessorPortalAppConfig $WebAPIPath -Force 
   }
   

   #Copy Config files to WindowService
   write-host 'Copy windowservice config files from lessorportal.'
   $WindowServicePath = $RelDir + '\WindowsService\' 
   if(($LessorPortalConnConfig) -and (Test-path $LessorPortalConnConfig))
   {
        copy-item $LessorPortalConnConfig $WindowServicePath -Force 
   }
   if(($LessorPortalAppConfig) -and (Test-path $LessorPortalAppConfig))
   {
        copy-item  $LessorPortalAppConfig $WindowServicePath -Force 
   }
   write-host 'Completed windowservice config files from lessorportal.'

   #copy WinSCP & WinSCPnet.dll to job
   write-host 'Starting WinSCP files'
   $WinSCP = $RelDir + '\LessorPortal\bin\WinSCP.exe'
   $WinSCPnet= $RelDir + '\LessorPortal\bin\WinSCPnet.dll'
   $WindowServicePath = $RelDir + '\WindowsService\'
   write-host $WinSCP $WindowServicePath
   if(Test-Path $WinSCP)
   {
       Copy-item $WinSCP $WindowServicePath -Force
   }
   if(Test-Path $WinSCPnet)
   {
       Copy-item $WinSCPnet $WindowServicePath -Force
   }
   write-host 'Completed WinSCP files'

   #Copy DomainAssembly DLL to WindowService
   write-host 'Copy windowsservice domainassembly DLL'
   $WindowServiceDomainAss = $RelDir + '\WindowsService\DomainAssemblies\'   
   $LessorPortalDomainAss = $RelDir + '\LessorPortal\DomainAssemblies\*.*'
   
   if (Test-path $WindowServiceDomainAss)
   {
        if (Test-path $LessorPortalDomainAss)
        {
            Copy-item $LessorPortalDomainAss  $WindowServiceDomainAss  -Force
            write-host 'Completed windowsservice domainassembly DLL'
        }
   }

    $LessorPortalPDB = $RelDir + '\LessorPortal\bin\Lw.Domain.Project.Extension.pdb'
        write-host '11'
        if (Test-path $LessorPortalPDB)
        {
            Copy-item $LessorPortalPDB  $WindowServicePath  -Force
            write-host 'Completed LessorPortal PDB files.'
            write-host '11.1'
        }


   #Copy leasewave to Customer portal
   $Leasewave = $RelDir + '\LessorPortal\'
   $CustomerPortal = $RelDir + '\CustomerPortal\' 
   #copy-item $LessorPortal $CustomerPortal -Force -Recurse
   robocopy $Leasewave $CustomerPortal /E /copyall

   #Copy leasewave to Vendor portal
   $VendorPortal = $RelDir + '\VendorPortal\' 
   #copy-item $LessorPortal $VendorPortal -Force -Recurse
   robocopy $Leasewave $VendorPortal /E /copyall


}

if($Module -eq '2')  #WebService
{
    $WebService = $RelDir + '\WebServices\'
    write-host 'Starting WebService copy.'
    robocopy $Source $WebService /E /copyall
    write-host 'Completed WebService copy.'
}

if($Module -eq '3')  #Reports
{
    $Reports = $RelDir + '\Reports\RDLs\'
    write-host 'Starting RDL copy.'
    robocopy $Source $Reports /E /copyall
    write-host 'Completed RDL copy.'

    #Copy DLL
    $reportDllpath = Split-Path $Source
    $reportDllpath
    $Helper = $RelDir + '\Reports\ReportHelper\'
    copy-item -Path "$reportDllpath\Lw.Domain.*ReportHelper*.dll" $Helper -Force -ErrorAction Ignore
   
    # only for EMM
    $DLLPath = $RelDir + '\LessorPortal\bin\'
    if(Test-Path $DLLPath\Lw.Domain.Region.Resource.dll)
    {
      copy-item -Path "$DLLPath\Lw.Domain.Region.Resource.dll" $Helper -Force -ErrorAction Ignore
      copy-item -Path "$DLLPath\Lw.Domain.Resource.dll" $Helper -Force -ErrorAction Ignore
    }
}

if($Module -eq '4')  #SQLScripts
{
    $SQLScripts = $RelDir + '\Database\DBScripts\'

    ##Validate Go Statement in SQL Scripts
    write-host "Startging to validate GO statement..."
    $SQLScriptPathDDL = $SQLScripts + 'DDL\*.sql'
    write-host $SQLScriptPathDDL
    $SQLFiles = Get-Item -Path $SQLScriptPathDDL

    for ($i=0; $i -lt $SQLFiles.Count; $i++) 
    {
        $outfile = $SQLFiles[$i].FullName
       $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
        write-host 'Printing last line of file -' $outfile +" - " + $SQLFileContent

        if($SQLFileContent -ne 'GO' -or $SQLFileContent -ne 'Go')
        {
          write-host "Please add GO statement at the end of file - " + $outfile
          exit -1
        }
    }
    
    $SQLScriptPathDML = $SQLScripts + 'DML\*.sql'
    $SQLFiles = Get-Item -Path $SQLScriptPathDML

    for ($i=0; $i -lt $SQLFiles.Count; $i++) 
    {
        $outfile = $SQLFiles[$i].FullName
       $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
        write-host $outfile +" - " + $SQLFileContent

        if($SQLFileContent -ne 'GO' -or $SQLFileContent -ne 'Go')
        {
          write-host "Please add GO statement at the end of file - " + $outfile
          exit -1
        }
    }

    write-host 'Starting SQL scripts copy.'
    robocopy $Source $SQLScripts /E /copyall
    write-host 'Completed SQL scripts copy.'
}

if($Module -eq '4.1')  #CoreSQLScripts
{
    $SQLScripts = $RelDir + '\Database\DBScripts\'
    write-host 'Starting Core SQL scripts copy.'
    write-host 'Source path ' + $Source
    write-host 'Destination path '$SQLScripts

    Copy-Item $Source $SQLScripts 
    write-host 'Completed SQL scripts copy.'


}

if($Module -eq '5')  #COpy Product Dlls
{
    $LessorPortalbin = $RelDir + '\LessorPortal\bin'
    write-host 'Starting product dll copy.'
    copy-Item $Source $LessorPortalbin -Include 'Lw.Domain.*.dll' -verbose
    write-host 'Completed product dll copy.'

}

if($Module -eq '6')  #UserManual
{
    $UserManual = $RelDir + '\UserManual'
   
    write-host 'Starting UserManual copy.'
    robocopy $Source $UserManual /E /copyall
    write-host 'Completed UserManual copy.' 

}

if($Module -eq '7')  #PricingService
{
    $PricingService = $RelDir + '\PricingService\'
    write-host 'Starting PricingService copy.'
    robocopy $Source $PricingService /E /copyall
    write-host 'Completed PricingService copy.'
}

if($Module -eq '9')  #Config Cleanup
{
    write-host 'Starting Config Cleanup'
    Get-ChildItem –Path $RelDir -Recurse -Filter *.config | Remove-Item -Force
    write-host 'Completed Config Cleanup'
}

if($Module -eq '10')  #SSIS Packages
{
    $SSISPackages = $RelDir + '\SSISPackages\'
    write-host 'Starting SSIS Packages copy.'
    write-host 'Source SSIS Package path ' $Source
    write-host 'Destination SSIS Package path ' $SSISPackages
    robocopy $Source $SSISPackages /E /copyall
    write-host 'Completed SSIS Packages copy.'
}



if (($lastexitcode -lt 8) -or ($lastexitcode -eq 16))
  { $lastexitcode = 0 }
