param(
   $packagePath
)

write-host 'Started unlocking RDL and DLL files.'

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$packagePath = $packagePath + "\" + $currentDate + "\"

$RPTPath1= $packagePath +'Reports\RDLs\'

if(Test-Path $RPTPath1)
{
$path1 = $packagePath +'Reports\RDLs\*.rpt'
dir $path1 | Unblock-File
write-host 'Successfully completed unlocking RDL files.'
}
else
{
 write-host 'Reports\RDLs folder not found. Skipping Unlocking step'
}

$RPTPath= $packagePath +'Reports\ReportHelper\'
if(Test-Path $RPTPath)
{
$path = $packagePath +'Reports\ReportHelper\*.dll'
dir $path | Unblock-File
write-host 'Successfully completed unlocking DLL files.'
}
else
{
 write-host 'Reports\ReportHelper folder not found. Skipping Unlocking step'
}


