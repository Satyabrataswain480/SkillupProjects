$timeStamp = Get-Date -format yyyy_MM_dd_HHmmss
$psLogpath = ##PSLOGPATH##

$Project = ##PROJECT##
$psLogFileName = "$psLogpath\$Project" +'_'+ $timeStamp+"_log.txt"
Start-Transcript -Append $psLogFileName
$LocalhostPort = ##PORT##
$OTCollectionname = ##COLLECTIONNAME##
$instanceId = ##INSTANCEID##
$RequiredSQLCoverReport = '0'
$packagesFolder = ''
$ReportOutputPath = ''
$database = ''
$databaseserver = ''
$PackageReference = ''
$BusinessUnit = 'defaultBU#'
$apiUrl = ##APIURL##
$dashboardProjectName = ##REALPROJECTNAME##
$IsZephyrChangeRequired = ##ZephyrChange##



$WebApplicationurl = 'http://localhost:' +  $LocalhostPort
$OTRunName = $Project + 'DotCover'
$OTScenarioCollectionName = $OTCollectionname


$otRequired = 'n'
$runUnitTest = 'n'
$merge = 'n'
$mergeReport= 'n'
$xmlReport = 'n'


function encryptKey($plaintext){
    
    $plainBytes = [System.Text.Encoding]::UTF8.GetBytes($plaintext)
    $publicKey="<RSAKeyValue><Modulus>u/+n2bHHccEVCZ6USiENsWb8Nl9YtTICf1nv62UQiv4kynsrAAgysUuE5IsnoYb1XfcTgjLEa3riUP0WoOIIBi4MfDSWgpPTglYjwCxovF5GU3cAiBBN28q6w/d1dQqaPJ1kUyRSCkYjaH7l2Pq3AO+bjFRsWz1VyR8m4WBtB0U=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
    $provider=[System.Security.Cryptography.RSACryptoServiceProvider]::new(1024) 
    $provider.PersistKeyInCsp = $false;
    $provider.FromXmlString($publicKey)
    $cipher=$provider.Encrypt($plainBytes,$true)
    return [System.Convert]::ToBase64String($cipher)
 }


function Run-OTScenarios{
param(
  [string]$OTExe, [string]$OTRunName, [string]$WebApplicationurl, [string]$OTWorkspace, [string]$OTScenarioCollectionName, [string]$userName, [string]$password, [string]$bu, [string]$project, [string]$sharedPath
)

    try
    {
        $OTLogsFolder = "E:\DoNotDelete\DotCoverAutomation\OTLogs"
        Write-Host "With runname as $OTRunName going to start on $WebApplicationurl under workspace $OTWorkspace to run collection named $OTScenarioCollectionName"
         
        $arguments = "-Operation Execute -DeploymentPath $WebApplicationurl -WorkingDirectory $OTWorkspace -Scenarios $OTScenarioCollectionName -Collection true -RunName $OTRunName -LogsFolder $OTLogsFolder"

        if($bu -ne 'defaultBU#') {
          $arguments = $arguments + " -UserName $userName -Password $password -BusinessUnit $bu"
        }
        if($IsZephyrChangeRequired -eq 'true') {
          $arguments = $arguments + " -UpdateExecutionToZephyr false -ZephyrTestCycleKey """
        }

        Write-Host $OTExe
        Write-Host $arguments
        Start-Process $OTExe $arguments -Wait

        write-host "OTScenarios Completed" -f Green
        Start-Sleep -Seconds 30
        $params = @{
            "projectName"=$project;
            "runName"=$OTRunName;
            "sharedPath"=$sharedPath;
        }
        $uri='http://lwdelbuild-001:8090/ot/create'
        $body = ConvertTo-Json -InputObject $params
        $body
        Invoke-WebRequest -Headers @{"Content-Type" = "application/json"} -Uri $uri -Method POST -Body $body
    }
    catch
    {
      Write-Host "An error occurred:"
      Write-Host $_
      Kill-Process 'dotcover'
      Kill-IISExpress
      Kill-Jobs
    }
}

function Dot-Cover{
param([string]$project,[string]$xmlLocation, [string]$type, [string]$jobName='NONE')

    $exeloc = "E:\DoNotDelete\DotCoverAutomation\dotCover\dotCover.exe"
    try
    {
        if($jobName -eq 'NONE'){
            $name = $project+"_DotCover_"+$type
        }else{
            $name = $jobName
        }
        Start-Job -Name $name -ScriptBlock{
            param([string]$exeloc, [string]$xmlLocation, [string]$type)
            Set-Alias dotCover $exeloc
            if($type -eq 'cover'){
                dotCover c $xmlLocation
            }elseif($type -eq 'merge'){
                dotCover m $xmlLocation
            }else{
                dotCover r $xmlLocation
            }
        } -ArgumentList $exeloc, $xmlLocation, $type

        Start-Sleep -Seconds 180
        Write-Host "$xmlLocation : $type"
        $job = Receive-Job -Name $name
        Write-Host $job
    }  
    catch
    {
        Write-Host "An error occurred:"
        Write-Host $_
        Kill-Process 'dotcover'
        Kill-IISExpress
        Kill-Jobs
    }
}

function Kill-DotCover-And-Generate-Report{
param([string]$project,[string]$instanceId,[string]$xmlLocation )
    
    Set-Alias dotCover "E:\DoNotDelete\DotCoverAutomation\dotCover\dotCover.exe"
    dotCover s --Instance=$instanceId --Command=GetSnapshotAndKillChildren
    Dot-Cover -project $project -xmlLocation $xmlLocation -type 'report'
    #dotCover s --Instance=1 --Command=GetSnapshotAndKillChildren
    #dotcover r $xmlLocation

    $jobName = $Project+"_DotCover_report"
    Wait-Job $jobName
    Start-Sleep -Seconds 10
}

function Kill-Process{
param([string] $processName)
    Get-Process | where {$_.Name -match $processName} | Kill -Force
}

function Kill-IISExpress{
    Get-Process | where {$_.Name -match "IISExpress"} | Kill -Force
}

function Kill-Jobs{
    Remove-Job -State Completed
    Remove-Job -State Blocked
    Remove-Job -State Failed
    Remove-Job -State Stopped
}

function SQLCoverExport-HtmlReport{
	param(        
        [SQLCover.CoverageResult] $result
        ,[string]$outputPath
		,[string]$reportGeneratorPath
    )
	
	New-Item -Type Directory -Force -Path $outputPath | out-Null
	
	$xmlPath = Join-Path -Path $outputPath -ChildPath "Coverage.opencoverxml"
    $result.OpenCoverXml() | Out-File $xmlPath
    $result.SaveSourceFiles($outputPath) 
	
	$report = "-reports:$xmlPath"
    $targetDir = "-targetDir:$outputPath" 
    $args = $report, $targetDir
    Start-Process -FilePath $reportGeneratorPath -ArgumentList $args -WorkingDirectory $outputPath -Wait
    Write-Verbose "Coverage Report Written to: $outputPath"
}

function UpdateDashboard{
param($project, $basePath, $reportName, $apiUrl)

	$params = @{
	  "projectName"= $project;
	  "basePath"= $basePath;
	  "reportName"= $reportName;
	}
	$body = ConvertTo-Json -InputObject $params
$body

	Invoke-WebRequest -Headers @{"Content-Type" = "application/json"} -Uri $apiUrl -Method POST -Body $body
}

function ReadConfigAndUpdate()
{
param($project, $path, $apiUrl)
	$servername = $env:COMPUTERNAME
	$xml = [xml](Get-Content "$path")

	# Get the Output element value
	$outputPath = $xml.ReportParams.Output

	# Split the Output path into base path and filename
	$basePath = [System.IO.Path]::GetDirectoryName($outputPath)
	$filename = [System.IO.Path]::GetFileName($outputPath)

	$restOfPath = $basePath.Substring(3)
	$networkBasePath = "\\$serverName\$restOfPath"
	UpdateDashboard $project $networkBasePath $filename $apiUrl
}

#VARIABLES
$iisExpressConfigRoot = ##iisExpressConfigRoot##
$reportConfig_OT = ##reportConfig_OT##

$unitTestConfig = ##unitTestConfig##
$mergeConfig = ##mergeConfig##
$unitTestReportConfig = ##unitTestReportConfig##
$mergeReportConfig = ##mergeReportConfig##
$xmlReportConfig = ##xmlReportConfig##
$OTWorkspace = ##OTWorkspace##
$OTExe = ##OTEXE##

$projectPath = ##projectPath##


#LOGIC
if(Test-Path $iisExpressConfigRoot){
    $otRequired = 'y'
}else{
    Write-Host "Skipping Dotcover execution on OT. File Missing: $iisExpressConfigRoot" -f Yellow
}
if(Test-Path $unitTestConfig){
    $runUnitTest = 'y'
}else{
    Write-Host "Skipping Dotcover execution on Unit Test Cases. File Missing: $unitTestConfig" -f Yellow
}
if(Test-Path $mergeConfig){
    $merge = 'y'
}else{
    Write-Host "Skipping report merge. File Missing: $mergeConfig" -f Yellow
}
if(Test-Path $mergeReportConfig){
    $mergeReport = 'y'
}else{
    Write-Host "Skipping merged report generation. File Missing: $mergeReportConfig" -f Yellow
}
if(Test-Path $xmlReportConfig){
    $xmlReport = 'y'
}else{
    Write-Host "Skipping merged report generation. File Missing: $xmlReportConfig" -f Yellow
}


$vsPath1 = $projectPath + "\.vs" 
$vsPath2 = $projectPath + "\Lw.LessorPortal.Project\.vs" 
$tfPath = $projectPath + "\`$tf"
if(Test-Path $vsPath1){
    Remove-Item $vsPath1 -Force -Recurse
}if(Test-Path $vsPath2){
    Remove-Item $vsPath2 -Force -Recurse
}if(Test-Path $tfPath){
    Remove-Item $tfPath -Force -Recurse
}

$coverage = 'n'

if($RequiredSQLCoverReport -eq '1')
{
    if($PackageReference -eq '1')
    {
        $packagesFolder = 'C:\Users\devops.admin\.nuget\packages\'
        $SQLCover = Join-Path $packagesFolder -ChildPath "GOEddie.SQLCover\0.5.0\lib\SqlCover.dll"
	    $ReportGenerator = Join-Path $packagesFolder -ChildPath "ReportGenerator\4.8.13\tools\net47\ReportGenerator.exe"
    }
    else
    {
        $SQLCover = Join-Path $packagesFolder -ChildPath "GOEddie.SQLCover.0.5.0\lib\SqlCover.dll"
	    $ReportGenerator = Join-Path $packagesFolder -ChildPath "ReportGenerator.4.8.13\tools\net47\ReportGenerator.exe"
    }
    	
	
	Add-Type -Path $SQLCover
	
	$objectFilters = "^\[dbo\].\[Save.*\]$" , 'Security'
	#$objectFilters = 'dbo', 'Security'
	#$objectFilters = $null
	$queryTimeout = 60
	$debugLogging = $false
	$connectionString = "server=$($databaseserver);initial catalog=$($database);integrated security=sspi"
	$coverage = new-object SQLCover.CodeCoverage($connectionString, $database, $objectFilters, $debugLogging)
	$coverage.Start()
    write-host "SQL Cover Started..."
}


if($otRequired -eq 'y'){
    Write-Host "Starting dotcover..." -f Green
    Dot-Cover -project $Project -xmlLocation $iisExpressConfigRoot -type 'cover'
    Write-Host "Starting OT execution..." -f Green

     $userName = ##USERNAME##
     $password = encryptKey(##PASSWORD##)

    Run-OTScenarios -OTExe $OTExe -OTRunName $OTRunName -WebApplicationurl $WebApplicationurl -OTWorkspace $OTWorkspace -OTScenarioCollection $OTScenarioCollectionName -userName $userName -password $password -bu $BusinessUnit -project $dashboardProjectName -sharedPath "\\lwdelbuild-002\DoNotDelete\DotCover\$project\Site"
    Write-Host "Starting Report Generation..." -f Green
    Kill-DotCover-And-Generate-Report -project $Project -instanceId $instanceId -xmlLocation $reportConfig_OT
}
if($runUnitTest -eq 'y'){
    Write-Host "Starting dotcover for unit test cases..." -f Green
    $jobName = $Project+"_DotCover_cover_UT"
    Dot-Cover -project $Project -xmlLocation $unitTestConfig -type 'cover' -jobName $jobName
    Wait-Job -Name $jobName
    
    Write-Host "Starting dotcover report generation..." -f Green
    $jobName = $Project+"_DotCover_report_UT"
    Dot-Cover -project $Project -xmlLocation $unitTestReportConfig -jobName $jobName -type 'report'
    Wait-Job -Name $jobName
    Write-Host "Reports generated" -f Green
}

if($merge -eq 'y'){
    Write-Host "Starting dotcover merge..." -f Green
    $jobName = $Project+"_DotCover_merge_UT"
    Dot-Cover -project $Project -xmlLocation $mergeConfig -type 'merge' -jobName $jobName
    Wait-Job -Name $jobName
}

if($mergeReport -eq 'y'){
    Write-Host "Starting dotcover merge..." -f Green
    $jobName = $Project+"_DotCover_merge_Report"
    Dot-Cover -project $Project -xmlLocation $mergeReportConfig -type 'report' -jobName $jobName
    Wait-Job -Name $jobName
}
if($xmlReport -eq 'y'){
    Write-Host "Starting dotcover xml report generation..." -f Green
    $jobName = $Project+"_DotCover_xml_Report"
    Dot-Cover -project $Project -xmlLocation $xmlReportConfig -type 'report' -jobName $jobName
    Wait-Job -Name $jobName
}

if($mergeReport -eq 'y'){
	ReadConfigAndUpdate $dashboardProjectName $mergeReportConfig $apiUrl
}elseif($mergeReport -eq 'n' -and $runUnitTest -eq 'y'){
	ReadConfigAndUpdate $dashboardProjectName $unitTestReportConfig $apiUrl
}else{
	ReadConfigAndUpdate $dashboardProjectName $reportConfig_OT $apiUrl
}
if($xmlReport -eq 'y'){
    ReadConfigAndUpdate $dashboardProjectName $xmlReportConfig 'http://lwdelbuild-001:8090/codecoverage/CreateCodeCoverageStatementRecords'
}

if($RequiredSQLCoverReport -eq '1')
{
    if($PackageReference -eq '1')
    {
        $packagesFolder = 'C:\Users\devops.admin\.nuget\packages\'        
	    $SQLCover = Join-Path $packagesFolder -ChildPath "GOEddie.SQLCover\0.5.0\lib\SqlCover.dll"
	    $ReportGenerator = Join-Path $packagesFolder -ChildPath "ReportGenerator\4.8.13\tools\net47\ReportGenerator.exe"
    }
    else
    {
        $SQLCover = Join-Path $packagesFolder -ChildPath "GOEddie.SQLCover.0.5.0\lib\SqlCover.dll"
	    $ReportGenerator = Join-Path $packagesFolder -ChildPath "ReportGenerator.4.8.13\tools\net47\ReportGenerator.exe"
    }
	$coverageResults = $coverage.Stop()
	SQLCoverExport-HtmlReport $coverageResults $ReportOutputPath $ReportGenerator
    write-host "SQL Cover COmpleted..."
}

Kill-Jobs


#add timeouts on waiting jobs
#ot -> is it possible to create new project using cmd?
#ot -> ot not running under internal job
