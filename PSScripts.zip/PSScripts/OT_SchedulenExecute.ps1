param(
$server,
$taskName,
$basePath
)

Invoke-Command -ComputerName $server -ScriptBlock {
    function ChangeToLocalPath{
        param($path)
        Write-Host $path
        $url = [System.Uri]::new($path)
        $p = $url.AbsolutePath.Remove(0,1).Replace("/","\").Replace("$",":")
        return $p
        #return $path
    }

    function CreateNRunScheduledTask{
        param([string]$taskName, [string]$basePath)

        
        $exe = 'powershell'
        $basePath = ChangeToLocalPath $basePath
        $arg = "$basePath\OdessaTestTemplate.ps1"

        $task = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Ignore

        if($task){
              Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        }
        
        $taskAction = New-ScheduledTaskAction -Execute $exe -Argument "-File $arg"
        
        Register-ScheduledTask -TaskName $taskName -Action $taskAction -User 'ODESSAPDC01\devops.admin' -Password 'Password@123'
        
        
        Start-ScheduledTask -TaskName $taskName
    }

    CreateNRunScheduledTask $using:taskName $using:basePath
}