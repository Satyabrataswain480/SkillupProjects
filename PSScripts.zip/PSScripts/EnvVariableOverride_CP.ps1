﻿param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='release')]
    [string]$ReleaseVersion,
    [parameter(Mandatory=$true, position=2, ParameterSetName='release')]
    [string]$Env,
    [parameter(Mandatory=$true, position=3, ParameterSetName='release')]
    [string]$proj,
    [parameter(Mandatory=$false, position=4, ParameterSetName='release')]
    [string]$Portal
    #varibale for env 0 staging , 1 prod , 2 devint , 3 sandbox
    )

#More than one approved release request check for past dates
$moreThanOneApproveQuery = "select a.* from Releases a , Projects b , ProjectReleaseMappings c , ApplicationReleaseMappings arm, Applications d
where a.Id = arm.ReleaseId and arm.ApplicationId = d.Id and  d.ApplicationName ='$Portal' and c.ProjectId = b.Id and a.Id = c.ReleaseId and
 b.ProjectNickName = '$proj' and a.ReleaseStatus = 'Approved' and a.CloudOpsReleaseDate < (SELECT CONVERT(varchar, GETDATE(), 23) AS TodayDate)"

$moreThanOneApprove = Invoke-Sqlcmd -ServerInstance 'LWDELBUILD-001\SQL2019' -Database 'Odessa_Dashboard_Prod' -Query $moreThanOneApproveQuery -QueryTimeout 65500 -ErrorAction Stop

if($moreThanOneApprove.Count -gt 0){

Write-Host "For $proj project previous releases are in Approved State. Please contact Devops team to update"

}

if($Env -eq '0'){

   $releaseDetailQuery = "select a.* from Releases a , Projects b , ProjectReleaseMappings c , ApplicationReleaseMappings arm, Applications d
where a.Id = arm.ReleaseId and arm.ApplicationId = d.Id and  d.ApplicationName ='$Portal' and c.ProjectId = b.Id and a.Id = c.ReleaseId and
 b.ProjectNickName = '$proj' and a.ReleaseVersion = '$ReleaseVersion' and a.ReleaseStatus in ('Approved','Packaged','Completed') and a.EnvName in ('UAT','Staging','UAT Hotfix','Staging Hotfix')"

}
elseif($Env -eq '1'){

   $releaseDetailQuery = "select a.* from Releases a , Projects b , ProjectReleaseMappings c, ApplicationReleaseMappings arm, Applications d 
where a.Id = arm.ReleaseId and arm.ApplicationId = d.Id and  d.ApplicationName ='$Portal' and c.ProjectId = b.Id and a.Id = c.ReleaseId and
 b.ProjectNickName = '$proj' and a.ReleaseVersion = '$ReleaseVersion' and a.ReleaseStatus in ('Approved','Packaged','Completed') and a.EnvName in  ('Production Hotfix')"

}
elseif($Env -eq '2'){
   
   $releaseDetailQuery = "select a.* from Releases a , Projects b , ProjectReleaseMappings c, ApplicationReleaseMappings arm, Applications d
where a.Id = arm.ReleaseId and arm.ApplicationId = d.Id and  d.ApplicationName ='$Portal' and c.ProjectId = b.Id and a.Id = c.ReleaseId and
 b.ProjectNickName = '$proj' and a.ReleaseVersion = '$ReleaseVersion' and a.ReleaseStatus in ('Approved','Packaged','Completed') and a.EnvName in  ('Dev Int')"

}
elseif($Env -eq '3'){
   
   $releaseDetailQuery = "select a.* from Releases a , Projects b , ProjectReleaseMappings c, ApplicationReleaseMappings arm, Applications d
where a.Id = arm.ReleaseId and arm.ApplicationId = d.Id and  d.ApplicationName ='$Portal' and c.ProjectId = b.Id and a.Id = c.ReleaseId and
 b.ProjectNickName = '$proj' and a.ReleaseVersion = '$ReleaseVersion' and a.ReleaseStatus in ('Approved','Packaged','Completed') and a.EnvName in  ('Sandbox')"

}

#need to add approved condition and ReleaseVersion variuable and project Name/ID , same version can be for different portall
#$releaseDetailQuery = "select * from ReleaseRequests where ReleaseVersion = '$ReleaseVersion'"

$releaseDetailQuery

$releaseDetails = Invoke-Sqlcmd -ServerInstance 'LWDELBUILD-001\SQL2019' -Database 'Odessa_Dashboard_Prod' -Query $releaseDetailQuery -QueryTimeout 65500 -ErrorAction Stop

#Need to add check condition 
if(([string]::IsNullOrEmpty($releaseDetails))){
  Write-Error "The Release request for release version $ReleaseVersion is not Approved/Packaged/Completed"
  exit 1
}


#*****************************************Get Basic Values*********************************************

#1. CO Ticket
$coTicket = $releaseDetails.CloudOpsTicket
$coTicket
Write-Host ("##vso[task.setvariable variable=COTicket]$coTicket")


#2. ReleaseDate
$releaseDate = $releaseDetails.CloudOpsReleaseDate
#$releaseDate = $releaseDate.ToString("dd/MMM/yyyy", [System.Globalization.CultureInfo]::InvariantCulture)
$releaseDate
Write-Host ("##vso[task.setvariable variable=ReleaseDate]$releaseDate")


#3. ReleaseTime
$releaseTime = $releaseDetails.CloudOpsReleaseTime
$releaseTime
Write-Host ("##vso[task.setvariable variable=ReleaseTime]$releaseTime")


#*****************************************Get Module Values********************************************
$id = $releaseDetails.Id

$moduleDetailsQuery = "select a.* from Services a , ServiceReleaseMappings b , Releases c 
where a.Id = b.ServiceId and b.ReleaseId = c.Id and b.IsChecked = 1 and c.Id = '$id'"
$moduleDetailsQuery

$moduleDetails = Invoke-Sqlcmd -ServerInstance 'LWDELBUILD-001\SQL2019' -Database 'Odessa_Dashboard_Prod' -Query $moduleDetailsQuery -QueryTimeout 65500 -ErrorAction Stop

# Store all the 'Name' values in a variable
$names = $moduleDetails.ApplicationServicenName
$names

#1. AppSettingsConfig
$appSettingsConfig = if ($names.Contains('AppSettingsConfig')) { 'Y' } else { 'N' }
$appSettingsConfig
Write-Host ("##vso[task.setvariable variable=AppSettingsConfig]$appSettingsConfig")

#2. CustomerPortal
$customerPortal = if ($names.Contains('CustomerPortal')) { 'Y' } else { 'N' }
$customerPortal
Write-Host ("##vso[task.setvariable variable=CustomerPortal]$customerPortal")

#3. Database
$database = if ($names.Contains('Database')) { 'Y' } else { 'N' }
$database
Write-Host ("##vso[task.setvariable variable=Database]$database")

#4. Reports
$reports = if ($names.Contains('Reports')) { 'Y' } else { 'N' }
$reports
Write-Host ("##vso[task.setvariable variable=Reports]$reports")

#5. WebandJobConfig
$webandJobConfig = if ($names.Contains('WebJobConfig')) { 'Y' } else { 'N' }
$webandJobConfig
Write-Host ("##vso[task.setvariable variable=WebandJobConfig]$webandJobConfig")

#6. WindowsService
$windowsService = if ($names.Contains('WindowsService')) { 'Y' } else { 'N' }
$windowsService
Write-Host ("##vso[task.setvariable variable=WindowsService]$windowsService")

#7. PartnerPortal
$partnerPortal = if ($names.Contains('PartnerPortal')) { 'Y' } else { 'N' }
$partnerPortal
Write-Host ("##vso[task.setvariable variable=PartnerPortal]$partnerPortal")
