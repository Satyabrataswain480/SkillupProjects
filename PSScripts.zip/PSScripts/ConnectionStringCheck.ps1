﻿param (
    [Parameter(Mandatory = $true)]
    [string]$dbName,
    [Parameter(Mandatory = $true)]
    [string]$buildPath
)

$connectionPath = $buildPath + "_PublishedWebsites\Lw.LessorPortal.Project\ConnectionStrings.config"

$fileContent = Get-Content -Path $connectionPath -Raw
$xml = [xml]$fileContent
$connectionString = $xml.connectionStrings.add | Where-Object { $_.name -eq "LeasewaveRepository" }
$initialCatalog = $connectionString.connectionString.Split(';') | Where-Object { $_ -like "Initial Catalog*" } | ForEach-Object { $_.Split('=')[1] }


Write-Host 'Connection String DB name = ' $initialCatalog
Write-Host 'Expected DB name = ' $dbName


if ($initialCatalog -eq $dbName) {

    Write-Host  $initialCatalog '=' $dbName
    Write-Output "Connection String DB is matching with the Expected DB name."
} 
else {

    Write-Host  $initialCatalog '!=' $dbName
    Write-Error "Connection String DB do not match with the Expected DB name. Please Correct your ConnectingString"
}
