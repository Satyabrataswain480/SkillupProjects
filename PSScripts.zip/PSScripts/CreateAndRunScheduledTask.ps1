param(
    $server,
    $taskName,
    $exe,
    $arg    
)

$server
Invoke-Command -ComputerName $server -ScriptBlock{
    function CreateNRunScheduledTask{
        param([string]$taskName, [string]$exe, [string]$arg)

        $taskName
        $exe
        $arg

        $task = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Ignore

        if($task){
              Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        }
        
        $taskAction = New-ScheduledTaskAction -Execute $exe -Argument "-File $arg"
        
        Register-ScheduledTask -TaskName $taskName -Action $taskAction -User 'ODESSAPDC01\devops.admin' -Password 'Password@123'
        
        
        Start-ScheduledTask -TaskName $taskName
    }

    CreateNRunScheduledTask $using:taskName $using:exe $using:arg

}