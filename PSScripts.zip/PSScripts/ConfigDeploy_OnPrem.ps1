﻿param(
    [string] $packagePath ,  # \\lwdelbuild-002\DropLocation\Lenovo_Drop\Dev\
    $env # Dev
)

if(Test-path $packagePath)
{    
    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
    $packagePath = $packagePath + $currentDate + '\Config\'
    #write-host $packagePath

    $packagePath = $packagePath + $env + '\ConfigModifications.config'

    if (!(Test-Path $packagePath)) { 
    Write-error "ConfigModifications $packagePath does not exist."
    return
}

Write-host 'ConfigModifications File Path :' $packagePath

#Clear-Host
$XMLfile = $packagePath

$exists = Test-Path $XMLfile
$exists
if($exists -eq $False)
{
$XMLfile
    Write-Host 'Skipping...'
    return
}


[XML]$config = Get-Content $XMLfile


   
    ## Deletion
    foreach($e in $config.rootEntity.deletions.delete)
    {
    write-host 'DELETE operation in progress...'
	$configFilePath = $e.targetFile
	$p = "Deleting a tag in " + $configFilePath + " named " + $e.tag +" with attribute named "+ $e.withAttribute
	write-host $p
	
    
    $exists = Test-Path $configFilePath
    if($exists -eq $False)
    {
        write-host "$($e.targetFile) not found . Skipping..." -f Gray
        continue;
    }
    [XML]$webconfig = Get-Content $configFilePath

    if($e.uniqueTag)
    {
        $findTag = "//$($e.uniqueTag)"
        $node = $webconfig.SelectSingleNode($findTag)
        $node.ParentNode.RemoveChild($node)
    }
    else
    {
        $findTag = "//$($e.tag)"+"[@$($e.withAttribute)"+"="+'"'+$($e.whoseValue)+'"'+"]"
        $node = $webconfig.SelectSingleNode($findTag)
        $node.ParentNode.RemoveChild($node)
    }
    $webconfig.Save($configFilePath)

    write-host 'DELETE operation completed...'
}
    
    ## Addition
    foreach($c in $config.rootEntity.additions.addNode)
    {
    write-host 'ADD operation in progress...'
	$configFilePath = $c.targetFile
	$p =  "Adding a tag in "+ $configFilePath +" under the parent tag "+ $c.under
	write-host $p

    
    $exists = Test-Path $configFilePath
    if($exists -eq $False)
    {
        write-host "$($c.targetFile) not found . Skipping..." -f Gray
        continue;
    } 
    [XML]$webconfig = Get-Content $configFilePath

    [xml]$xml = '<root>'+$c.InnerText+'</root>'
    $node = $webconfig.SelectSingleNode("//$($c.under)")
    foreach($e in $xml.root.ChildNodes.GetEnumerator())
    {
        $node.AppendChild($webconfig.ImportNode($e, $true))
    }
    $webconfig.Save($configFilePath)

    write-host 'ADD operation completed...'
}
    
    ## Update
    foreach($d in $config.rootEntity.modifications.modify)
    {
        write-host 'UPDATE operation in progress...'
	    $configFilePath = $d.targetFile
    
        $exists = Test-Path $configFilePath
        if($exists -eq $False)
        {
            Write-Host $configFilePath
            write-host "$($d.targetFile) not found . Skipping..." -f Gray
            continue;
        }
        [XML]$webconfig = Get-Content $configFilePath

        [xml]$xml = '<root>'+$d.InnerText+'</root>'
		if($d.uniqueTag)
		{
            $p = "Updating an unique tag named "+ $d.uniqueTag + " in "+ $configFilePath 
	        write-host $p   
			$findTag = "//$($d.uniqueTag)"
		}
		else{
            $p = "Updating a tag in "+ $configFilePath +" named "+ $d.tag +" with attribute named "+ $d.withAttribute + " whose value "+$d.whoseValue
	        write-host $p
			$findTag = "//$($d.tag)"+"[@$($d.withAttribute)"+"="+'"'+$($d.whoseValue)+'"'+"]"
		}

		$node = $webconfig.SelectSingleNode($findTag)
        
        if($d.uniqueTag)
        {
            $node.RemoveAll()
        }
        else
        {
            $parent = $node.ParentNode
		    $parent.RemoveChild($node)
            $node = $parent
        }
 
        if($xml.root.ChildNodes)
        {
            foreach($e in $xml.root.ChildNodes.GetEnumerator())
            {
                $node.AppendChild($webconfig.ImportNode($e, $true))
            }
        }
        $webconfig.Save($configFilePath)

        write-host 'UPDATE operation completed...'
    }
    foreach($d in $config.rootEntity.modifications.modifyChild)
    {
        write-host 'UPDATE operation in progress...'
	    $configFilePath = $d.targetFile
	    $p = "Updating tag in "+ $configFilePath +" with attribute named "+ $d.targetAttribute+ " whose value "+$d.whoseValue
	    write-host $p
    
        $exists = Test-Path $configFilePath
        if($exists -eq $False)
        {
            Write-Host $configFilePath
            write-host "$($d.targetFile) not found . Skipping..." -f Gray
            continue;
        }
        [XML]$webconfig = Get-Content $configFilePath

        [xml]$xml = '<root>'+$d.InnerText+'</root>'

        $findTag = "//*[@$($d.targetAttribute)"+"="+'"'+$($d.whoseValue)+'"'+"]"
        $node = $webconfig.SelectSingleNode($findTag)
        $parent = $node.ParentNode

        $parent.RemoveAll()
        if($xml.root.ChildNodes)
        {
            foreach($e in $xml.root.ChildNodes.GetEnumerator())
            {
                $parent.AppendChild($webconfig.ImportNode($e, $true))
            }
        }
        $webconfig = [xml] $webconfig.OuterXml.Replace(" xmlns=`"`"", "")
        $webconfig.Save($configFilePath)

        write-host 'UPDATE operation completed...'
    }

    }
    else{
      
      Write-Error 'Drop Location Path is Incorrect. Please check with Devops team'

    }


