﻿param(
$dbserver,
$TargetDB
)

Write-Host '-------------------------Dropping Build Helper DB Started------------------------------------'

$TargetDB = $TargetDB +"_BuildHelper"
import-module sqlps -DisableNameChecking
$MasterDatabase="master"
$sql = @"
USE [master]
Go
DROP DATABASE IF EXISTS $TargetDB
GO
"@
Invoke-Sqlcmd -ServerInstance $dbserver -Database $MasterDatabase  -Query $sql -ConnectionTimeout 77777 -QueryTimeout 77777

Write-Host '-------------------------Dropping Build Helper DB Completed------------------------------------'