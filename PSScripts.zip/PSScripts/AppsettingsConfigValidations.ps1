Param (
    [Parameter(Mandatory = $true, Position = 1, ParameterSetName = 'release')]
    [string]$ReleaseVersion,

    [Parameter(Mandatory = $true, Position = 2, ParameterSetName = 'release')]
    [string]$Env,

    [Parameter(Mandatory = $true, Position = 3, ParameterSetName = 'release')]
    [string]$Proj,

    [Parameter(Mandatory = $true, Position = 4, ParameterSetName = 'release')]
    [string]$Portal,

    [Parameter(Mandatory = $true, Position = 5, ParameterSetName = 'release')]
    [string]$AppSettingsConfig,

    [Parameter(Mandatory = $true, Position = 6, ParameterSetName = 'release')]
    [string]$WorkingDirectory,

    [Parameter(Mandatory = $true, Position = 7, ParameterSetName = 'release')]
    [string]$TechLeadMail,

    [Parameter(Mandatory = $false, Position = 8, ParameterSetName = 'release')]
    [string]$ProjRepoName
    
)

function Send-Email(){
    param(
        [string]$smtpServer = "mail.odessatech.in",
        [string]$ComputerName = $env:ComputerName,
        [string]$from = "Delivery-Devops@odessainc.com",
        [string]$to = $TechLeadMail  
		
		)
    Write-Host 'Before Try'
    try { 
       Write-Host 'Inside Try'
        #Creating a Mail object
        $msg = new-object Net.Mail.MailMessage    

        #Creating SMTP server object
        $smtp = new-object Net.Mail.SmtpClient($smtpServer,25) 
        #$smtp.EnableSsl = $true 
        $smtp.Credentials = New-Object System.Net.NetworkCredential("no-reply@odessatech.in", "password-1"); 

        #Email structure 
        $msg.From = $from
        $msg.ReplyTo = "noreply@odessatech.in"
        $msg.To.Add($to)


        $msg.subject =$Projectname +' ' + $environmentname + ' Config Check Failure Notification'
        $msg.body = $global:MailBody
        $msg.IsBodyHtml = 1       

        #Sending email 
        write-host 'Email sending...'
        $smtp.Send($msg)
        write-host 'Email Sent...'
  } catch {
        Write-Host 'Inside Catch'
        Write-Warning $_
  }
}

function ConfigCheck {
    Param(
        [string]$Path,
        [string]$Project,
        [string]$EnvName,
        [string]$AppName,
        [string]$ConfigName
    )

    # Define the API endpoint and payload
    $url = "http://lwdelbuild-001:8091/keyvalue/filter"
    $headers = @{ "Content-Type" = "application/json" }
    $body = @{
        "projectname"      = $Project # Case sensitive - should match with Odessa Vision values
        "environmentName"  = $EnvName # Case sensitive - should match with Odessa Vision values
        "applicationName"  = $AppName # Case sensitive - should match with Odessa Vision values
        "configName"       = $ConfigName # Case sensitive - should match with Odessa Vision values
    } | ConvertTo-Json
    
    # Send the POST request
    $response = Invoke-RestMethod -Uri $url -Method Post -Headers $headers -Body $body

    if ($response) {
        # Convert API response to a dictionary for easy access
        $apiDict = @{}
        $response | ForEach-Object { $apiDict[$_.key] = $_.value }

        # Load and parse the XML configuration file
        [xml]$xmlConfig = Get-Content -Path $Path
        $configDict = @{}
        foreach ($addElement in $xmlConfig.appSettings.add) {
            $configDict[$addElement.key] = $addElement.value
        }

        Write-Host "Validation started for $EnvName $AppName $ConfigName"
        $err = 0

        # Compare API response with XML configuration       
        foreach ($key in $configDict.Keys) {
            if ($apiDict.ContainsKey($key)) {
                if ($configDict[$key] -eq $apiDict[$key]) {
                    Write-Host "Key '$key' is present and values match." -ForegroundColor Green
                } else {
                    Write-Host "Key '$key' is present but values do not match. Odessa Vision Portal Value: '$($apiDict[$key])', Config Value: '$($configDict[$key])'." -ForegroundColor Red
                $global:MailBody += "Hello Team,<br>" 
                $global:MailBody += "<br>Key '$key' is present but values do not match. Odessa Vision Portal Value: '$($apiDict[$key])', Config Value: '$($configDict[$key])'.</br>"
                $global:MailBody += "Thank You,<br>"  
                    $err++
                }
            } else {
                Write-Host "Key '$key' is not present in the configuration file." -ForegroundColor Yellow
                $global:MailBody += "Hello Team,<br>" 
                $global:MailBody += "<br>Key '$key' is not present in the configuration file.</br>"
                $global:MailBody += "Thank You,<br>"  
            }
        }

        Write-Host "Validation completed for $EnvName $AppName $ConfigName"

        if ($err -gt 0) {
            Write-host 'Please check the Config files'
            Send-Email
            Write-Host 'After Send-Email'
            exit 1
        }
    } else {
        Write-Host "No Env variables added for $EnvName $AppName $ConfigName in the Odessa Vision Portal."
    }
}

function Invoke-EnvironmentSpecificConfigCheck {
    Param(
        [string]$EnvironmentName,
        [string]$ProjectName,
        [string]$WorkingDirectory,
        [hashtable]$EnvironmentPaths,
        [string]$AppSettingsConfig
    )

    # Check if environment configurations are available
    if (!$EnvironmentPaths.ContainsKey($EnvironmentName)) {
        Write-Host "No configuration found for environment: $EnvironmentName" -ForegroundColor Red
        return
    }

    $envKeys = $EnvironmentPaths[$EnvironmentName]

    #if the repo name is different from project-name
    if (![string]::IsNullOrEmpty($ProjRepoName)) {
    $ProjectName = $ProjRepoName  
    }

    # Check and process Web and Job Configurations
    if ($AppSettingsConfig -eq 'Y') {
        foreach ($key in $envKeys) {
            $AppConfigPath = Join-Path -Path $WorkingDirectory -ChildPath "$ProjectName\Project\Config\$key\App\AppSettings.config"
            $wsAppConfigPath = Join-Path -Path $WorkingDirectory -ChildPath "$ProjectName\Project\Config\$key\JobServices\AppSettings.config"
            $webAPIConfig = Join-Path -Path $WorkingDirectory -ChildPath "$ProjectName\Project\Config\$key\WebAPI\AppSettings.config"

            if (Test-Path $AppConfigPath) {
                ConfigCheck -Path $AppConfigPath -Project $Proj -EnvName $key -AppName $Portal -ConfigName 'OC-AppSettings'
            } else {

                Write-Host "Path '$AppConfigPath' doesn't exist" -ForegroundColor Red
                $global:MailBody += "Hello Team,<br>" 
                $global:MailBody += "<br>Config file doesn't exist in this path : '$AppConfigPath' for ReleaseVersion $ReleaseVersion and project $Proj</br>"
                $global:MailBody += "<br>Please include the appropriate config file</br>"
                $global:MailBody += "Thank You,<br>" 

                Send-Email
                exit 1
                #email
            }

            if (Test-Path $wsAppConfigPath) {
                ConfigCheck -Path $wsAppConfigPath -Project $Proj -EnvName $key -AppName $Portal -ConfigName 'WS-AppSettings'
            } else {

                Write-Host "Path '$wsAppConfigPath' doesn't exist" -ForegroundColor Red
                $global:MailBody += "Hello Team,<br>" 
                $global:MailBody += "<br>Config file doesn't exist in this path : '$wsAppConfigPath' for ReleaseVersion $ReleaseVersion and project $Proj</br>"
                $global:MailBody += "<br>Please include the appropriate config file</br>"
                $global:MailBody += "Thank You,<br>" 

                Send-Email
                exit 1
                
            }
            
            if (Test-Path $webAPIConfig) {
                ConfigCheck -Path $webAPIConfig -Project $Proj -EnvName $key -AppName $Portal -ConfigName 'WA-AppSettings'

            } else {
                Write-Host "Path '$webAPIConfig' doesn't exist" -ForegroundColor Red
                $global:MailBody += "Hello Team,<br>" 
                $global:MailBody += "<br>Config file doesn't exist in this path : '$webAPIConfig' for ReleaseVersion $ReleaseVersion and project $Proj</br>"
                $global:MailBody += "<br>Please include the appropriate config file</br>"
                $global:MailBody += "Thank You,<br>"  

                Send-Email
                exit 1
                
            }
        }
    } else {
        Write-Host "AppSettings module not selected; validation skipped."
    }
}


$envDetailQuery = @"
select a.* from Releases a, Projects b, ProjectReleaseMappings c, ApplicationReleaseMappings arm, Applications d
where a.Id = arm.ReleaseId and arm.ApplicationId = d.Id and d.ApplicationName = '$Portal' and c.ProjectId = b.Id and a.Id = c.ReleaseId
and b.ProjectNickName = '$Proj' and a.ReleaseVersion = '$ReleaseVersion' and a.ReleaseStatus in ('Approved','Packaged','Completed')
"@
    $envDetailQuery
    $envDetails = Invoke-Sqlcmd -ServerInstance 'LWDELBUILD-001\SQL2019' -Database 'Odessa_Dashboard_Prod' -Query $envDetailQuery -QueryTimeout 65500 -ErrorAction Stop

    $envi = $envDetails.EnvName
Write-Host "Environment -> $envi"

$environmentPaths = @{
    "Dev Int"           = @("DEV")
    "Sandbox"           = @("SAN")
    "Staging"           = @("Staging", "UAT", "PROD")
    "Staging Hotfix"    = @("STAGING", "UAT", "PROD")
    "SIT"               = @("SIT", "PROD")
    "SIT Hotfix"        = @("SIT", "PROD")
    "UAT"               = @("UAT", "PROD")
    "UAT Hotfix"        = @("UAT", "PROD")
    "Production Hotfix" = @("PROD")
}

#if (![string]::IsNullOrEmpty($ProjRepoName)) {
    #$Proj = $ProjRepoName
#}

Invoke-EnvironmentSpecificConfigCheck -EnvironmentName $envi -ProjectName $Proj -WorkingDirectory $WorkingDirectory -EnvironmentPaths $environmentPaths -AppSettingsConfig $AppSettingsConfig
