﻿Param (
    [Parameter(Mandatory=$true, Position=1, ParameterSetName='release')]
    [string]$ReleaseVersion,

    [Parameter(Mandatory=$true, Position=2, ParameterSetName='release')]
    [string]$Env,

    [Parameter(Mandatory=$true, Position=3, ParameterSetName='release')]
    [string]$Proj,

    [Parameter(Mandatory=$false, Position=4, ParameterSetName='release')]
    [string]$Portal,

    [Parameter(Mandatory=$true, Position=5, ParameterSetName='release')]
    [string]$WebandJobConfig,

    [Parameter(Mandatory=$true, Position=6, ParameterSetName='release')]
    [string]$WebAPIConfig,
    
    [Parameter(Mandatory=$true, Position=7, ParameterSetName='release')]
    [string]$WorkingDirectory,

    [Parameter(Mandatory=$false, Position=8, ParameterSetName='release')]
    [string]$ProjRepoName
)

<#if($Proj -eq 'SGF'){

function Invoke-EnvironmentSpecificConfigCheck {
    Param(
        [string]$EnvironmentName,
        [string]$ProjectName,
        [string]$WorkingDirectory,
        [hashtable]$EnvironmentPaths,
        [string]$WebandJobConfig,
        [string]$WebAPIConfig
    )

    # Check if environment configurations are available
    if (!$EnvironmentPaths.ContainsKey($EnvironmentName)) {
        Write-Host "No configuration found for environment: $EnvironmentName" -ForegroundColor Red
        return
    }

    $envKeys = $EnvironmentPaths[$EnvironmentName]

    # Check and process Web and Job Configurations
    if ($WebandJobConfig -eq 'Y') {
        foreach ($key in $envKeys) {
            $webConfig = "$WorkingDirectory\$ProjectName\Project\Config\$key\App\Web.config"
            $windowsServicesConfig = "$WorkingDirectory\$ProjectName\Project\Config\$key\JobServices\Lw.WindowsServices.exe.config"

            ConfigCheck $webConfig 'OC' $key
            ConfigCheck $windowsServicesConfig 'WS' $key
        }
    } else {
        Write-Host "WebJobConfig module not selected hence validation skipped."
    }

    # Check and process Web API Configurations
    if ($WebAPIConfig -eq 'Y') {
        foreach ($key in $envKeys) {
            $webAPIConfig = "$WorkingDirectory\$ProjectName\Project\Config\$key\WebAPI\Web.config"
            ConfigCheck $webAPIConfig 'API' $key
        }
    } else {
        Write-Host "WebAPIConfig module not selected hence validation skipped."
    }
}



function ConfigCheck {
    Param($Path,$service,$folder)

    if (Test-Path $Path) {
        [xml]$xml = Get-Content -Path $Path
        $requiredKeys = @("AppSettingsKeyVault", "ConnectionStringKeyVault", "AzureAppConfig", "Environment")
        $presentKeys = @()

        foreach ($add in $xml.DocumentElement.configBuilders.builders.add) {
            if ($requiredKeys -contains $add.name) {
                $presentKeys += $add.name
            }
        }

        $missingKeys = $requiredKeys | Where-Object { $_ -notin $presentKeys }
        if ($missingKeys.Count -eq 0) {
            Write-Host "All required keys are present in the <builders> tag in: " $Path
        } else {
            Write-Host "The following keys are missing from the <builders> tag in: " $Path -ForegroundColor Red
            $missingKeys | ForEach-Object { Write-Host "- $_" -ForegroundColor Red }
            exit 1
        }
        
        $azureAppConfigElement = $xml.DocumentElement.configBuilders.builders.add | Where-Object { $_.name -eq "AzureAppConfig" }

        $labelFilter = $azureAppConfigElement.labelFilter

        if ($folder -eq 'SIT'){
        
        if( $service -eq 'OC'-and $labelFilter -eq "SITOC" ) {
            Write-Output "The labelFilter is set to 'SITOC'."
        }
        elseif( $service -eq 'WS'-and $labelFilter -eq "SITOCWS" ){
            Write-Output "The labelFilter is set to 'SITOCWS'."
        }
        elseif( $service -eq 'API'-and $labelFilter -eq "SITAPI" ){
            Write-Output "The labelFilter is set to 'SITAPI'."
        }
        else {
             
            Write-Output "The labelFilter is Wrong."
            $global:MailBody += "Hello Team,<br>" 
            $global:MailBody += "<br>The LabelFilter $labelFilte is not correct for env - $folder and application $service.</br>"
            $global:MailBody += "Thank You,<br>" 

            Send-Email
            exit 1
        }

        }
        
        
        if ($folder -eq 'UAT'){
        
        if( $service -eq 'OC'-and $labelFilter -eq "UATOC" ) {
            Write-Output "The labelFilter is set to 'UATOC'."
        }
        elseif( $service -eq 'WS'-and $labelFilter -eq "UATOCWS" ){
            Write-Output "The labelFilter is set to 'UATOCWS'."
        }
        elseif( $service -eq 'API'-and $labelFilter -eq "UATAPI" ){
            Write-Output "The labelFilter is set to 'UATAPI'."
        }
        else {
             
            Write-Output "The labelFilter is Wrong."
            $global:MailBody += "Hello Team,<br>" 
            $global:MailBody += "<br>The LabelFilter $labelFilte is not correct for env - $folder and application $service.</br>"
            $global:MailBody += "Thank You,<br>" 

            Send-Email
            exit 1
        }

        }

        
        if ($folder -eq 'PROD'){
        
        if( $service -eq 'OC'-and $labelFilter -eq "PRODOC" ) {
            Write-Output "The labelFilter is set to 'PRODOC'."
        }
        elseif( $service -eq 'WS'-and $labelFilter -eq "PRODOCWS" ){
            Write-Output "The labelFilter is set to 'PRODOCWS'."
        }
        elseif( $service -eq 'API'-and $labelFilter -eq "PRODAPI" ){
            Write-Output "The labelFilter is set to 'PRODAPI'."
        }
        else {
             
            Write-Output "The labelFilter is Wrong."
            $global:MailBody += "Hello Team,<br>" 
            $global:MailBody += "<br>The LabelFilter $labelFilte is not correct for env - $folder and application $service.</br>"
            $global:MailBody += "Thank You,<br>" 

            Send-Email
            exit 1
        }

        }
        
    } else {
        Write-Host "Path $Path not found." -ForegroundColor Red
        exit 1
    }
}


function Send-Email(){
    param(
        [string]$smtpServer = "mail.odessatech.in",
        [string]$ComputerName = $env:ComputerName,
        [string]$from = "Delivery-Devops@odessainc.com",
        [string]$to = "sgf-blr-team@odessainc.com"    
		
		)
    
    try { 

        #Creating a Mail object
        $msg = new-object Net.Mail.MailMessage    

        #Creating SMTP server object
        $smtp = new-object Net.Mail.SmtpClient($smtpServer,25) 
        #$smtp.EnableSsl = $true 
        $smtp.Credentials = New-Object System.Net.NetworkCredential("no-reply@odessatech.in", "password-1"); 

        #Email structure 
        $msg.From = $from
        $msg.ReplyTo = "noreply@odessatech.in"
        $msg.To.Add($to)


        $msg.subject =$Projectname +' ' + $environmentname + ' Config Check Failure Notification'
        $msg.body = $global:MailBody
        $msg.IsBodyHtml = 1       

        #Sending email 
        write-host 'Email sending...'
        $smtp.Send($msg)
        write-host 'Email Sent...'
  } catch {
        Write-Warning $_
  }
}

$envDetailQuery = @"
select a.* from Releases a, Projects b, ProjectReleaseMappings c, ApplicationReleaseMappings arm, Applications d
where a.Id = arm.ReleaseId and arm.ApplicationId = d.Id and d.ApplicationName = '$Portal' and c.ProjectId = b.Id and a.Id = c.ReleaseId
and b.ProjectNickName = '$Proj' and a.ReleaseVersion = '$ReleaseVersion' and a.ReleaseStatus = 'Approved'
"@
    $envDetailQuery
    $envDetails = Invoke-Sqlcmd -ServerInstance 'LWDELBUILD-001\SQL2019' -Database 'Odessa_Dashboard_Prod' -Query $envDetailQuery -QueryTimeout 65500 -ErrorAction Stop

    $envi = $envDetails.EnvName
    Write-Host 'Environment-> ' $envi

    $environmentPaths = @{
        "Dev Int"             = @("DEV")
        "Sandbox"             = @("SAN")
        "Staging"             = @("STAGING", "UAT", "PROD")
        "Staging Hotfix"      = @("STAGING", "UAT", "PROD")
        "SIT"                 = @("SIT", "PROD")
        "SIT Hotfix"          = @("SIT", "PROD")
        "UAT"                 = @("UAT", "PROD")
        "UAT Hotfix"          = @("UAT", "PROD")
        "Production Hotfix"   = @("PROD")
    }
    
 if (!([string]::IsNullOrEmpty($ProjRepoName))) {
    $Proj = $ProjRepoName
}

 Invoke-EnvironmentSpecificConfigCheck -EnvironmentName $envi -ProjectName $Proj -WorkingDirectory $WorkingDirectory -EnvironmentPaths $environmentPaths -WebandJobConfig $WebandJobConfig -WebAPIConfig $WebAPIConfig

} #>


function Invoke-EnvironmentSpecificConfigCheck {
    Param(
        [string]$EnvironmentName,
        [string]$ProjectName,
        [string]$WorkingDirectory,
        [hashtable]$EnvironmentPaths,
        [string]$WebandJobConfig,
        [string]$WebAPIConfig
    )

    # Check if environment configurations are available
    if (!$EnvironmentPaths.ContainsKey($EnvironmentName)) {
        Write-Host "No configuration found for environment: $EnvironmentName" -ForegroundColor Red
        return
    }

    $envKeys = $EnvironmentPaths[$EnvironmentName]

    # Check and process Web and Job Configurations
    if ($WebandJobConfig -eq 'Y') {
        foreach ($key in $envKeys) {
            $webConfig = "$WorkingDirectory\$ProjectName\Project\Config\$key\App\Web.config"
            $windowsServicesConfig = "$WorkingDirectory\$ProjectName\Project\Config\$key\JobServices\Lw.WindowsServices.exe.config"

            ConfigCheck $webConfig
            ConfigCheck $windowsServicesConfig
        }
    } else {
        Write-Host "WebJobConfig module not selected hence validation skipped."
    }

    # Check and process Web API Configurations
    if ($WebAPIConfig -eq 'Y') {
        foreach ($key in $envKeys) {
            $webAPIConfig = "$WorkingDirectory\$ProjectName\Project\Config\$key\WebAPI\Web.config"
            ConfigCheck $webAPIConfig
        }
    } else {
        Write-Host "WebAPIConfig module not selected hence validation skipped."
    }
}



function ConfigCheck {
    Param($Path)

    if (Test-Path $Path) {
        [xml]$xml = Get-Content -Path $Path
        $requiredKeys = @("AppSettingsKeyVault", "ConnectionStringKeyVault", "AzureAppConfig", "Environment")
        $presentKeys = @()

        foreach ($add in $xml.DocumentElement.configBuilders.builders.add) {
            if ($requiredKeys -contains $add.name) {
                $presentKeys += $add.name
            }
        }

        $missingKeys = $requiredKeys | Where-Object { $_ -notin $presentKeys }
        if ($missingKeys.Count -eq 0) {
            Write-Host "All required keys are present in the <builders> tag in: " $Path
        } else {
            Write-Host "The following keys are missing from the <builders> tag in: " $Path -ForegroundColor Red
            $missingKeys | ForEach-Object { Write-Host "- $_" -ForegroundColor Red }
            exit 1
        }
    } else {
        Write-Host "Path $Path not found." -ForegroundColor Red
        exit 1
    }
}

$envDetailQuery = @"
select a.* from Releases a, Projects b, ProjectReleaseMappings c, ApplicationReleaseMappings arm, Applications d
where a.Id = arm.ReleaseId and arm.ApplicationId = d.Id and d.ApplicationName = '$Portal' and c.ProjectId = b.Id and a.Id = c.ReleaseId
and b.ProjectNickName = '$Proj' and a.ReleaseVersion = '$ReleaseVersion' and a.ReleaseStatus in ('Approved','Packaged','Completed')
"@
    $envDetailQuery
    $envDetails = Invoke-Sqlcmd -ServerInstance 'LWDELBUILD-001\SQL2019' -Database 'Odessa_Dashboard_Prod' -Query $envDetailQuery -QueryTimeout 65500 -ErrorAction Stop

    $envi = $envDetails.EnvName
    Write-Host 'Environment-> ' $envi

    $environmentPaths = @{
        "Dev Int"             = @("DEV")
        "Sandbox"             = @("SAN")
        "Staging"             = @("STAGING", "UAT", "PROD")
        "Staging Hotfix"      = @("STAGING", "UAT", "PROD")
        "SIT"                 = @("SIT", "UAT", "PROD")
        "SIT Hotfix"          = @("SIT", "UAT", "PROD")
        "UAT"                 = @("UAT", "PROD");
        "UAT Hotfix"          = @("UAT", "PROD")
        "Production Hotfix"   = @("PROD")
    }
    
    if (!([string]::IsNullOrEmpty($ProjRepoName))) {
    $Proj = $ProjRepoName
} 

 Invoke-EnvironmentSpecificConfigCheck -EnvironmentName $envi -ProjectName $Proj -WorkingDirectory $WorkingDirectory -EnvironmentPaths $environmentPaths -WebandJobConfig $WebandJobConfig -WebAPIConfig $WebAPIConfig

