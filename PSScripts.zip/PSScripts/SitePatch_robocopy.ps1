﻿param(
$packagePath,
$sitePath,
$id,
$clear = '1'
)

if($id -ne 'na' -or $id -ne 'NA'){
    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
    $packagePath = $packagePath + "\" + $currentDate + "\"+$id+"\"
}
$packagePath
$sitePath
$clear

if((Test-Path $packagePath) -eq $false){
    Write-Host "No package found $packagePath"
    return
}elseif((Test-Path $sitePath) -eq $false){
    Write-Host "Destination $sitePath not found"
    return
}

if($clear -eq '1'){
    #Remove-Item -Path $sitePath -Exclude *.config,*.bat -Force -Recurse -Verbose
}
#Copy-Item -Path $packagePath  -Destination $sitePath -Force -Recurse -Verbose

#robocopy $packagePath $sitePath /S /E /Z /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /XO /maxage: n
robocopy $packagePath $sitePath /S /E /Z /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /XO /COPY:DT


write-host "Successfully completed $id site folder..." -ForegroundColor Green

if ($lastexitcode -lt 8) { $lastexitcode = 0 }

