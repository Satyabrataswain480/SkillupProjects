﻿Param(
[parameter (Mandatory=$true, position=0, ParameterSetName='RDL')]
[string]$source,
[parameter (Mandatory=$true, position=1, ParameterSetName='RDL')]
[string]$destination
)


   # Get the latest zip file
   $latestZip = Get-ChildItem -Path $source -Filter "*.zip" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
              
   if ($latestZip -ne $null) {
       # Generate destination file name with current date and time
       $currentDateTime = Get-Date -Format "yyyyMMdd_HHmmss"
       $destinationFileName = "{0}_{1}" -f $currentDateTime, $latestZip.BaseName
       $destinationFile = Join-Path -Path $destination -ChildPath "$destinationFileName.zip"
          
       # Copy the latest zip file to the destination
       Copy-Item -Path $latestZip.FullName -Destination $destinationFile -Force
       Write-Host "Latest zip file '$($latestZip.Name)' copied to '$destinationFile'."
     
       } 
   else{
       
       Write-Host "No zip files found in the source directory."
      
       }