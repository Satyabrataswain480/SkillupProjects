﻿Param  (
[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Source,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Destination,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$Module,
[parameter (Mandatory=$false, position=3, ParameterSetName='Release')]
[string]$IsCustomerPortal
)

##  Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir = $Destination + $currentDate


##Customerportal or PartnerPortal copy
if($Module -eq '1')  
{
    if($IsCustomerPortal -eq '1')
    {
        $CustomerPortal = $RelDir + '\CustomerPortal\'
    }
    else
    {
        $CustomerPortal = $RelDir + '\PartnerPortal\'
    }
    $Source1 = $Source + '\_PublishedWebsites\Lw.LessorPortal.Project\'    
    
    write-host 'Starting Customer/Partner Portal copy.'
    robocopy $Source1 $CustomerPortal /E /copyall
    write-host 'Completed Customer/Partner Portal copy.'

    $LWSource = $Source + '\Lw.LessorPortal.Project.Resource.dll'
        
    $LWBin =  $CustomerPortal + '\bin\'
    if(!([string]::IsNullOrEmpty($LWSource)) -and (Test-path $LWSource))
    {
      Copy-Item  $LWSource $LWBin
    }

    #Copy DomainAssembly DLL to WindowService
    write-host 'Copy windowsservice domainassembly DLL'
    if($IsCustomerPortal -eq '1')
    {
        $LessorPortalDomainAss = $RelDir + '\CustomerPortal\DomainAssemblies\*.*'
    }
    else
    {
        $LessorPortalDomainAss = $RelDir + '\PartnerPortal\DomainAssemblies\*.*'
    }
    $WindowServiceDomainAss = $RelDir + '\WindowsService\DomainAssemblies\' 
     if (Test-path $WindowServiceDomainAss)
   {
        if (Test-path $LessorPortalDomainAss)
        {   
    Copy-item $LessorPortalDomainAss  $WindowServiceDomainAss  -Force
    write-host 'Completed windowsservice domainassembly DLL'
        }
   }
}

if($Module -eq '2')  #Reports
{
    $Reports = $RelDir + '\Reports\RDLs\'
    write-host 'Starting RDL copy.'
    robocopy $Source $Reports /E /copyall
    write-host 'Completed RDL copy.'

    #Copy DLL
    $reportDllpath = Split-Path $Source
    $reportDllpath
    $Helper = $RelDir + '\Reports\ReportHelper\'
    copy-item -Path "$reportDllpath\Lw.Domain.ReportHelper*.dll" $Helper -Force -ErrorAction Ignore
}

if($Module -eq '3')  #SQLScripts
{
    $SQLScripts = $RelDir + '\Database\DBScripts\'

    ##Validate Go Statement in SQL Scripts
    write-host "Startging to validate GO statement..."
    $SQLScriptPathDDL = $SQLScripts + 'DDL\*.sql'
    write-host $SQLScriptPathDDL
    $SQLFiles = Get-Item -Path $SQLScriptPathDDL

    for ($i=0; $i -lt $SQLFiles.Count; $i++) 
    {
        $outfile = $SQLFiles[$i].FullName
       $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
        write-host 'Printing last line of file -' $outfile +" - " + $SQLFileContent

        if($SQLFileContent -ne 'GO' -or $SQLFileContent -ne 'Go')
        {
          write-host "Please add GO statement at the end of file - " + $outfile
          exit -1
        }
    }
    
    $SQLScriptPathDML = $SQLScripts + 'DML\*.sql'
    $SQLFiles = Get-Item -Path $SQLScriptPathDML

    for ($i=0; $i -lt $SQLFiles.Count; $i++) 
    {
        $outfile = $SQLFiles[$i].FullName
       $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
        write-host $outfile +" - " + $SQLFileContent

        if($SQLFileContent -ne 'GO' -or $SQLFileContent -ne 'Go')
        {
          write-host "Please add GO statement at the end of file - " + $outfile
          exit -1
        }
    }

    write-host 'Starting SQL scripts copy.'
    robocopy $Source $SQLScripts /E /copyall
    write-host 'Completed SQL scripts copy.'
}

if($Module -eq '3.1')  #CoreSQLScripts
{
    $SQLScripts = $RelDir + '\Database\DBScripts\'
    write-host 'Starting Core SQL scripts copy.'
    write-host 'Source path ' + $Source
    write-host 'Destination path '$SQLScripts

    Copy-Item $Source $SQLScripts 
    write-host 'Completed SQL scripts copy.'
}

if($Module -eq '4')  #COpy Product Dlls
{
    if($IsCustomerPortal -eq '1')
    {
        $CustomerPortalbin = $RelDir + '\CustomerPortal\bin'
    }
    else
    {
        $CustomerPortalbin = $RelDir + '\PartnerPortal\bin'
    }
    write-host 'Starting product dll copy.'
    copy-Item $Source $CustomerPortalbin -Include 'Lw.Domain.*.dll'
    write-host 'Completed product dll copy.'
}

if($Module -eq '5')  #UserManual
{
    $UserManual = $RelDir + '\UserManual'
   
    write-host 'Starting UserManual copy.'
    robocopy $Source $UserManual /E /copyall
    write-host 'Completed UserManual copy.'
}

if($Module -eq '6')  #Config Cleanup
{
    write-host 'Starting Config Cleanup'
    $Include = "AppSettings.config", "ConnectionStrings.config", "Lw.WindowsServices.exe.config", "Web.config", "ApplicationInsights.config"
    if(Test-Path $RelDir)
    {
        Get-ChildItem $RelDir -Include $Include -Recurse | Remove-Item -Recurse
    }
    write-host 'Completed Config Cleanup'
}

if (($lastexitcode -lt 8) -or ($lastexitcode -eq 16))
  { $lastexitcode = 0 }
