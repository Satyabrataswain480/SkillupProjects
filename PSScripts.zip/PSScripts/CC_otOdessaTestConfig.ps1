param(
   $basePath,
   $projectName,
   $configName
)

#$basePath = "D:\Test"
#$projectName = "CSI"
#$configName = "OdessaTest.config" 

$sitePath = "$basePath\$projectName\Site"
$siteName = "DotCoverAutomation_$projectName"
$iisConfigPath = "$basePath\applicationhost.config"
$configLocation = "$basePath\$projectName\Configs"
$targetName = $siteName

[xml]$xml = Get-Content -Path $iisConfigPath
$targetNode = Select-Xml -Xml $xml -XPath "//site[@name='$targetName']"
$id = $targetNode.Node.Attributes['id'].value
$port = $targetNode.Node.bindings.binding.Attributes["bindingInformation"].value -replace "[^0-9]", ""

$otConfigPath = "$basePath\$projectName\OT\$configName"
[xml]$otxml = Get-Content -Path $otConfigPath
$TargetValue = "http://localhost:$port"
$nodes = $otxml.SelectNodes("//add[@key='DeploymentUrl']")

if($nodes -ne $null){
    foreach($node in $nodes) {
        $node.SetAttribute("value", $TargetValue);
    }

    $otxml.Save($otConfigPath)
}
