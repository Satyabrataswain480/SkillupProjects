﻿param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='db')]
    [string]$dbname,
    [parameter(Mandatory=$true, position=2, ParameterSetName='db')]
    [string]$dbserver,
    [parameter(Mandatory=$true, position=3, ParameterSetName='db')]
    [string]$dbusername
)



#1.Create User
$createUserQuery = "
CREATE USER $dbusername 
FOR LOGIN $dbusername;
GO
"

$createUserQuery

invoke-sqlcmd -ServerInstance $dbserver -Database $dbname -Query $createuserquery  -QueryTimeout 65500 -ErrorAction Continue
invoke-sqlcmd -ServerInstance $dbserver -Database 'tempdb' -Query $createuserquery  -QueryTimeout 65500 -ErrorAction Continue


#2.Sync the user according to the current instance

$syncUserQuery= "
EXEC sp_change_users_login 'Auto_Fix', '$dbusername'
GO

EXEC sp_addrolemember 'db_datareader', '$dbusername'
GO

EXEC sp_addrolemember 'db_datawriter', '$dbusername'
GO"

$syncUserQuery
invoke-sqlcmd -ServerInstance $dbserver -Database $dbname -Query $syncUserQuery  -QueryTimeout 65500 -ErrorAction Continue
invoke-sqlcmd -ServerInstance $dbserver -Database 'tempdb' -Query $syncUserQuery  -QueryTimeout 65500 -ErrorAction Continue

#3.Provide Access to the respective project DB user

$dbAccessQuery = "
GRANT VIEW DEFINITION, SELECT, REFERENCES, INSERT, ALTER, EXECUTE, UPDATE, CONNECT, UNMASK TO $dbusername  
GO"

$dbAccessQuery
invoke-sqlcmd -ServerInstance $dbserver -Database $dbName -Query $dbAccessQuery -QueryTimeout 65500 -ErrorAction Continue
invoke-sqlcmd -ServerInstance $dbserver -Database 'tempdb' -Query $dbAccessQuery -QueryTimeout 65500 -ErrorAction Continue

#4.Provide VIEW SERVER STATE Permission in Master DB

$viewServerStateQuery = "Use Master
GO

GRANT VIEW SERVER STATE TO $dbusername 
GO"

$viewServerStateQuery
invoke-sqlcmd -ServerInstance $dbserver -Database 'master' -Query $viewServerStateQuery -QueryTimeout 65500 -ErrorAction Continue

#5.Extract Table Permissions

$extractTablePermissionQuery = "Use $dbname
GO
EXEC CreateExtractTables
GO

EXEC CreateSynonymForJobs 1
GO

EXEC CreateLWClusteredIndexes
GO

EXEC CreateLWDefaultConstraints
GO

EXEC DisableConstraints
GO

EXEC DisableKeysForSKUTable
GO

DECLARE @DatabaseName SYSNAME =DB_NAME()
DECLARE @LoginName NVARCHAR(1000) = N'$dbusername'
EXEC CreateSQLJobToCreateExtractTable @DatabaseName, @LoginName
GO

DECLARE @DatabaseName SYSNAME = DB_NAME()
DECLARE @LoginName SYSNAME = SYSTEM_USER
EXEC CreateSQLJobToTruncateExtractTable @DatabaseName,@LoginName
GO

EXEC sp_configure 'clr enabled', 1;  
RECONFIGURE;  
GO"

$extractTablePermissionQuery
invoke-sqlcmd -ServerInstance $dbserver -Database 'master' -Query $extractTablePermissionQuery -QueryTimeout 65500 -ErrorAction Continue 