﻿param(
$packagePath,
$jobServer,
$jobServiceCount,
$jobName,
$jobRootPath,
$job_Service_Path,
$direct = '0'
)
$direct
if($direct -eq '0'){
    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
    $packagePath = $packagePath + $currentDate
    $packagePath = $packagePath +'\WindowsService'
}

#CONSTs
$array = $jobRootPath.Split('\')
$child= $array[$array.Length - 1]

if(!(Test-Path $jobRootPath)){
    New-Item -Path $jobRootPath -itemtype directory
}

$jobSubFolder = '\'+$child+'\'
$jobRootPath = (Get-Item $jobRootPath).Parent.FullName

Write-Host $jobSubFolder
Write-Host $jobRootPath
#VARIABLES
$existingJobs = @()
$existingJobDestination = @()
$newJobs=@()
$newJobDestinations=@()
$allJobs=@()
$backupPathArrayFrom = @()
$backupPathArrayTo = @()
$destinationPathArray=@()

function CopyContent{
    Param([string]$target, [string]$destination, [string]$name = '', [bool]$delete = $true)
    if(Test-Path $target){
        if(Test-Path $destination){
            if($delete){
                Remove-Item -Path $destination'/*' -Exclude *.config,*.bat, "OpenXmlPowerTools.dll", "librdkafka.dll" -Force -Recurse -ErrorAction Stop
            }
            #Copy-Item -Path $target'/*' -Destination $destination  -Recurse -Force
            robocopy $target $destination /S /E /Z /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /XO /COPY:DT /XF $target + "OpenXmlPowerTools.dll" + "librdkafka.dll" 
            Write-Host "$name content copied from $target to $destination successfully." -ForegroundColor Green
        }
        else{
            Write-Host "Path $destination not found." -f Red
            exit -1
        }
    }
    else{
        Write-Host "Path $target not found." -f Red
        exit -1
    }
}


function Retry()
{
    param(
        [Parameter(Mandatory=$true)][Action]$action,
        [Parameter(Mandatory=$false)][Action]$retryAction = $null,
        [Parameter(Mandatory=$false)][int]$maxAttempts = 4
    )

    $attempts=1
    do
    {
        try
        {
            $action.Invoke();
            break;
        }
        catch [Exception]
        {
            Write-Host $_.Exception.Message
        }

        # exponential backoff delay
        $attempts++
        if ($attempts -le $maxAttempts) {
            $retryDelaySeconds = [math]::Pow(2, $attempts)
            $retryDelaySeconds = $retryDelaySeconds - 1
        
            Write-Host("Action failed. Attempt " + $attempts + " of " + $maxAttempts + ".")
            Start-Sleep $retryDelaySeconds 
            if( $retryAction -ne $null){
                $retryAction.Invoke()
            }
        }
        else {
            throw $_.Exception
           
        }
    } while ($attempts -le $maxAttempts)
}

function Kill-Process{
    param($server, $serviceName)
    write-host "+++++++++++++++++"
    write-host $server
    write-host $serviceName
    write-host "+++++++++++++++++"
    Invoke-Command -ComputerName $server{
        $id = Get-WmiObject -Class Win32_Service -Filter "Name LIKE '$using:serviceName'" | Select-Object -ExpandProperty ProcessId 
        write-host "Process Id: $id" 
        if($id -eq $null){return}
        Stop-Process -id $id -Force -ErrorAction Ignore
    }

}

if(!(Test-Path $packagePath)){
    Write-Host $packagePath
    Write-Host "No Content Found"
    return -1
}

##CHECK
if(!(Test-path $packagePath))
{
   write-host 'No Windowsservice folder found in release package.'
}
else
{
for($i=0; $i -lt $jobServiceCount; $i++){
    
    $j = $i+1
    if($i -eq 0){
        $name = $jobName
        $destinationPath = $jobRootPath + "\$child"
    }
    else{
        $name = $jobName + $j 
        $destinationPath = $jobRootPath + "\$child" + $j
    }
    if(!(Test-Path $destinationPath)){
        $newJobs += $name
        New-Item $destinationPath -ItemType "directory"
        $newJobDestinations += $job_Service_Path+"\Lw.WindowsServices.exe"
    }
    else{
        $existingJobs += $name
        $existingJobDestination += $job_Service_Path+"\Lw.WindowsServices.exe"
        $backupPathArrayFrom += $destinationPath
        $tempBackupPath = $backupPath + $jobSubFolder + $jobName + $j
        $backupPathArrayTo += $tempBackupPath
    }
    $destinationPathArray += $destinationPath
    $allJobs += $name
}

$destinationPathArray

for($i=0; $i -lt $backupPathArrayFrom.Length; $i++){
    Write-Host "Deleting existing copies from :" $backupPathArrayFrom[$i]
    $path = $backupPathArrayFrom[$i] + "\*"
    $jobServer 
    $nameOftheJob =  $existingJobs[$i]
    Retry { 
        #Remove-Item -Path $path -Exclude *.config,*.bat -Force -Recurse -ErrorAction Stop
        } -retryAction { Kill-Process $jobServer $nameOftheJob }
}

#COPYCONTENT
for($i=0; $i -lt $destinationPathArray.Length; $i++){
    $destination = $destinationPathArray[$i]
    $description = $allJobs[$i]+":"
    if($i -gt 0){

        CopyContent $destinationPathArray[0] $destination $description
        #Copy-Item -Path $target'/*' -Destination $destination  -Recurse -Force
    }
    else{
        write-host $packagePath + ' From Here'
        CopyContent $packagePath $destination $description
    }
}


#CREATE SERVICES
for($i=0; $i -lt $newJobs.Length; $i++){

    $jobName = $newJobs[$i]
    $TargetPath = $newJobDestinations[$i]
    $DisplayName = $jobName
    
    Invoke-Command -ComputerName $jobServer -ScriptBlock{
        param ([string]$jobName, [string]$TargetPath, [string]$DisplayName)
        New-Service -Name $jobName -BinaryPathName $TargetPath -DisplayName $DisplayName -StartupType Automatic
        } -ArgumentList $jobName,$TargetPath,$DisplayName
    
}

for($i=0; $i -lt $existingJobs.Length; $i++){
    $jobName = $existingJobs[$i]
    $TargetPath = $existingJobDestination[$i]
    $DisplayName = $jobName

    $Service = Get-WmiObject -ComputerName  $jobServer  -Class Win32_Service -Filter "Name='$jobName'"
    if($Service -eq $null){
        Invoke-Command -ComputerName $jobServer -ScriptBlock{
        param ([string]$jobName, [string]$TargetPath, [string]$DisplayName)
        New-Service -Name $jobName -BinaryPathName $TargetPath -DisplayName $DisplayName -StartupType Automatic
        } -ArgumentList $jobName,$TargetPath,$DisplayName
    }
}
}
if ($lastexitcode -lt 8) { $lastexitcode = 0 }

