﻿Param (

[parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
[string]$SQLServer,
[parameter (Mandatory=$true, position=1, ParameterSetName='Database')]
[string]$DatabaseName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Database')]
[string]$ReleaseVersion,
[parameter (Mandatory=$true, position=3, ParameterSetName='Database')]
[string]$ProjectName,
[parameter (Mandatory=$true, position=4, ParameterSetName='Database')]
[string]$Status,
[parameter (Mandatory=$false, position=5, ParameterSetName='Database')]
[string]$Portal='OdessaCore'

)
#$Status = Packaged, Completed

#$Query1="update ReleaseRequestApprovals set HasApproved = 1 where ReleaseRequestId = (
#select Id from ReleaseRequests where ReleaseVersion ='$ReleaseVersion' and status = 'Approved' and ProjectId = (select Id from Projects where Name = '$ProjectName')
#)"

#write-host $Query1

#invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -query $Query1 -QueryTimeout 65500

$Query2="update Releases set ReleaseStatus = '$Status' where Id  = 
(select r.id from Releases r
join ApplicationReleaseMappings arm on r.Id = arm.ReleaseId
join Applications a on arm.ApplicationId = a.Id
join ProjectReleaseMappings prm on r.Id = prm.ReleaseId
join Projects p on p.Id = prm.ProjectId
where r.ReleaseVersion = '$ReleaseVersion'
and r.ReleaseStatus = 'Approved' 
and p.ProjectNickName = '$ProjectName'
and a.ApplicationName ='$Portal')"
 
write-host $Query2
invoke-sqlcmd –ServerInstance 'LWDELBUILD-001\SQL2019' -Database 'Odessa_Dashboard_Prod' -query $Query2 -QueryTimeout 65500

