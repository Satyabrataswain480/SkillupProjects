﻿param(
$LocalPackagePath,
$BuildServer
)

    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd")
    $LocalPackagePath = $LocalPackagePath + $currentDate
    $LocalPackagePath

Invoke-Command -Computername $BuildServer -ScriptBlock {
param ($LocalPackagePath)

         write-host 'Starting ziping'
         Compress-Archive -Path $LocalPackagePath -DestinationPath $LocalPackagePath -Force 
         write-host 'Completed ziping'

} -ArgumentList $LocalPackagePath
