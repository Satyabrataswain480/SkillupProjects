﻿param(
$buildPath, # '$(Build.ArtifactStagingDirectory)\build\'
$domainPath, #  $(Build.Repository.LocalPath)\Lenovo\Project\Lw.Domain.Project\
$outputPath, # any shared path
$sqldest, #$(Build.ArtifactStagingDirectory)\SQLScripts\
$OBArchPath
)

#Clean outputPath
Remove-Item -Path "$outputPath\*" -Force

Write-Host '-------------------------OB Generation Started------------------------------------'

Write-Host 'BuildPath ---' $buildPath
$stLocationPth = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin"
Write-Host 'stLocationpth---' $stLocationPth
Set-Location -Path $stLocationPth
$lf = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.System.Common.dll"
[System.Reflection.assembly]::LoadFile($lf)
$lf = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.System.Metamodel.dll"
$lf
[System.Reflection.assembly]::LoadFile($lf)
$lf = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.System.Tools.Common.dll"
$lf
[System.Reflection.assembly]::LoadFile($lf)
$lf = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.System.dll"
$lf
[System.Reflection.assembly]::LoadFile($lf)
$objBuildToolsService=New-Object Lw.Sys.Customization.BuildTools.BuildToolsServiceInvoker
$objBuildToolsService.GenerateDatabaseScripts($buildPath+"_PublishedWebsites\Lw.LessorPortal.Project",$domainPath,$buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\DomainAssemblies\Lw.Domain.dll",$outputPath,"Lw.Domain.LeasewaveRepository")

Write-Host '-------------------------OB Generation Completed------------------------------------'

##################################################################################################################################

Write-Host '-------------------------Copy OB Script to Build folder Started------------------------------------'


$assemblyInfoPath = $domainPath + "\AssemblyInfo.cs"
$assemblyInfoPath
$assemblyInfoContent = Get-Content -Path $assemblyInfoPath -Raw

$versionPattern = 'AssemblyVersion\("(.+?)"\)'
$versionMatch = [regex]::Match($assemblyInfoContent, $versionPattern)

$version = $versionMatch.Groups[1].Value
$Version = $version.Replace('.','')

Write-Host = 'Assembly Version ---> '$Version

$deltaSchemaPath = $outputPath + '\DatabaseDeltaSchemaScript.sql'
$updateScriptPath = $outputPath + '\DatabaseUpdateScript.sql'
 
Rename-Item -Path $deltaSchemaPath -NewName "3000_R${Version}_DeltaSchema.sql" -Force 
Rename-Item -Path $updateScriptPath -NewName "3000_R${Version}_DUpdate.sql" -Force

$ExclusionFiles= @("DatabaseFullScript.sql")

$source = $outputPath + '\*'

$sqldest = $sqldest + '\DDL'
Copy-Item -Path $source -Destination $sqldest -Exclude $ExclusionFiles -Recurse -Force


#Archiving OB
$filesToCopy = Get-ChildItem -Path $source -File | Where-Object { $_.Name -ne $ExclusionFiles }

foreach ($file in $filesToCopy) {

    $newFilename = "$(Get-Date -Format 'yyyyMMdd_HH_mm')_$($file.BaseName)$($file.Extension)"
    
    $destinationFilePath = Join-Path -Path $OBArchPath -ChildPath $newFilename
    
    Move-Item -Path $file.FullName -Destination $destinationFilePath -Force

    Write-Host "File $($file.Name) copied to $($destinationFilePath)"
}

Write-Host '-------------------------Copy OB Script to Build folder Completed------------------------------------'
