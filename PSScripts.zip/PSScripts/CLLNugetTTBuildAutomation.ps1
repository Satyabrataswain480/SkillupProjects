﻿Param (
    [Parameter(Mandatory=$true, Position=1, ParameterSetName='release')]
    [string]$MsBuildPath,

    [Parameter(Mandatory=$true, Position=2, ParameterSetName='release')]
    [string]$SolutionPath,

    [Parameter(Mandatory=$true, Position=3, ParameterSetName='release')]
    [string]$NugetExePath,

    [Parameter(Mandatory=$false, Position=4, ParameterSetName='release')]
    [string]$NugetConfigPath,

    [Parameter(Mandatory=$false, Position=5, ParameterSetName='release')]
    [string]$BuildOutputPath
)


function NugetRestore{
 Param($nugetExePath,$solutionPath,$nugetConfigPath)
 Write-Host 'Nuget Path --' $nugetExePath
 Write-Host 'Solution Path --' $solutionPath
 Write-Host 'NugetConfig Path --' $nugetConfigPath 
 $verbosity = "Detailed"

# Prepare the command arguments
# Use an array to properly pass arguments
$arguments = "restore", "`"$solutionPath`"", "-ConfigFile", "`"$nugetConfigPath`"", "-NoCache", "-Verbosity", $verbosity

# Execute NuGet restore
Write-Host "Running NuGet restore for $solutionPath"
Write-Host "Using config: $nugetConfigPath"
& $nugetExePath $arguments

# Check if the NuGet restore was successful
if ($LastExitCode -eq 0) {
    Write-Host "NuGet restore completed successfully."
} else {
    Write-Host "NuGet restore failed."
    exit $LastExitCode
}
}

function RunTT {
  Param($msbuildPath,$solutionPath)

  # Define the path to MSBuild.exe
  write-host 'MS Build Path' $msbuildPath 

# Ensure the MSBuild path exists
if (-Not (Test-Path $msbuildPath)) {
    Write-Error "MSBuild.exe not found at path: $msbuildPath"
    exit 1
}

# Define the path to the solution
  write-host 'Solution Path--' $solutionPath 

# Define MSBuild arguments
$msbuildArgs = @(
    "`"$solutionPath`"",
    "/t:Lw_Domain_Custom:Transform",
    "/p:TransformFile=*EntityModelGenerator.tt",
    "/p:Configuration=Release",
    "/p:Platform=`"Any CPU`""
)

# Run MSBuild
Write-Host "Running MSBuild..."
& $msbuildPath $msbuildArgs

# Check for errors
if ($LASTEXITCODE -ne 0) {
    Write-Error "MSBuild failed with exit code: $LASTEXITCODE"
    exit $LASTEXITCODE
} else {
    Write-Host "MSBuild completed successfully."
}

}


function BuildSolution {
  Param($msbuildPath,$solutionPath,$BuildOutputPath)

   # Define the path to MSBuild.exe
  write-host 'MS Build Path' $msbuildPath 

# Ensure the MSBuild path exists
if (-Not (Test-Path $msbuildPath)) {
    Write-Error "MSBuild.exe not found at path: $msbuildPath"
    exit 1
}

# Define the path to the solution
  write-host 'Solution Path--' $solutionPath 

# Define MSBuild arguments
$msbuildArgs = @(
    "`"$solutionPath`"",
    "/p:outdir=$BuildOutputPath",
    "/p:Configuration=Release",
    "/p:Platform=`"Any CPU`""
)

# Run MSBuild
Write-Host "Running MSBuild..."
& $msbuildPath $msbuildArgs

# Check for errors
if ($LASTEXITCODE -ne 0) {
    Write-Error "MSBuild failed with exit code: $LASTEXITCODE"
    exit $LASTEXITCODE
} else {
    Write-Host "MSBuild completed successfully."
}

  }

NugetRestore -nugetExePath $NugetExePath -solutionPath $SolutionPath -nugetConfigPath $NugetConfigPath
Write-Host '***************Nuget Restore Done***************'
RunTT -msbuildPath $MsBuildPath -solutionPath $SolutionPath
Write-Host '***************Run TT is Done***************'
BuildSolution -msbuildPath $MsBuildPath -solutionPath $SolutionPath -BuildOutputPath $BuildOutputPath
Write-Host '***************Build Solution is Done***************'


