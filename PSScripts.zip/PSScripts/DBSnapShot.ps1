#$SQLServer = 'lwo-MittalM' 'LW_Main' 'D:\3\'
Param (
$SQLServer,
$DBName,
$ScriptPath
)


$SQLDBQuery = "select SERVERPROPERTY('InstanceDefaultDataPath') as 'DataPath'"
#$DBName='LW_Main'

$results = Invoke-Sqlcmd -ServerInstance $SQLServer -Query $SQLDBQuery 

write-host $results.DataPath

$ScriptPath1=$ScriptPath + 'CreateDBSnapshot.sql'
Invoke-Sqlcmd -ServerInstance $SQLServer -Database $DBName -InputFile $ScriptPath1


write-host 'SP Created'

$SQLPath= $results.DataPath
$Script= 'EXEC CreateDBSnapshot "' + $SQLPath + '","' + $DBName + '"'

Invoke-Sqlcmd -ServerInstance $SQLServer -Database $DBName -Query $Script 


