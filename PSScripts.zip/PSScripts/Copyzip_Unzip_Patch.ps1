﻿param(
[parameter (Mandatory=$true, position=1, ParameterSetName='IIS')]
[string]$SrcPackagePath,
[parameter (Mandatory=$true, position=2, ParameterSetName='IIS')]
[string]$TarPackagePath,
[parameter (Mandatory=$true, position=3, ParameterSetName='IIS')]
[string]$TarPackageLocalPath,
[parameter (Mandatory=$true, position=4, ParameterSetName='IIS')]
[string]$TarServer,
[parameter (Mandatory=$true, position=5, ParameterSetName='IIS')]
[string]$SitePath,
[parameter (Mandatory=$true, position=6, ParameterSetName='IIS')]
[string]$ServicePath,
[parameter (Mandatory=$false, position=7, ParameterSetName='IIS')]
[string]$webapipath,
[parameter (Mandatory=$false, position=8, ParameterSetName='IIS')]
[string]$docportalpath,
[parameter (Mandatory=$false, position=9, ParameterSetName='IIS')]
[string]$IsCustomerPortal,
[parameter (Mandatory=$false, position=10, ParameterSetName='IIS')]
[string]$IsPartnerPortal
)

    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") + '.zip'
    $SrcPackagePath = $SrcPackagePath + $currentDate
    $SrcPackagePath

    if((Test-Path $SrcPackagePath) -eq $false){
    Write-Host "No package found $packagePath"
    return
}

#Copying zip package to VM Cloud server Drop
write-host 'Starting zip copy'
copy-item $SrcPackagePath $TarPackagePath -Force
write-host 'Compelted zip copy'

#############################################################################################################

#Unzip the package on VM Cloud
    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd")
    $PackagePath = $TarPackageLocalPath + $currentDate
    $PackagePath
Invoke-Command -Computername $TarServer -ScriptBlock {
param ($Src,$Dest)

$Src = $Src + ".zip"
      
         write-host 'Starting Unziping'
         write-host $Src $Dest
         Expand-Archive -Path $Src -DestinationPath $Dest -Force
         write-host 'Completed Unziping'

} -ArgumentList $PackagePath,$TarPackageLocalPath

##############################################################################################################
Write-Host 'Starting Package Config Cleanup'
Invoke-Command -Computername $TarServer -ScriptBlock {
param ($PackagePath)
         $ttPath = $PackagePath + "\*.tt"
if ( Test-Path $ttPath)
{
    Remove-Item -Path $ttPath -Recurse -force
}

Remove-Item –path $PackagePath -include AppSettings.config –recurse
Remove-Item –path $PackagePath -include ConnectionStrings.config –recurse
Remove-Item –path $PackagePath -include Lw.WindowsServices.exe.config –recurse
Remove-Item –path $PackagePath -include Web.config –recurse
}-ArgumentList $PackagePath
Write-Host 'Completed Package Config Cleanup'

##############################################################################################################
#Patch to Site , Service
Invoke-Command -Computername $TarServer -ScriptBlock {
param ($PackagePath,$SitePath,$ServicePath, $IsCustomerPortal, $IsPartnerPortal)
        
        if((Test-Path $SitePath) -eq $false){
         Write-Host "LessorPortal path - $sitePath not found"
              return
         }

        Remove-Item -Path $SitePath -Exclude *.config,*.bat -Force -Recurse -Verbose
      <#   $DBContext = $SitePath + "\DomainAssemblies\LeasewaveRepositoryDbContext.Views"
        if ( Test-Path $DBContext)
        {
           Remove-Item -Path $DBContext -Recurse -force
           Write-Host "Deleted" $DBContext
        }
        $DTMPPath = $SitePath + "\DomainAssemblies\temp"
        if ( Test-Path $DTMPPath)
        {
           Remove-Item -Path $DTMPPath -Recurse -force -ErrorAction Ignore
           Write-Host "Deleted" $DTMPPath
        }
       #> 

         Write-Host 'Starting LessorPortal patch'
         if($IsCustomerPortal -eq '1')  
         {
            $LessorPortal = $PackagePath + '\CustomerPortal'
         }
         elseif($IsPartnerPortal -eq '1')
         {
            $LessorPortal = $PackagePath + '\PartnerPortal'
         }
         else
         {
            $LessorPortal = $PackagePath + '\LessorPortal'
         }
         Write-Host $LessorPortal $SitePath

         Robocopy $LessorPortal $SitePath /S /E /Z /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /XO /COPY:DT
         Write-Host 'LessorPortal patch Done'

##############################################################################################################
         
         <# if((Test-Path $ServicePath) -eq $false){
         Write-Host "WindowsService path - $ServicePath not found"
              return
         }

         Remove-Item -Path $ServicePath -Exclude *.config,*.bat -Force -Recurse -Verbose


         Write-Host 'Starting WindowsService patch'
         $WindowsService = $PackagePath + '\WindowsService'
         Write-Host $WindowsService $ServicePath

         Robocopy $WindowsService $ServicePath /S /E /Z /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /XO
         Write-Host 'WindowsService patch Done' #>

} -ArgumentList $PackagePath,$SitePath,$ServicePath, $IsCustomerPortal, $IsPartnerPortal

##############################################################################################################
#Patch to WebAPI
Invoke-Command -Computername $TarServer -ScriptBlock {
param ($PackagePath,$webapipath)
if(!([string]::IsNullOrEmpty($webapipath)) -and (Test-path $webapipath)){
    
   
         
         Remove-Item -Path $webapipath -Exclude *.config,*.bat -Force -Recurse -Verbose

         Write-Host 'Starting WebAPI patch'
         $WebAPI = $PackagePath + '\WebAPI'
         Write-Host $WebAPI $webapipath

         Robocopy $WebAPI $webapipath /S /E /Z /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /XO /COPY:DT
         Write-Host 'WebAPI patch Done'
}
else{
  Write-Host 'No WebAPI Patch'
}
} -ArgumentList $PackagePath,$webapipath

##############################################################################################################
#Patch to DocPortal
Invoke-Command -Computername $TarServer -ScriptBlock {
param ($PackagePath,$docportalpath)
if(!([string]::IsNullOrEmpty($docportalpath)) -and (Test-path $docportalpath)){
    
         Remove-Item -Path $docportalpath -Exclude *.config,*.bat -Force -Recurse -Verbose

         Write-Host 'Starting DocPortal patch'
         $DocPortal = $PackagePath + '\DocPortal'
         Write-Host $DocPortal $docportalpath

         Robocopy $DocPortal $docportalpath /S /E /Z /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /XO /COPY:DT
         Write-Host 'DocPortal patch Done'

}
else{
  Write-Host 'No DocPortal Patch'
}
 } -ArgumentList $PackagePath,$docportalpath

if ($lastexitcode -lt 8) { $lastexitcode = 0 }