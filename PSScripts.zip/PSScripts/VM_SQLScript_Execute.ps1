﻿Param (

[parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
[string]$SQLServer,
[parameter (Mandatory=$true, position=1, ParameterSetName='Database')]
[string]$DatabaseName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Database')]
[string]$DB_UserName,
[parameter (Mandatory=$true, position=3, ParameterSetName='Database')]
[string]$DB_Password,
[parameter (Mandatory=$true, position=4, ParameterSetName='Database')]
[string]$PackagePath,
[parameter (Mandatory=$false, position=5, ParameterSetName='Database')]
[string]$IsDDLDMLConsolidated = '0',
[parameter (Mandatory=$false, position=6, ParameterSetName='Database')]
[string]$IsDBOnly = '0',
[parameter (Mandatory=$false, Position=7, ParameterSetName='Database')]
[string]$issqlmi  

)

Write-Host $SQLServer $DatabaseName $DB_UserName $PackagePath

if($IsDBOnly -eq '0')
{
    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd")     
    $FolderPath1 = $PackagePath + "\" + $currentDate + "\"    
    $FolderPath = $FolderPath1 + 'Database\DBScripts\'
}
else
{
    $FolderPath = $PackagePath
}

##Returns last releaseversion Id from ReleaseVersions Table
function global:GetLastReleaseVersionNumber() {
  $strSQL = "
      SELECT CASE WHEN EXISTS(SELECT * FROM ReleaseVersions) 
      THEN (SELECT TOP 1 Id FROM ReleaseVersions ORDER BY id DESC)
      ELSE NULL 
      END AS VersionNumber
      "
      
      if($issqlmi  -eq '1')
      {
        $result = invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query $strSQL  -QueryTimeout 65500
      }
      else
      {
        $result = invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Query $strSQL  -QueryTimeout 65500
      }

  if ($result -ne [System.DBNull]::Value) {
    return $result.VersionNumber 
  }
  else {
    return 1
  }
}

##Insert the scripts in ReleaseVersionDetails table if Script is not present before with IsExecuted=0
function global:InsertNewScriptsToDB() {

    Write-Host $FolderPath

    ##DDL Insertion
    $DbScriptSourceDDL = $FolderPath + 'DDL\'
    Write-Host $DbScriptSourceDDL
    

    if((Get-ChildItem $DbScriptSourceDDL  |Measure-Object).Count -eq 0 )    
    {        
            write-host "No sql scripts found..."          
       
    }    
    else 
    {        
        foreach ($filename in get-childitem -path $DbScriptSourceDDL -filter "*.sql")
        {
            try
            {
                $regex = '^[1-3][0-9]{3}_.{1,31}\.sql$'
                $found = $filename -match $regex

                Write-Host "$filename : $found"

                if($found -eq $false)
                {
                    throw "$filename have incorrect filename. Please follow the naming convention mentioned in readme file."
                }
  
                $ScriptFile= $filename.BaseName
                $LatestReleaseVersionId = GetLastReleaseVersionNumber 
                $SQLFilename = $ScriptFile.BaseName

                $SQLFilenameExecute = $DbScriptSourceDDL + $filename
                write-host 'Inserting Script to ReleaseVersionDetails Table...'                           
                write-host $filename
                                                   
                ## Update ReleaseVersionDetails table
                $InsertQuery = "INSERT INTO [dbo].[ReleaseVersionDetails] ([ReleaseScriptName],[IsExecuted],[CreatedById],[CreatedTime],[UpdatedById],[UpdatedTime],[ReleaseVersionId]) VALUES ('" + $ScriptFile + "',1,1,SYSDATETIMEOFFSET(),null,null,$LatestReleaseVersionId)"
                  
                if($issqlmi -eq '1')
                {            
                    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query $InsertQuery  -QueryTimeout 65500 -ErrorAction Stop
                }
                else
                {
                    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Query $InsertQuery  -QueryTimeout 65500 -ErrorAction Stop
                }     
            }
            catch 
            {
                throw $_.Exception.Message
            }       
        }

    }

    ##DML Insertion
    $DbScriptSourceDML = $FolderPath + 'DML\'
    Write-Host $DbScriptSourceDML

    if((Get-ChildItem $DbScriptSourceDML  |Measure-Object).Count -eq 0 )    
    {        
            write-host "No sql scripts found..."          
       
    }    
    else 
    {        
        foreach ($filename in get-childitem -path $DbScriptSourceDML -filter "*.sql")
        {
            try
            {
                $regex = '^[1-3][0-9]{3}_.{1,31}\.sql$'
                $found = $filename -match $regex

                Write-Host "$filename : $found"

                if($found -eq $false)
                {
                    throw "$filename have incorrect filename. Please follow the naming convention mentioned in readme file."
                }
  
                $ScriptFile= $filename.BaseName
                $LatestReleaseVersionId = GetLastReleaseVersionNumber 
                $SQLFilename = $ScriptFile.BaseName


                $SQLFilenameExecute = $DbScriptSourceDDL + $filename
                write-host 'Inserting Script to ReleaseVersionDetails Table...'                           
                write-host $filename
                                                   
                ## Update ReleaseVersionDetails table
                $InsertQuery = "INSERT INTO [dbo].[ReleaseVersionDetails] ([ReleaseScriptName],[IsExecuted],[CreatedById],[CreatedTime],[UpdatedById],[UpdatedTime],[ReleaseVersionId]) VALUES ('" + $ScriptFile + "',1,1,SYSDATETIMEOFFSET(),null,null,$LatestReleaseVersionId)"
                 
                if($issqlmi -eq '1')           
                {
                    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query $InsertQuery  -QueryTimeout 65500 -ErrorAction Stop
                }
                else
                { 
                    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName  -Query $InsertQuery  -QueryTimeout 65500 -ErrorAction Stop 
                }   
            }
            catch 
            {
                throw $_.Exception.Message
            }       
        }

    }
}

#DDLDML Script Consolidation

if($IsDDLDMLConsolidated -eq 1){

    $DDLDMLConsolidateScript  = $FolderPath + 'ConsolidateScripts.sql'
   
    Write-Host 'DDLDMLConsolidateScript Path - ' $DDLDMLConsolidateScript

}

if($IsDDLDMLConsolidated -eq 0)
{

    ##########  Execute DDL\DML
    if($issqlmi -eq '1')
    {
        $ReleaseVersionId= invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query 'select top 1 id from releaseversions order by ID desc'  -QueryTimeout 65500
        $Getreleasescript=invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query 'Select ReleaseScriptName from ReleaseVersionDetails order by ID'  -QueryTimeout 65500
    }
    else
    {
        $ReleaseVersionId= invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName  -Query 'select top 1 id from releaseversions order by ID desc'  -QueryTimeout 65500
        $Getreleasescript=invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName  -Query 'Select ReleaseScriptName from ReleaseVersionDetails order by ID'  -QueryTimeout 65500
    }
    #DDL Execution
    Write-Host $FolderPath
    $DbScriptSourceDDL = $FolderPath + 'DDL\'

    # Get ReleaseviersionID
    if((Get-ChildItem $DbScriptSourceDDL  |Measure-Object).Count -eq 0 )    
    {        
        write-host "No sql scripts found..."   
    }    
    else 
    {        
        foreach ($filename in get-childitem -path $DbScriptSourceDDL -filter "*.sql")
                                                                                                                                                                                                                                                                                                                        {
        try
        {
            $regex = '^[1-3][0-9]{3}_.{1,31}\.sql$'
            $found = $filename -match $regex
            Write-Host "$filename : $found"

            if($found -eq $false)
            {
                throw "$filename have incorrect filename. Please follow the naming convention mentioned in readme file."
            }
            $PWFile = $filename.BaseName.SubString(0,1)

            if($PWFile -lt "3") # Framework \ product
            {   
                $ScriptFile= $filename.BaseName

                if(!([string]::IsNullOrEmpty($Getreleasescript)))
                {
                    # check dbscript name with filename  
                    foreach ($DBScript in $Getreleasescript)
                    {
                        if($ScriptFile -eq $DBScript.ReleaseScriptName)
                        {
                            $TobeExecute=1;
                            break
                        }
                        else
                        {
                            $TobeExecute=0;
                        }
                    }
                }
                else
                {
                    $TobeExecute=0;
                }
   
                ##Verify if $TobeExecute=0 then execute script
                if($TobeExecute -eq 0)
                {
                    # Get ReleaseviersionID
                    #write-host 'Versionid ' $ReleaseVersionId.id
                    $ReleaseVersionId1 = $ReleaseVersionId.id
                    $SQLFilename = $ScriptFile.BaseName


                    ##Execute product\FRWK Actual Script
                    $SQLFilenameExecute = $DbScriptSourceDDL + $filename
                    write-host 'Executing FRWK/Product scripts' 
                    if($issqlmi -eq '1')
                    {   
                        invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -InputFile  $SQLFilenameExecute -QueryTimeout 65500 -ErrorAction Stop
                    }
                    else
                    {
                        invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName  -InputFile  $SQLFilenameExecute -QueryTimeout 65500 -ErrorAction Stop
                    }
                    write-host $filename
                         
                          

                    ## Update ReleaseVersionDetails table
                    $InsertQuery = "INSERT INTO [dbo].[ReleaseVersionDetails] ([ReleaseScriptName],[IsExecuted],[CreatedById],[CreatedTime],[UpdatedById],[UpdatedTime],[ReleaseVersionId]) VALUES ('" + $ScriptFile + "',1,1,GETDATE(),null,null,$ReleaseVersionId1)"
                    if($issqlmi -eq '1')
                    {   
                        invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -Query $InsertQuery  -QueryTimeout 65500 -ErrorAction Stop
                    }   
                    else
                    {
                        invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName  -Query $InsertQuery  -QueryTimeout 65500 -ErrorAction Stop
                    }  

                }                    
                else
                {
                    write-host 'Script Already Executed - ' $ScriptFile
                }       
            } 
            else  # Project script exec
            {
                $SQLFilenameExecute = $DbScriptSourceDDL + $filename               
                Write-Host 'Executing project scripts' 
                if($issqlmi -eq '1')
                {    
                    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -InputFile $SQLFilenameExecute -QueryTimeout 65500
                    write-host $filename
                }
                else
                {   
                    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName  -InputFile $SQLFilenameExecute -QueryTimeout 65500
                    write-host $filename
                }
            }            
        }
        catch 
        {
            throw $_.Exception.Message
        }       
    }
    }

    #DML Execution
    $DbScriptSourceDML = $FolderPath + 'DML\'

    # Get ReleaseviersionID
    if((Get-ChildItem $DbScriptSourceDML  |Measure-Object).Count -eq 0 )    
    {        
        write-host "No sql scripts found..."    
    }    
    else 
    {        
        foreach ($filename in get-childitem -path  $DbScriptSourceDML -filter "*.sql")        
        {
            $SQLFilenameExecute = $DbScriptSourceDML + $filename
        if($issqlmi -eq '1')
        {
            invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -InputFile $SQLFilenameExecute -QueryTimeout 65500                            
            write-host $filename
        }
        else
        {
            invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName  -InputFile $SQLFilenameExecute -QueryTimeout 65500                            
            write-host $filename
        }
        }
    }
}
else
{
    Write-Host 'Starting Consolidated script execution'
    $DDLDMLConsolidateScript  = $FolderPath + 'ConsolidateScripts.sql'
    write-Host $DDLDMLConsolidateScript
    if($issqlmi -eq '1')
    {
        invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -InputFile  $DDLDMLConsolidateScript -QueryTimeout 65500 -ErrorAction Stop
    }
    else
    {
        invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName  -InputFile  $DDLDMLConsolidateScript -QueryTimeout 65500 -ErrorAction Stop
    }
    write-Host 'Executed special character'
    InsertNewScriptsToDB

}