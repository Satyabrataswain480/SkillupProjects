﻿#######  This script will take site and SQL database backup.
Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='IIS')]
[string]$DB_Backup_Path,  #\\lwdeldb-003\Backups\MFM\Nightly
[parameter (Mandatory=$true, position=1, ParameterSetName='IIS')]
[string]$SQLInstance,  #LWDELDB-003
[parameter (Mandatory=$true, position=2, ParameterSetName='IIS')]
[string]$DBName  #MFM_QA

)


write-host 'DB backup deleted started.'
############  Remove Old Backups ######################
if ( Test-Path -Path $DB_Backup_Path -PathType Container )
{
    $DaysToKeep = "-2"
    $CurrentDate = Get-Date
    $DatetoDelete = $CurrentDate.AddDays($DaysToKeep)
    Get-ChildItem $DB_Backup_Path -Filter *.bak -Recurse  | Where-Object { $_.LastWriteTime -lt $DatetoDelete } | Remove-Item -Recurse
}
else
{
    New-Item $DB_Backup_Path -ItemType Directory
}

write-host 'DB backup deleted completed.'
############   DB Backup ##########################

$timeStamp = Get-Date -format yyyy_MM_dd_HHmmss 

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null 

$srv = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $SQLInstance 
$dbs = New-Object Microsoft.SqlServer.Management.Smo.Database 
$dbs = $srv.Databases 

foreach ($Database in $dbs) 
{ 
 $Database.name 

 if($Database.name -eq $DBName)
 {

   $bk = New-Object ("Microsoft.SqlServer.Management.Smo.Backup") 
   $bk.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database 
   $bk.BackupSetName = $Database.Name + "_backup_" + $timeStamp 
   $bk.Database = $Database.Name 
   $bk.CompressionOption = 1 
   $bk.MediaDescription = "Disk" 
   $bk.Devices.AddDevice($DB_Backup_Path + "\" + $Database.Name + "_" + $timeStamp + ".bak", "File") 
   $bk.SqlBackup($srv)
   exit
 }
TRY {
 #$bk.SqlBackup($srv)
 } 
CATCH 
 {
 $Database.Name + " backup failed." 
 $_.Exception.Message
 } 
} 