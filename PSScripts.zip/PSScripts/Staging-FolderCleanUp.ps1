﻿Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$CustomerPortal,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Database,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$DocPortal,
[parameter (Mandatory=$true, position=3, ParameterSetName='Release')]
[string]$LessorPortal,
[parameter (Mandatory=$true, position=4, ParameterSetName='Release')]
[string]$License,
[parameter (Mandatory=$true, position=5, ParameterSetName='Release')]
[string]$MigrationTool,
[parameter (Mandatory=$true, position=6, ParameterSetName='Release')]
[string]$PricingService,
[parameter (Mandatory=$true, position=7, ParameterSetName='Release')]
[string]$Reports,
[parameter (Mandatory=$true, position=8, ParameterSetName='Release')]
[string]$SqlServices,
[parameter (Mandatory=$true, position=9, ParameterSetName='Release')]
[string]$TValueBinaries,
[parameter (Mandatory=$true, position=10, ParameterSetName='Release')]
[string]$UserManual,
[parameter (Mandatory=$true, position=11, ParameterSetName='Release')]
[string]$VendorPortal, 
[parameter (Mandatory=$true, position=12, ParameterSetName='Release')]
[string]$WebAPI,
[parameter (Mandatory=$true, position=13, ParameterSetName='Release')]
[string]$WebServices,
[parameter (Mandatory=$true, position=14, ParameterSetName='Release')]
[string]$WindowsService, 
[parameter (Mandatory=$true, position=15, ParameterSetName='Release')]
[string]$AppSettingsConfig,
[parameter (Mandatory=$true, position=16, ParameterSetName='Release')]
[string]$ReleasePath,
[parameter (Mandatory=$false, position=17, ParameterSetName='Release')]
[string]$SSISPackages,
[parameter (Mandatory=$false, position=18, ParameterSetName='Release')]
[string]$IsCustomerPortal = '1',
[parameter (Mandatory=$false, position=19, ParameterSetName='Release')]
[string]$WebandJobConfig,
[parameter (Mandatory=$false, position=20, ParameterSetName='Release')]
[string]$WebAPIConfig

)

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 

$ReleasePath = $ReleasePath + $currentDate + '\'

Write-Host "Drop Location: " $ReleasePath

if($CustomerPortal -eq 'N' -or $CustomerPortal -eq 'n')
{
    $CustPath = $ReleasePath + 'CustomerPortal\*'
    if(Test-Path $CustPath)
    {
        Remove-Item $CustPath -Force -Recurse
    }
}
if($PartnerPortal -eq 'N' -or $PartnerPortal -eq 'n')
{
    $CustPath = $ReleasePath + 'PartnerPortal\*'
    if(Test-Path $CustPath)
    {
        Remove-Item $CustPath -Force -Recurse
    }
}
if($Database -eq 'N' -or $Database -eq 'n')
{
    $DDL = $ReleasePath + 'DataBase\DBScripts\DDL\*'
    if(Test-Path $DDL)
    {
        Remove-Item $DDL -Force -Recurse
    }
    $DML = $ReleasePath + 'DataBase\DBScripts\DML\*'
    if(Test-Path $DML)
    {
        Remove-Item $DML -Force -Recurse
    }
}
if($DocPortal -eq 'N' -or $DocPortal -eq 'n')
{
    $DocPortal = $ReleasePath + 'DocPortal\*'
    if(Test-Path $DocPortal)
    {
        Remove-Item $DocPortal -Force -Recurse
    }
}
if($LessorPortal -eq 'N' -or $LessorPortal -eq 'n')
{
    $LessorPortal = $ReleasePath + 'LessorPortal\*'
    if(Test-Path $LessorPortal)
    {
        Remove-Item $LessorPortal -Force -Recurse
    }
}
if($License -eq 'N' -or $License -eq 'n')
{
    $License = $ReleasePath + 'License\*'
    if(Test-Path $License)
    {
        Remove-Item $License -Force -Recurse
    }
}
if($MigrationTool -eq 'N' -or $MigrationTool -eq 'n')
{
    $MigrationTool = $ReleasePath + 'MigrationTool\*'
    if(Test-Path $MigrationTool)
    {
        Remove-Item $MigrationTool -Force -Recurse
    }
}
if($PricingService -eq 'N' -or $PricingService -eq 'n')
{
    $PricingService = $ReleasePath + 'PricingService\*'
    if(Test-Path $PricingService)
    {
        Remove-Item $PricingService -Force -Recurse
    }
}
if($Reports -eq 'N' -or $Reports -eq 'n')
{
    $Rdls = $ReleasePath + 'Reports\RDLs\*'
    if(Test-Path $Rdls)
    {
        Remove-Item $Rdls -Force -Recurse
    }
    $ReportHelper = $ReleasePath + 'Reports\ReportHelper\*'
    if(Test-Path $ReportHelper)
    {
        Remove-Item $ReportHelper -Force -Recurse
    }
}
if($SqlServices -eq 'N' -or $SqlServices -eq 'n')
{
    $SqlServices = $ReleasePath + 'SqlServices\*'
    if(Test-Path $SqlServices)
    {
        Remove-Item $SqlServices -Force -Recurse
    }
}
if($TValueBinaries -eq 'N' -or $TValueBinaries -eq 'n')
{
    $TValueBinaries = $ReleasePath + 'TValueBinaries\*'
    if(Test-Path $TValueBinaries)
    {
        Remove-Item $TValueBinaries -Force -Recurse
    }
}
if($UserManual -eq 'N' -or $UserManual -eq 'n')
{
    $UserManual = $ReleasePath + 'UserManual\*'
    if(Test-Path $UserManual)
    {
        Remove-Item $UserManual -Force -Recurse
    }
}
if($VendorPortal -eq 'N' -or $VendorPortal -eq 'n')
{
    $VendorPortal = $ReleasePath + 'VendorPortal\*'
    if(Test-Path $VendorPortal)
    {
        Remove-Item $VendorPortal -Force -Recurse
    }
}
if($WebAPI -eq 'N' -or $WebAPI -eq 'n')
{
    $WebAPI = $ReleasePath + 'WebAPI\*'
    if(Test-Path $WebAPI)
    {
        Remove-Item $WebAPI -Force -Recurse
    }
}
if($WebServices -eq 'N' -or $WebServices -eq 'n')
{
    $WebServices = $ReleasePath + 'WebServices\*'
    if(Test-Path $WebServices)
    {
        Remove-Item $WebServices -Force -Recurse
    }
}
if($WindowsService -eq 'N' -or $WindowsService -eq 'n')
{
    $WindowsService = $ReleasePath + 'WindowsService\*'
    if(Test-Path $WindowsService)
    {
        Remove-Item $WindowsService -Force -Recurse
    }
}

if ($WindowsService -eq 'Y' -or $WindowsService -eq 'y') 
{
    $WindowsService = $ReleasePath + 'WindowsService\*'
    $AppSettingsPath = $WindowsService + 'appsettings.json'

    if (Test-Path $AppSettingsPath) {
        Remove-Item $AppSettingsPath -Force -Recurse
    }
}

if($SSISPackages -eq 'N' -or $SSISPackages -eq 'n')
{
    $SSISPackage = $ReleasePath + 'SSISPackages\*'
    if(Test-Path $SSISPackage)
    {
        Remove-Item $SSISPackage -Force -Recurse
    }
}

if($WebandJobConfig -eq 'N' -or $WebandJobConfig -eq 'n')
{
    $ConfigPath = $ReleasePath + 'Config\*'
    $exclude = "*WebAPI*"
    $Include = "web.config", "Lw.WindowsServices.exe.config", "README.md"
    if(Test-Path $ConfigPath)
    {
        get-childitem $ConfigPath\*.* -recurse | where-object{$_.fullname -notlike $exclude} | Remove-Item -Include $Include -Recurse -Force
    }
}

if($WebAPIConfig -eq 'N' -or $WebAPIConfig -eq 'n')
{
    $ConfigPath = $ReleasePath + 'Config\*'
    $exclude = "*WebAPI*"
    $Include = "web.config", "README.md"
    if(Test-Path $ConfigPath)
    {
        get-childitem $ConfigPath\*.* -recurse | where-object{$_.fullname -like $exclude} | Remove-Item -Include $Include -Recurse -Force
    }  
}

$CurrentRDL = $ReleasePath + 'DataBase\DBScripts\Reports'
if(Test-Path $CurrentRDL)
{
    write-host $CurrentRDL
    Remove-Item $CurrentRDL -Force -Recurse
}

$CurrentSSIS = $ReleasePath + 'DataBase\DBScripts\SSISPackages'
if(Test-Path $CurrentSSIS)
{
    write-host $CurrentSSIS
    Remove-Item $CurrentSSIS -Force -Recurse
}