﻿Param (

[parameter (Mandatory=$true, position=1, ParameterSetName='Version')]
[string]$StorageAccountName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Version')]
[string]$ContainerName,
[parameter (Mandatory=$true, position=3, ParameterSetName='Version')]
[string]$ReleaseVersion,
[parameter (Mandatory=$true, position=4, ParameterSetName='Version')]
[string]$ProjectCode,
[parameter (Mandatory=$true, position=5, ParameterSetName='Version')]
[string]$PackageFolder,
[parameter (Mandatory=$true, position=6, ParameterSetName='Version')]
[string]$CustomerPortal,
[parameter (Mandatory=$true, position=7, ParameterSetName='Version')]
[string]$Database,
[parameter (Mandatory=$true, position=8, ParameterSetName='Version')]
[string]$DocPortal,
[parameter (Mandatory=$true, position=9, ParameterSetName='Version')]
[string]$LessorPortal,
[parameter (Mandatory=$true, position=10, ParameterSetName='Version')]
[string]$License,
[parameter (Mandatory=$true, position=11, ParameterSetName='Version')]
[string]$MigrationTool,
[parameter (Mandatory=$true, position=12, ParameterSetName='Version')]
[string]$PricingService,
[parameter (Mandatory=$true, position=13, ParameterSetName='Version')]
[string]$Reports,
[parameter (Mandatory=$true, position=14, ParameterSetName='Version')]
[string]$SqlServices,
[parameter (Mandatory=$true, position=15, ParameterSetName='Version')]
[string]$TValueBinaries,
[parameter (Mandatory=$true, position=16, ParameterSetName='Version')]
[string]$UserManual,
[parameter (Mandatory=$true, position=17, ParameterSetName='Version')]
[string]$VendorPortal, 
[parameter (Mandatory=$true, position=18, ParameterSetName='Version')]
[string]$WebAPI,
[parameter (Mandatory=$true, position=19, ParameterSetName='Version')]
[string]$WebServices,
[parameter (Mandatory=$true, position=20, ParameterSetName='Version')]
[string]$WindowsService,
[parameter (Mandatory=$true, position=21, ParameterSetName='Version')]
[string]$ToEmail,
[parameter (Mandatory=$true, position=22, ParameterSetName='Version')]
[string]$ReleaseDate,
[parameter (Mandatory=$true, position=23, ParameterSetName='Version')]
[string]$ReleaseTime,
[parameter (Mandatory=$true, position=24, ParameterSetName='Version')]
[string]$COTicket,
[parameter (Mandatory=$true, position=25, ParameterSetName='Version')]
[string]$AppSettingsConfig,
[parameter (Mandatory=$false, position=26, ParameterSetName='Version')]
[string]$SSISPackages,
[parameter (Mandatory=$false, position=27, ParameterSetName='Version')]
[string]$WebandJobConfig,
[parameter (Mandatory=$false, position=28, ParameterSetName='Version')]
[string]$WebAPIConfig,
[parameter (Mandatory=$false, position=29, ParameterSetName='Version')]
[string]$PartnerPortal
)

function Send-Email(){
    param(
        [string]$smtpServer = "mail.odessatech.in",
        [string]$ComputerName = $env:ComputerName,
        [string]$from = "Delivery-Devops@odessainc.com",
        [string]$to = "Delivery-Devops@odessainc.com",
        [string]$coticketno = "N/A"
    )
    
    try { 

        #Creating a Mail object
        $msg = new-object Net.Mail.MailMessage    

        #Creating SMTP server object
        $smtp = new-object Net.Mail.SmtpClient($smtpServer,25) 
        #$smtp.EnableSsl = $true 
        $smtp.Credentials = New-Object System.Net.NetworkCredential("no-reply@odessatech.in", "password-1"); 

        #Email structure 
        $msg.From = $from
        $msg.ReplyTo = "noreply@odessatech.in"
        $msg.To.Add($to)

        $msg.subject ='Release Package Uploaded - ' + $coticketno
        $msg.body = $global:MailBody
        $msg.IsBodyHtml = 1       

        #Sending email 
        write-host 'Email sending...'
        $smtp.Send($msg)
        write-host 'Email Sent...'
  } catch {
        Write-Warning $_
  }
}

function GenerateReport
{
    if($AppSettingsConfig -eq 'Y' -or $AppSettingsConfig -eq 'y')
    {
        $global:MailBody += "<tr><td> Appsettings Config </td><td> Yes </td></tr>"
    }

    if($CustomerPortal -eq 'Y' -or $CustomerPortal -eq 'y')
    {
        $global:MailBody += "<tr><td> Customer Portal </td><td> Yes </td></tr>"
    }

    if($PartnerPortal -eq 'Y' -or $PartnerPortal -eq 'y')
    {
        $global:MailBody += "<tr><td> Partner Portal </td><td> Yes </td></tr>"
    }

    if($Database -eq 'Y' -or $Database -eq 'y')
    {
        $global:MailBody += "<tr><td> Database </td><td> Yes </td></tr>"
    }

    if($DocPortal -eq 'Y' -or $DocPortal -eq 'y')
    {
        $global:MailBody += "<tr><td> Doc Portal </td><td> Yes </td></tr>"
    }

    if($LessorPortal -eq 'Y' -or $LessorPortal -eq 'y')
    {
        $global:MailBody += "<tr><td> Lessor Portal </td><td> Yes </td></tr>"
    }

    if($License -eq 'Y' -or $License -eq 'y')
    {
        $global:MailBody += "<tr><td> License </td><td> Yes </td></tr>"
    }

    if($MigrationTool -eq 'Y' -or $MigrationTool -eq 'y')
    {
        $global:MailBody += "<tr><td> Migration Tool </td><td> Yes </td></tr>"
    }

    if($PricingService -eq 'Y' -or $PricingService -eq 'y')
    {
        $global:MailBody += "<tr><td> Pricing Service </td><td> Yes </td></tr>"
    }

    if($Reports -eq 'Y' -or $Reports -eq 'y')
    {
        $global:MailBody += "<tr><td> Reports </td><td> Yes </td></tr>"
    }

    if($SqlServices -eq 'Y' -or $SqlServices -eq 'y')
    {
        $global:MailBody += "<tr><td> Sql Services </td><td> Yes </td></tr>"
    }

    if($TValueBinaries -eq 'Y' -or $TValueBinaries -eq 'y')
    {
        $global:MailBody += "<tr><td> TValue Binaries </td><td> Yes </td></tr>"
    }

    if($UserManual -eq 'Y' -or $UserManual -eq 'y')
    {
        $global:MailBody += "<tr><td> User Manual </td><td> Yes </td></tr>"
    }

    if($VendorPortal -eq 'Y' -or $VendorPortal -eq 'y')
    {
        $global:MailBody += "<tr><td> Vendor Portal </td><td> Yes </td></tr>"
    }

    if($WebAPI -eq 'Y' -or $WebAPI -eq 'y')
    {
        $global:MailBody += "<tr><td> Web API </td><td> Yes </td></tr>"
    }

    if($WebServices -eq 'Y' -or $WebServices -eq 'y')
    {
        $global:MailBody += "<tr><td> Web Services </td><td> Yes </td></tr>"
    }

    if($WindowsService -eq 'Y' -or $WindowsService -eq 'y')
    {
        $global:MailBody += "<tr><td> Windows Services </td><td> Yes </td></tr>"
    }

    if($SSISPackages -eq 'Y' -or $SSISPackages -eq 'y')
    {
        $global:MailBody += "<tr><td> SSISPackages </td><td> Yes </td></tr>"
    }

    if($WebandJobConfig -eq 'Y' -or $WebandJobConfig -eq 'y')
    {
        $global:MailBody += "<tr><td> WebandJobConfig </td><td> Yes </td></tr>"
    }

    if($WebAPIConfig -eq 'Y' -or $WebAPIConfig -eq 'y')
    {
        $global:MailBody += "<tr><td> WebAPIConfig </td><td> Yes </td></tr>"
    }

    $global:MailBody += "</table>"
    $global:MailBody += "<br>Regards," 
    $global:MailBody += "<br>Delivery Devops Team</br><br>"
    Send-Email -To $ToEmail -coticketno $COTicket 
}


write-host 'Report started...'
 
$global:MailBody += "Hello Cloudops Team,<br>" 
$global:MailBody += "<br>The Release package has been successfully uploaded to the blob container. Please find the details below. Thanks.</br>"
$global:MailBody += "<br>Project Code: $ProjectCode</br>"
$global:MailBody += "<br>Release Version: $ReleaseVersion</br>"
$global:MailBody += "<br>Release Date: $ReleaseDate</br>"
$global:MailBody += "<br>CO Release Time: $ReleaseTime</br>"
$global:MailBody += "<br>Storage Account: $StorageAccountName</br>"
$global:MailBody += "<br>Container Name: $ContainerName</br>"
$global:MailBody += "<br>Package Folder: $PackageFolder</br>"
$global:MailBody += "<br>Below is the list of modules included as part of this package.</br>"
      
$global:MailBody += "<br><table border=1>"
$global:MailBody += "<tr><td><b> Module Name </b></td><td><b> Included </b></td></tr>"
   
GenerateReport
 
$global:MailBody = ''
 
write-host 'Report Completed...'