﻿Param (

[parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
[string]$SQLServer,
[parameter (Mandatory=$true, position=1, ParameterSetName='Database')]
[string]$DatabaseName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Database')]
[string]$DB_UserName,
[parameter (Mandatory=$true, position=3, ParameterSetName='Database')]
[string]$DB_Password,
[parameter (Mandatory=$true, position=4, ParameterSetName='Database')]
[string]$PackagePath,
[parameter (Mandatory=$false, position=5, ParameterSetName='Database')]
[string]$IsDDLDMLConsolidated = '0',
[parameter (Mandatory=$false, position=6, ParameterSetName='Database')]
[string]$IsDBOnly = '0'  

)

Write-Host $SQLServer $DatabaseName $DB_UserName $PackagePath


if($IsDDLDMLConsolidated -eq 0)
{
    #DDL Execution
    $DbScriptSourceDDL = $PackagePath+ 'DDL\'

    # Get ReleaseviersionID
    if((Get-ChildItem $DbScriptSourceDDL |Measure-Object).Count -eq 0 )    
    {        
        write-host "No sql scripts found..."    
    }    
    else 
    {        
        foreach ($filename in get-childitem -path  $DbScriptSourceDDL -filter "*.sql")        
        {
            try
            {
                Write-Host 'Started Executing DDL SQL Scripts'
                $SQLFilenameExecute = $DbScriptSourceDDL  + $filename
                invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -InputFile $SQLFilenameExecute -QueryTimeout 65500                            
                write-host $filename
            }
            catch 
            {
                Write-Host "Syntax Error: $_" -ForegroundColor Red
                exit -1
            }
        }
    }

    #DML Execution
    $DbScriptSourceDML = $PackagePath+ 'DML\'

    # Get ReleaseviersionID
    if((Get-ChildItem $DbScriptSourceDML  |Measure-Object).Count -eq 0 )    
    {        
        write-host "No sql scripts found..."    
    }    
    else 
    {        
        foreach ($filename in get-childitem -path  $DbScriptSourceDML -filter "*.sql")        
        {
            try
            {
                Write-Host 'Started Executing DML SQL Scripts'
                $SQLFilenameExecute = $DbScriptSourceDML + $filename
                invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -InputFile $SQLFilenameExecute -QueryTimeout 65500                            
                write-host $filename
            }
            catch 
            {
                Write-Host "Syntax Error: $_" -ForegroundColor Red
                exit -1
            }
            
        }
    }
}
else
{
    Write-Host 'Starting Consolidated script execution'
    $DDLDMLConsolidateScript  = $PackagePath + 'ConsolidateScripts.sql'
    write-Host $DDLDMLConsolidateScript
    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -Username $DB_UserName -Password $DB_Password -InputFile  $DDLDMLConsolidateScript -QueryTimeout 65500 -ErrorAction Stop
    write-Host 'Executed special character'
    InsertNewScriptsToDB

}