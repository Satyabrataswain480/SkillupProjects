## MERGE CONFIG GENERATION ##
param(
	$basePath,
    $projectName
)
#$basePath = "D:\Test"
#$projectName = "CSI"

Write-Host "==============================================================================="
Write-Host "Dotcover Merge config genearation started."
Write-Host ""

function ChangeToLocalPath{
    param($path)
    $url = [System.Uri]::new($path)
    $p = $url.AbsolutePath.Remove(0,1).Replace("/","\").Replace("$",":")
    return $p
    #return $path
}

$otOutputPath = ChangeToLocalPath "$basePath\Output"
$utOutputPath = ChangeToLocalPath "$basePath\Output"
$mergeOutputPath = ChangeToLocalPath "$basePath\Output"


$ot_dcvr="$otOutputPath\$projectName"+"_OT_CoverageReport.dcvr"
$ut_dcvr="$utOutputPath\$projectName"+"_UnitTest_CoverageReport.dcvr"
$merge_dcvr = "$mergeOutputPath\$projectName"+"_Merged_CoverageReport.dcvr"
$configLocation = "$basePath\$projectName\Configs"
$htmlFile = "$mergeOutputPath\$projectName"+"_Merged_CoverageReport.html"
$otconfigName = 'Merge_Config.xml'
$otReportconfigName = "Merge_Report.xml"


$newNode = @"
<MergeParams>
  <Source>$ot_dcvr</Source>
  <Source>$ut_dcvr</Source>
  <Output>$merge_dcvr</Output>
</MergeParams>
"@

$file = Get-Item -Path "$configLocation\$otconfigName" -ErrorAction Ignore
if($file -eq $null){
    New-Item "$configLocation\$otconfigName" -ItemType File
    Set-Content "$configLocation\$otconfigName" $newNode
    Write-Host ""
    Write-Host "$otconfigName Generated..."
}else {
    Write-Host "$otconfigName already exists..."
}

Write-Host "==============================================================================="

$newNode = @"
<?xml version="1.0" encoding="utf-8"?>
<ReportParams>
  <Source>$merge_dcvr</Source>
  <Output>$htmlFile</Output>
  <ReportType>html</ReportType>
</ReportParams>
"@

$file = Get-Item -Path "$configLocation\$otReportconfigName" -ErrorAction Ignore
if($file -eq $null){
    New-Item "$configLocation\$otReportconfigName" -ItemType File
    Set-Content "$configLocation\$otReportconfigName" $newNode
    Write-Host ""
    Write-Host "$otReportconfigName Generated..."
}else {
    Write-Host "$otReportconfigName already exists..."
}
Write-Host "==============================================================================="
Write-Host ""
Write-Host "Dotcover Merge config genearation completed."
Write-Host "==============================================================================="
