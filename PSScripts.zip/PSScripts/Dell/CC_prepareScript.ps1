param(
   $basePath,
   $projectName,
   $otCollectionName,
   $bu = 'defaultBU',
   $username,
   $password,
   $apiUrl='http://lwdelbuild-001:8090/codecoverage/add',
   $fileName='CodeCoverageTemplate.ps1',
   $dashboardProjectName = 'default',
   $IsZephyrChangeRequired,
   $codeCoverageServerName
)

#$basePath = "D:\Test"
#$projectName = "CSI"
#$otCollectionName = "somecollection"

$sitePath = "$basePath\$projectName\Site"
$siteName = "DotCoverAutomation_$projectName"
$iisConfigPath = "$basePath\applicationhost.config"
$configLocation = "$basePath\$projectName\Configs"
$targetName = $siteName
$otconfigName = 'OT_Config.xml'
$otReportconfigName = 'OT_Report.xml'
$unitTestConfigName = 'UT_Config.xml'
$mergeConfig = 'Merge_Config.xml'
$unitTestReportConfig = 'UT_Report.xml'
$mergeReportConfig = 'Merge_Report.xml'

[xml]$xml = Get-Content -Path $iisConfigPath
$targetNode = Select-Xml -Xml $xml -XPath "//site[@name='$targetName']"
$id = $targetNode.Node.Attributes['id'].value
$port = $targetNode.Node.bindings.binding.Attributes["bindingInformation"].value -replace "[^0-9]", ""

function ChangeToLocalPath{
    param($path)
    $url = [System.Uri]::new($path)
    $p = $url.AbsolutePath.Remove(0,1).Replace("/","\").Replace("$",":")
    return $p
    #return $path
}


Write-Host "Dotcover config genearation Completed."
Write-Host "==============================================================================="
Write-Host ""

$pspath = "$basePath\$projectName\Script\$fileName"
$content = Get-Content -path $pspath -Raw
$localPath = ChangeToLocalPath $basePath
$configLocation = ChangeToLocalPath $configLocation
$iisConfigPath = ChangeToLocalPath $iisConfigPath

[regex]$pattern = "defaultBU#"
$content = $pattern.replace($content, $bu, 1) 

$content =$content -replace "##PROJECT##", "'$projectName'"
$content =$content -replace "##PORT##", "'$port'"
$content =$content -replace "##COLLECTIONNAME##", "'$otCollectionName'"
$content =$content -replace "##INSTANCEID##", "'$id'"
$content =$content -replace "##iisExpressConfigRoot##", "'$configLocation\$otconfigName'"
$content =$content -replace "##reportConfig_OT##", "'$configLocation\$otReportconfigName'"
$content =$content -replace "##OTWorkspace##", "'$localPath\$projectName\OT'"
$content =$content -replace "##OTEXE##", "'$localPath\$projectName\OT\Binaries\Odessa.exe'"
$content =$content -replace "##projectPath##", "'$sitePath'"
$content =$content -replace "##unitTestConfig##", "'$configLocation\$unitTestConfigName'"
$content =$content -replace "##mergeConfig##", "'$configLocation\$mergeConfig'"
$content =$content -replace "##unitTestReportConfig##", "'$configLocation\$unitTestReportConfig'"
$content =$content -replace "##mergeReportConfig##", "'$configLocation\$mergeReportConfig'"
$content =$content -replace "##PSLOGPATH##", "'E:\DoNotDelete\DotCover\Logs'"
$content =$content -replace "##USERNAME##", "'$username'"
$content =$content -replace "##PASSWORD##", "'$password'"
$content =$content -replace "##APIURL##", "'$apiUrl'"
$content =$content -replace "##REALPROJECTNAME##", "'$dashboardProjectName'"
$content =$content -replace "##ZephyrChange##", "'$IsZephyrChangeRequired'"
$content =$content -replace "##codeCoverageServerName##", "'$codeCoverageServerName'"

Set-Content -Path $pspath -Value $content
