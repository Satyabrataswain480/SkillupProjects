param(
    $psTemplatePath,
    $path,
    $projectName
)
    
function CreateDirectories{
param([string]$path)
  $path1 = "$path\Site"
  $path2 = "$path\OT"
  $path3 = "$path\Configs"
  $path4 = "$path\Script"
  $path5 = "$path\Test"
  if(!(Test-Path $path1)){
    New-Item $path1 -ItemType Directory
  }if(!(Test-Path $path2)){
    New-Item $path2 -ItemType Directory
  }if(!(Test-Path $path3)){
    New-Item $path3 -ItemType Directory
  }if(!(Test-Path $path4)){
    New-Item $path4 -ItemType Directory
  }if(!(Test-Path $path5)){
    New-Item $path5 -ItemType Directory
  }
  Copy-Item -Filter *.ps1 -Path $psTemplatePath -Destination $path4 -Recurse -Force


}
$path = "$path/$projectName"
CreateDirectories $path 