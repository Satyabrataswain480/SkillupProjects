##IIS CONFIGURATION##

param(
    $basePath,
    $projectName
)
#$basePath = "D:\Test"
#$projectName = "CSI"


$path = "$basePath\applicationhost.config"
$sitePath = "$basePath\$projectName\Site"
$siteName = "DotCoverAutomation_$projectName"
$targetName = $siteName

function ChangeToLocalPath{
    param($path)
    $url = [System.Uri]::new($path)
    $p = $url.AbsolutePath.Remove(0,1).Replace("/","\").Replace("$",":")
    return $p
}

[xml]$xml = Get-Content -Path $path
$targetNode = Select-Xml -Xml $xml -XPath "//site[@name='$targetName']"

$sitePath = ChangeToLocalPath $sitePath

Write-Host "==============================================================================="
Write-Host "IIS Express configuration Started."

if($targetNode -ne $null){ 
    Write-Host "Site already configured."
    Write-Host "==============================================================================="
    return
}

$nodes = $xml.configuration.'system.applicationHost'.sites.ChildNodes
$maxId = 1
$maxport = 1

foreach ($node in $nodes) {
    [int]$id = $node.attributes['id'].value
        if($id -ne $null -and $id -gt $maxId) {
            $maxId = $id
            $ports = $node.bindings.binding.attributes['bindingInformation'].value
            foreach ($port in $ports)
            {
                [int]$portnumber = $port -replace "[^0-9]", ""
                if($portnumber -gt $maxport){
                    $maxport = $portnumber
                }

            }
        }
}

$xpathValue = "//site[@id='$maxid']"
$targetNode = Select-Xml -Xml $xml -XPath $xpathValue

$maxId++
$maxport++

$bindingInformation = "*:" + [string]$maxport + ":localhost"

$newNode = [xml]@"
<site name="$targetName" id="$maxId" serverAutoStart="true">
                <application path="/" applicationPool="Clr4IntegratedAppPool">
                    <virtualDirectory path="/" physicalPath="$sitePath" />
                </application>
                <bindings>
                    <binding protocol="http" bindingInformation="$bindingInformation" />
                </bindings>
            </site>	
"@

$newNode = $xml.ImportNode($newNode.site,$true)
$xml.configuration.'system.applicationHost'.sites.InsertAfter($newNode,$targetNode.Node) |out-null

$xml.Save($path)
Start-Sleep -Seconds 10

Write-Host "IIS express configured for site $targetName with portnumber: $maxport Id: $maxId"

Write-Host "==============================================================================="