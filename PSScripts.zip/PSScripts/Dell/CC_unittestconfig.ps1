## UNITTEST CONFIG GENERATION ##
param(
 $basePath,
 $projectName,
 $dll,
 $targetExe,
 $vsTestVersion
)
#$basePath = "D:\Test"
#$projectName = "CSI"
#$dll ="Lw.Domain.Project.Extension"
#$vsVersion = "15.0"

if( $vsTestVersion -eq '2022'){
 $targetExe = "C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\IDE\CommonExtensions\Microsoft\TestWindow\vstest.console.exe"
}
else{
 $targetExe = "C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\Common7\IDE\CommonExtensions\Microsoft\TestWindow\vstest.console.exe"
}

$sitePath = "$basePath\$projectName\Site"
$siteName = "DotCoverAutomation_$projectName"
$path = "$basePath\applicationhost.config"
$targetName = $siteName

$targetWorkingDir = "$basePath\$projectName\"
$targetArg = "$basePath\$projectName\Test\Lw.Test.dll"


function ChangeToLocalPath{
    param($path)
    $url = [System.Uri]::new($path)
    $p = $url.AbsolutePath.Remove(0,1).Replace("/","\").Replace("$",":")
    return $p
    #return $path
}
$outputPath = ChangeToLocalPath "$basePath\Output"

[xml]$xml = Get-Content -Path $path
$targetNode = Select-Xml -Xml $xml -XPath "//site[@name='$targetName']"
$id = $targetNode.Node.Attributes['id'].value
$port = $targetNode.Node.bindings.binding.Attributes["bindingInformation"].value -replace "[^0-9]", ""

Write-Host "==============================================================================="
Write-Host "Dotcover Unit Test config genearation started."
Write-Host ""

$otconfigName = 'UT_Config.xml'
$otReportconfigName = 'UT_Report.xml'
$dcvrFileName = $projectName+"_UnitTest_CoverageReport.dcvr"
$htmlFileName = $projectName+"_UnitTest_CoverageReport.html"
$configLocation = "$basePath\$projectName\Configs"
$targetWorkingDir = ChangeToLocalPath $targetWorkingDir
$targetArg = ChangeToLocalPath $targetArg

$newNode = @"
<?xml version="1.0" encoding="utf-8"?>
<CoverageParams>
  <TargetExecutable>$targetExe</TargetExecutable>
  <TargetArguments>$targetArg</TargetArguments>
  <TargetWorkingDir>$targetWorkingDir</TargetWorkingDir>
  <TempDir><!-- Directory for auxiliary files. Set to the system temp by default. --></TempDir>
  <Output>$outputPath\$dcvrFileName</Output>
  <InheritConsole>True</InheritConsole>
  <AnalyzeTargetArguments>True</AnalyzeTargetArguments>
  
  <Filters>
    <IncludeFilters>
      <FilterEntry>
	   <ModuleMask>$dll</ModuleMask>
       </FilterEntry>
    </IncludeFilters>
  </Filters>
</CoverageParams>
"@

$file = Get-Item -Path "$configLocation\$otconfigName" -ErrorAction Ignore
if($file -eq $null){
    New-Item "$configLocation\$otconfigName" -ItemType File
    Set-Content "$configLocation\$otconfigName" $newNode
    Write-Host ""
    Write-Host "$otconfigName Generated..."
}else {
    Write-Host "$otconfigName already exists..."
}

Write-Host "==============================================================================="

$newNode = @"
<?xml version="1.0" encoding="utf-8"?>
<ReportParams>
  <Source>$outputPath\$dcvrFileName</Source>
  <Output>$outputPath\$htmlFileName</Output>
  <ReportType>html</ReportType>
</ReportParams>
"@

$file = Get-Item -Path "$configLocation\$otReportconfigName" -ErrorAction Ignore
if($file -eq $null){
    New-Item "$configLocation\$otReportconfigName" -ItemType File
    Set-Content "$configLocation\$otReportconfigName" $newNode
    Write-Host ""
    Write-Host "$otReportconfigName Generated..."
}else {
    Write-Host "$otReportconfigName already exists..."
}
Write-Host "==============================================================================="
Write-Host ""
Write-Host "Dotcover Unit Test config genearation completed."
Write-Host "==============================================================================="