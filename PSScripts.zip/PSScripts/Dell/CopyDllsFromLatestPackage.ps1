param(
    $packagePath,
    $targetPath,
    $lessorportalName = 'LessorPortal'
)

$p = Get-ChildItem $packagePath | ? { $_.PSIsContainer } | sort CreationTime -desc | select -f 1
$path = $p.FullName
$path1 = "$path\$lessorportalName\bin"
$path2 = "$path\$lessorportalName\DomainAssemblies"

$path1
$path2

#$targetPath = "$targetPath\build"

if(!(Test-Path $targetPath)){
    New-Item -Path $targetPath -ItemType Directory
}

$targetPath

Copy-Item -Path $path1\Lw.Domain*.dll -Destination $targetPath -Force
Copy-Item -Path $path2\Lw.Domain.dll -Destination $targetPath -Force