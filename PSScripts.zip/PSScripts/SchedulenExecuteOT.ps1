#$ot_base_local = 'E:\DeliveryDevops\GitProjects'
#$projectName= 'CSI'
#$ot_runName='CSI_Automation_001'
#$ot_appl_url='http://csiautomation.del4.odessadev.local'
#$ot_collectionName='Test_Auto'
#$ot_logfolder='\\lwdeljob-004\DeliveryDevops\GitProjects\OTLogs'
#$ot_server= 'LWDELJOB-004'
#$ot_server_psConfig='Devops'


#$otexe = "$ot_base_local\$projectName\Binaries\Odessa.exe"
#$otws = "$ot_base_local\$projectName"
#$OTRunName = "$ot_runName"
#$WebApplicationurl = "$ot_appl_url"
#$OTScenarioCollectionName = "$ot_collectionName"
#$OTLogsFolder = "$ot_logfolder"
#$OTServer = "$ot_server"
#$psConfig = "$ot_server_psConfig"

param(

[string] $otexe,
[string] $otws,
[string] $OTRunName,
[string] $WebApplicationurl,
[string] $OTScenarioCollectionName,
[string] $OTLogsFolder,
[string] $OTServer
)
 write-host $otexe
 write-host $otws 
 write-host $OTRunName
 write-host $WebApplicationurl
 write-host $OTScenarioCollectionName
 write-host $OTLogsFolder
 write-host $OTServer
              
$result = Invoke-Command -ComputerName $OTServer -ScriptBlock {
function CreateSCTask{
param([string]$OTExe, [string]$arg, [string]$name)
  $task = Get-ScheduledTaskInfo -TaskName $name -ErrorAction Ignore

  if($task){
      Unregister-ScheduledTask -TaskName $name -Confirm:$false
  }

  $taskAction = New-ScheduledTaskAction -Execute $OTExe -Argument $arg
  
  Register-ScheduledTask -TaskName $name -Action $taskAction -User 'ODESSAPDC01\devops.admin' -Password 'Password@123'
  Start-ScheduledTask -TaskName $name
}

function Run-OTScenarios{
param(
  [string]$OTExe, [string]$OTRunName, [string]$WebApplicationurl, [string]$OTWorkspace, [string]$OTScenarioCollectionName, [string]$OTLogsFolder
)
    $logfile = $OTLogsFolder+"\$OTRunName"+"_Execute.txt"
    try
    {
        Write-Host "With runname as $OTRunName going to start on $WebApplicationurl under workspace $OTWorkspace to run collection named $OTScenarioCollectionName"
         
        $arguments = "-Operation Execute -DeploymentPath $WebApplicationurl -WorkingDirectory $OTWorkspace -Scenarios $OTScenarioCollectionName -Collection true -RunName $OTRunName -LogsFolder $OTLogsFolder"
        Write-Host $OTExe
        Write-Host $arguments
        
        CreateSCTask $OTExe $arguments $OTRunName
        
        
        write-host "OT has been scheduled successfully" -f Green
        #if(Test-Path $logfile){
        #    $log = Get-Content $logfile
        #    write-host $log
        #    return $log
        #}

    }
    catch
    {
      Write-Host "##error## occurred:"
      throw $_
    }
}                
 Run-OTScenarios $using:otexe $using:OTRunName $using:WebApplicationurl $using:otws $using:OTScenarioCollectionName $using:OTLogsFolder
}  