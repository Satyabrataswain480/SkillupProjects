﻿Param  (
[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Source,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Destination,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$Flag
)

#Creating new folders
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$Destination = $Destination + $currentDate
$Config = $Destination + '\Config'

if(Test-Path $Config)
{
  Remove-Item $Config -Recurse -Force
}
New-Item -Name 'Config'  -ItemType Directory -Path $Destination
New-Item -Name 'UAT'  -ItemType Directory -Path $Config
New-Item -Name 'Prod' -ItemType Directory -Path $Config
New-Item -Name 'IntStaging' -ItemType Directory -Path $Config
New-Item -Name 'QA' -ItemType Directory -Path $Config
##

if($Flag -eq 'y' -or $Flag -eq 'Y')
{ 
    $UATSource = $Source + '\UAT\*'
    $ConfigUAT = $Destination + '\Config\UAT'
    
    if(Test-path $ConfigUAT)
    {
        
        write-host $UATSource $ConfigUAT 'Starting config files copy.'
        Copy-Item $UATSource $ConfigUAT -Recurse -Force
        write-host 'Completed config files copy.'
    }
    
    $ProdSource = $Source + '\Prod\*'
    $ConfigProd = $Destination + '\Config\Prod'
       
    if(Test-path $ConfigProd)
    {
      write-host $ProdSource $ConfigProd 'Starting config files copy.'
      Copy-Item $ProdSource $ConfigProd -Recurse -Force
      write-host 'Completed config files copy.'
    }

    $IntStagingSource = $Source + '\IntStaging\*'
    $ConfigIntStaging = $Destination + '\Config\IntStaging'
    
    if(Test-path $ConfigIntStaging)
    {
        
        write-host $IntStagingSource $ConfigIntStaging 'Starting config files copy.'
        Copy-Item $IntStagingSource $ConfigIntStaging -Recurse -Force
        write-host 'Completed config files copy.'
    }

    $QASource = $Source + '\QA\*'
    $ConfigQA = $Destination + '\Config\QA'
    
    if(Test-path $ConfigQA)
    {
        
        write-host $QASource $ConfigQA 'Starting config files copy.'
        Copy-Item $QASource $ConfigQA -Recurse -Force
        write-host 'Completed config files copy.'
    }
    
    ##Keep only Appsettings.config
    $DestinationConfig = $Destination + '\Config\'
    Remove-Item -Path $DestinationConfig -Include 'ConnectionStrings.config' -Force -Recurse
    Remove-Item -Path $DestinationConfig -Include 'Web.config' -Force -Recurse
    Remove-Item -Path $DestinationConfig -Include 'Lw.WindowsServices.exe*' -Force -Recurse

    ##ConvertConfigtoJSON
    ##UAT\APP
    $UATAppPath = $Destination + '\Config\UAT\App\Appsettings.config'
    
    & c:\scripts\Devops\ConfigToJSON\ConfigJSON.exe $UATAppPath 
    
    $ConfigAppPath = 'c:\scripts\Devops\ConfigToJSON\Appsettings.JSON'
    $ConfigUAT1 = $Destination + '\Config\UAT\App\'
    Copy-Item -Path $ConfigAppPath -Destination $ConfigUAT1
    Remove-Item $UATAppPath -Force #deleting existing appsetings.cofing bcoz converted to json

    ##UAT\JobService
    $UATJobPath = $Destination + '\Config\UAT\JobServices\Appsettings.config'
    
    & c:\scripts\Devops\ConfigToJSON\ConfigJSON.exe $UATJobPath 
    
    $ConfigJobPath = 'c:\scripts\Devops\ConfigToJSON\Appsettings.JSON'
    $ConfigUAT1 = $Destination + '\Config\UAT\JobServices\'
    Copy-Item -Path $ConfigJobPath -Destination $ConfigUAT1
    Remove-Item $UATJobPath -Force #deleting existing appsetings.cofing bcoz converted to json

    ##Prod\APP
    $ProdAppPath = $Destination + '\Config\Prod\App\Appsettings.config'
    
    & c:\scripts\Devops\ConfigToJSON\ConfigJSON.exe $ProdAppPath 
    
    $ConfigJobPath = 'c:\scripts\Devops\ConfigToJSON\Appsettings.JSON'
    $ConfigProd1 = $Destination + '\Config\Prod\App\'
    Copy-Item -Path $ConfigJobPath -Destination $ConfigProd1
    Remove-Item $ProdAppPath -Force #deleting existing appsetings.cofing bcoz converted to json

    ##Prod\JobService
    $ProdJobPath = $Destination + '\Config\Prod\JobServices\Appsettings.config'
    
    & c:\scripts\Devops\ConfigToJSON\ConfigJSON.exe $ProdJobPath 
    
    $ConfigJobPath = 'c:\scripts\Devops\ConfigToJSON\Appsettings.JSON'
    $ConfigProd1 = $Destination + '\Config\Prod\JobServices\'
    Copy-Item -Path $ConfigJobPath -Destination $ConfigProd1
    Remove-Item $ProdJobPath -Force #deleting existing appsetings.cofing bcoz converted to json

    ##IntStaging\APP
    $IntStagingAppPath = $Destination + '\Config\IntStaging\App\Appsettings.config'
    
    & c:\scripts\Devops\ConfigToJSON\ConfigJSON.exe $IntStagingAppPath 
    
    $ConfigAppPath = 'c:\scripts\Devops\ConfigToJSON\Appsettings.JSON'
    $ConfigIntStaging1 = $Destination + '\Config\IntStaging\App\'
    Copy-Item -Path $ConfigAppPath -Destination $ConfigIntStaging1
    Remove-Item $IntStagingAppPath -Force #deleting existing appsetings.cofing bcoz converted to json

    ##IntStaging\JobService
    $IntStagingJobPath = $Destination + '\Config\IntStaging\JobServices\Appsettings.config'
    
    & c:\scripts\Devops\ConfigToJSON\ConfigJSON.exe $IntStagingJobPath 
    
    $ConfigJobPath = 'c:\scripts\Devops\ConfigToJSON\Appsettings.JSON'
    $ConfigIntStaging1 = $Destination + '\Config\IntStaging\JobServices\'
    Copy-Item -Path $ConfigJobPath -Destination $ConfigIntStaging1
    Remove-Item $IntStagingJobPath -Force #deleting existing appsetings.cofing bcoz converted to json

    ##QA\APP
    $QAAppPath = $Destination + '\Config\QA\App\Appsettings.config'
    
    & c:\scripts\Devops\ConfigToJSON\ConfigJSON.exe $QAAppPath 
    
    $ConfigAppPath = 'c:\scripts\Devops\ConfigToJSON\Appsettings.JSON'
    $ConfigQA1 = $Destination + '\Config\QA\App\'
    Copy-Item -Path $ConfigAppPath -Destination $ConfigQA1
    Remove-Item $QAAppPath -Force #deleting existing appsetings.cofing bcoz converted to json

    ##QA\JobService
    $QAJobPath = $Destination + '\Config\QA\JobServices\Appsettings.config'
    
    & c:\scripts\Devops\ConfigToJSON\ConfigJSON.exe $QAJobPath 
    
    $ConfigJobPath = 'c:\scripts\Devops\ConfigToJSON\Appsettings.JSON'
    $ConfigQA1 = $Destination + '\Config\QA\JobServices\'
    Copy-Item -Path $ConfigJobPath -Destination $ConfigQA1
    Remove-Item $QAJobPath -Force #deleting existing appsetings.cofing bcoz converted to json
   

}
