param(
    $SearchKey,
    $SearchValue,
    $TargetKey,
    $TargetValue,
    $path
)

#$path = 'D:\Test\OdessaTest.config'
#$SearchKey = 'key'
#$SearchValue = 'DeploymentUrl'
#$TargetKey = 'value'
#$TargetValue = 'asdsad'

[xml]$xml = Get-Content -Path $path

$xpath = "//add[@"+ $SearchKey + "='$SearchValue'"
$xpath

$nodes = $xml.SelectNodes("//add[@key='DeploymentUrl']")

if($nodes -ne $null){
    foreach($node in $nodes) {
        $node.SetAttribute($TargetKey, $TargetValue);
    }

    $xml.Save($path)
}