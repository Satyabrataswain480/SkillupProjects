﻿Param (
[parameter (Mandatory=$true, position=0, ParameterSetName='Satellite')]
[string]$LocalizerToolPath,
[parameter (Mandatory=$true, position=1, ParameterSetName='Satellite')]
[string]$SatelliteAssemblyPath,
[parameter (Mandatory=$true, position=2, ParameterSetName='Satellite')]
[string]$Release_Path,
[parameter (Mandatory=$true, position=3, ParameterSetName='Satellite')]
[string]$Artifact_Build_Path
)

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir = $Release_Path + $currentDate

if (Test-Path $LocalizerToolPath)
{
    $LocalLTPPath = $LocalizerToolPath + '\*'
    Remove-Item $LocalLTPPath -Force -Recurse
}

if(Test-Path $Artifact_Build_Path)
{
    $OdessaLocalizer = $Artifact_Build_Path + '\*'
    Copy-item -Path $OdessaLocalizer $LocalizerToolPath  -Recurse -Force
}

if(Test-Path $SatelliteAssemblyPath)
{
    $LocalAssemblyPath = $SatelliteAssemblyPath + '\*'
    Remove-Item $LocalAssemblyPath -Force -Recurse
}

if(Test-Path $RelDir)
{
    $LPPath = $RelDir + '/LessorPortal/bin/lw.*.dll'
    if(Test-Path $LPPath)
    {
        Copy-item -Path $LPPath $LocalizerToolPath  -Recurse -Force
        Copy-item -Path $LPPath $SatelliteAssemblyPath  -Recurse -Force
    }
}

$LocalizerExe = $LocalizerToolPath + '\Lw.Localizer.exe'

Start-Process $LocalizerExe -Wait 

$en_gbPath = $SatelliteAssemblyPath + 'en-GB\Lw.Domain.Resources.dll'
if(Test-Path $en_gbPath)
{
    $LessorPortalPath = $RelDir + '\LessorPortal\bin\'
    $JobServicePath = $RelDir + '\WindowsService\'
    $WebAPIPath = $RelDir + '\WebAPI\bin\'
    if(Test-Path $LessorPortalPath)
    {
        Copy-item -Path $en_gbPath $LessorPortalPath  -Recurse -Force
    }
    if(Test-Path $JobServicePath)
    {
        Copy-item -Path $en_gbPath $JobServicePath  -Recurse -Force
    }
    if(Test-Path $WebAPIPath)
    {
        Copy-item -Path $en_gbPath $WebAPIPath  -Recurse -Force
    }
}