param(

[string] $otexe,
[string] $otws,
[string] $OTRunName,
[string] $WebApplicationurl,
[string] $OTScenarioCollectionName,
[string] $OTLogsFolder,
[string] $OTServer,
[string] $BusinessUnit,
[string] $userName,
[string] $password
)

function encryptKey($plaintext){
    
    $plainBytes = [System.Text.Encoding]::UTF8.GetBytes($plaintext)
    $publicKey="<RSAKeyValue><Modulus>u/+n2bHHccEVCZ6USiENsWb8Nl9YtTICf1nv62UQiv4kynsrAAgysUuE5IsnoYb1XfcTgjLEa3riUP0WoOIIBi4MfDSWgpPTglYjwCxovF5GU3cAiBBN28q6w/d1dQqaPJ1kUyRSCkYjaH7l2Pq3AO+bjFRsWz1VyR8m4WBtB0U=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
    $provider=[System.Security.Cryptography.RSACryptoServiceProvider]::new(1024) 
    $provider.PersistKeyInCsp = $false;
    $provider.FromXmlString($publicKey)
    $cipher=$provider.Encrypt($plainBytes,$true)
    return [System.Convert]::ToBase64String($cipher)
 }

 write-host $otexe
 write-host $otws 
 write-host $OTRunName
 write-host $WebApplicationurl
 write-host $OTScenarioCollectionName
 write-host $OTLogsFolder
 write-host $OTServer

 $userName 
 $password = encryptKey($password)
              
$result = Invoke-Command -ComputerName $OTServer -ScriptBlock {
function CreateSCTask{
param([string]$OTExe, [string]$arg, [string]$name)
  $task = Get-ScheduledTaskInfo -TaskName $name -ErrorAction Ignore

  if($task){
      Unregister-ScheduledTask -TaskName $name -Confirm:$false
  }

  $taskAction = New-ScheduledTaskAction -Execute $OTExe -Argument $arg
  
  Register-ScheduledTask -TaskName $name -Action $taskAction -User 'ODESSAPDC01\devops.admin' -Password 'Password@123'
  Start-ScheduledTask -TaskName $name
}

function Run-OTScenarios{
param(
  [string]$OTExe, [string]$OTRunName, [string]$WebApplicationurl, [string]$OTWorkspace, [string]$OTScenarioCollectionName, [string]$OTLogsFolder, [string]$userName, [string]$password, [string]$bu
)
    $logfile = $OTLogsFolder+"\$OTRunName"+"_Execute.txt"
    try
    {
        Write-Host "With runname as $OTRunName going to start on $WebApplicationurl under workspace $OTWorkspace to run collection named $OTScenarioCollectionName"
        write-host $bu
         
        $arguments = "-Operation Execute -DeploymentPath $WebApplicationurl -WorkingDirectory $OTWorkspace -Scenarios $OTScenarioCollectionName -Collection true -RunName $OTRunName -LogsFolder $OTLogsFolder -UserName $userName -Password $password"
        if($bu -ne 'defaultBU') {
          $arguments = $arguments + " -BusinessUnit $bu"
        }
        Write-Host $OTExe
        Write-Host $arguments
        
        CreateSCTask $OTExe $arguments $OTRunName
        
        
        write-host "OT has been scheduled successfully" -f Green
        #if(Test-Path $logfile){
        #    $log = Get-Content $logfile
        #    write-host $log
        #    return $log
        #}

    }
    catch
    {
      Write-Host "##error## occurred:"
      throw $_
    }
}                
 Run-OTScenarios $using:otexe $using:OTRunName $using:WebApplicationurl $using:otws $using:OTScenarioCollectionName $using:OTLogsFolder $using:userName $using:password $using:BusinessUnit
}  