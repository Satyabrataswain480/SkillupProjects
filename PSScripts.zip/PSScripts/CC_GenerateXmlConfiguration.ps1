
param($basePath,
 $projectName,
 $isOt, 
 $isUt, 
 $isMerge)
 
 write-host $basePath
 write-host $projectName
 write-host $isOt
 write-host $isUt
 write-host $isMerge


    $otReportConfig = "OT_Report.xml"
    $utReportConfig = "UT_Report.xml"
    $mergeReportConfig = "Merge_Report.xml"
    $basePath = "$basePath\$projectName\Configs\"
    $xmlReportConfigPath = "$basePath\XML_Report.xml"
    $reportType = "xml"

    if(Test-Path $xmlReportConfigPath){
        return
    }

    $path = ""

    if($isOt -eq 'true'){
        $path = $basePath + $otReportConfig
    }
    if($isUt -eq 'true'){
        $path = $basePath + $utReportConfig
    }
    if($isMerge -eq 'true'){
        $path = $basePath + $mergeReportConfig
    }

    $path

    Get-Content -Raw $path |
    ForEach-Object { $_ -replace  "html", $reportType} |
    Set-Content -Path $xmlReportConfigPath -Force
    
