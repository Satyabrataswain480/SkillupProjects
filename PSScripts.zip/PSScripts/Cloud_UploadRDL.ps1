﻿Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Reports')]
[string]$Report_Server,
[parameter (Mandatory=$true, position=1, ParameterSetName='Reports')]
[string]$SSRSServiceName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Reports')]
[string]$Report_ServerPort,
[parameter (Mandatory=$true, position=3, ParameterSetName='Reports')]
[string]$Report_Folder,
[parameter (Mandatory=$false, position=4, ParameterSetName='Reports')]
[string]$Report_Binpath,
[parameter (Mandatory=$true, position=5, ParameterSetName='Reports')]
[string]$PackagePath


)

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$packagePath = $packagePath + "\" + $currentDate + "\"
$ReportPath = $packagePath +'Reports'

$DefaultWorkingDirectory = $env:System_DefaultWorkingDirectory

Write-Host 'Starting uploading reports..'



#$FoldersList = Get-ChildItem $DefaultWorkingDirectory\ReleasePackages -Recurse -Force

#write-host $DefaultWorkingDirectory\ReleasePackages



<#

$path1 = $DefaultWorkingDirectory +'\ReleasePackages\Reports\ReportHelper\*.dll'

if(!(Test-Path $path1))
{
    write-host 'Skipping DLL replacement process, as no content found.'
}
else
{
    Copy-Item -path $path1 -destination $(Report_SharedPath) -Force -Recurse
}

#>



$ReportHelperPath = $packagePath + 'Reports\ReportHelper\*.dll'

$p = $ReportHelperPath
$sb = {
        param ($path, $binpath)
        Copy-Item -path $path -destination $binpath -Force -Recurse -ErrorAction Ignore
    }


## restart SQLServerReportingService

<#

$Service = Get-WmiObject -ComputerName $Report_Server -Class Win32_Service -Filter "Name='$SSRSServiceName'" 
$Service.stopservice()

Start-Sleep 60

Invoke-Command -computername $Report_Server -scriptBlock $sb -ArgumentList $p,$Report_Binpath 

$Service = Get-WmiObject -ComputerName $Report_Server -Class Win32_Service -Filter "Name='$SSRSServiceName'" 
$Service.startservice()

#>

Start-Sleep 60

$path2 = $packagePath + '\Reports\RDLs'

Write-Host  $path2 

if(!(test-path $path2))
{
    write-host 'Skipping RDL replacement process, as no content found.'
    return;
}

$report_serverwithport = $Report_Server + ':' + $Report_ServerPort

$reportServerUri = "http://{0}/Reports" -f $report_serverwithport

write-host $reportServerUri

Write-RsFolderContent -ReportServerUri $reportServerUri -Path $path2 -Destination $Report_Folder -OverWrite -Verbose

Write-Host 'Report upload completed.'