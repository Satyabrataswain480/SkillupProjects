﻿Param (
    [Parameter(Mandatory = $true, Position = 1, ParameterSetName = 'release')]
    [string]$ReleaseVersion,

    [Parameter(Mandatory = $true, Position = 2, ParameterSetName = 'release')]
    [string]$Env,

    [Parameter(Mandatory = $true, Position = 3, ParameterSetName = 'release')]
    [string]$Proj,

    [Parameter(Mandatory = $true, Position = 4, ParameterSetName = 'release')]
    [string]$Portal,

    [Parameter(Mandatory = $true, Position = 5, ParameterSetName = 'release')]
    [string]$WebandJobConfig,

    [Parameter(Mandatory = $true, Position = 6, ParameterSetName = 'release')]
    [string]$WorkingDirectory,

    [Parameter(Mandatory = $true, Position = 7, ParameterSetName = 'release')]
    [string]$TechLeadMail,

    [Parameter(Mandatory = $false, Position = 8, ParameterSetName = 'release')]
    [string]$ProjRepoName
)

function Invoke-EnvironmentSpecificConfigCheck {
    Param(
        [string]$EnvironmentName,
        [string]$ProjectName,
        [string]$WorkingDirectory,
        [hashtable]$EnvironmentPaths,
        [string]$WebandJobConfig
    )

    # Check if environment configurations are available
    if (!$EnvironmentPaths.ContainsKey($EnvironmentName)) {
        Write-Host "No configuration found for environment: $EnvironmentName" -ForegroundColor Red
        return
    }

    $envKeys = $EnvironmentPaths[$EnvironmentName]

    #if the repo name is different from project-name
    if (![string]::IsNullOrEmpty($ProjRepoName)) {
    $ProjectName = $ProjRepoName  
    }

    # Check and process Web and Job Configurations
    if ($WebandJobConfig -eq 'Y') {
        foreach ($key in $envKeys) {
            $webConfigPath = Join-Path -Path $WorkingDirectory -ChildPath "$ProjectName\Project\Config\$key\App\Web.config"
            $windowsServicesConfigPath = Join-Path -Path $WorkingDirectory -ChildPath "$ProjectName\Project\Config\$key\JobServices\Lw.WindowsServices.exe.config"
            #$webAPIConfig = Join-Path -Path $WorkingDirectory -ChildPath "$ProjectName\Project\Config\$key\WebAPI\AppSettings.config"

            if (Test-Path $webConfigPath) {
                ConfigCheck -Path $webConfigPath -Project $Proj -EnvName $key -AppName $Portal -ConfigName 'Web'
            } else {

                Write-Host "Path '$webConfigPath' doesn't exist" -ForegroundColor Red
                $global:MailBody += "Hello Team,<br>" 
                $global:MailBody += "<br>Config file doesn't exist in this path : '$webConfigPath' for ReleaseVersion $ReleaseVersion and project $Proj</br>"
                $global:MailBody += "<br>Please include the appropriate config file</br>"
                $global:MailBody += "Thank You,<br>" 

                Send-Email
                exit 1
                #email
            }

            if (Test-Path $windowsServicesConfigPath) {
                ConfigCheck -Path $windowsServicesConfigPath -Project $Proj -EnvName $key -AppName $Portal -ConfigName 'WindowsService'
            } else {

                Write-Host "Path '$windowsServicesConfigPath' doesn't exist" -ForegroundColor Red
                $global:MailBody += "Hello Team,<br>" 
                $global:MailBody += "<br>Config file doesn't exist in this path : '$windowsServicesConfigPath' for ReleaseVersion $ReleaseVersion and project $Proj</br>"
                $global:MailBody += "<br>Please include the appropriate config file</br>"
                $global:MailBody += "Thank You,<br>" 

                Send-Email
                exit 1
                
            }
            
        }
    } else {
        Write-Host "AppSettings module not selected; validation skipped."
    }
}

function ConfigCheck {
    Param(
        [string]$Path,
        [string]$Project,
        [string]$EnvName,
        [string]$AppName,
        [string]$ConfigName
    )

    # Define the API endpoint and payload
    $url = "http://lwdelbuild-001:8090/keyvalue/filter"
    $headers = @{ "Content-Type" = "application/json" }
    $body = @{
        "projectname"      = $Project # Case sensitive - should match with Odessa Vision values
        "environmentName"  = $EnvName # Case sensitive - should match with Odessa Vision values
        "applicationName"  = $AppName # Case sensitive - should match with Odessa Vision values
        "configName"       = $ConfigName # Case sensitive - should match with Odessa Vision values
    } | ConvertTo-Json

    # Send the POST request
    $response = Invoke-RestMethod -Uri $url -Method Post -Headers $headers -Body $body

    if ($response) { # Load and parse the XML configuration file
        [xml]$xmlConfig = Get-Content -Path $Path
        
        # Convert API response to a dictionary for easy access
        $apiDict = @{}
        $response | ForEach-Object { $apiDict[$_.key] = $_.value }

   function Compare-Value {
    param (
        [string]$key,
        [string]$expectedValue,
        [string]$apiValue
    )
    
    Write-Host "$key --- $expectedValue"
    
    if ($apiValue -eq $expectedValue) {
        Write-Host 'Values are Matching'
    } else {
        Write-Host "Values are not matching. API value: $apiValue, Config Value: $expectedValue"
         $global:MailBody += "Hello Team,<br>" 
         $global:MailBody += "<br>Values are not matching. API value: $apiValue, Config Value: $expectedValue for ReleaseVersion $ReleaseVersion and project $Proj</br>"
         $global:MailBody += "<br>Please check the config file</br>"
         $global:MailBody += "Thank You,<br>"
        Send-Email 
        exit 1
    }
}

# Helper function for checking vertex endpoints
function Check-VertexEndpoint {
    param (
        [string]$contractName,
        [string]$apiKey
    )

    $endpoint = $xmlConfig.DocumentElement.'system.serviceModel'.client.endpoint | Where-Object { $_.contract -eq $contractName }
    #Write-Host "$contractName --- $($endpoint.address)"

    Compare-Value -key $contractName -expectedValue $endpoint.address -apiValue $apiDict[$apiKey]
}

# 1. AppSettingsKeyVault


 if($apiDict.Keys -contains 'configBuilders.builders.AppSettingsKeyVault'){

$AppSettingsKeyVault = $xmlConfig.DocumentElement.configBuilders.builders.add | Where-Object { $_.name -eq "AppSettingsKeyVault" }
Compare-Value -key "AppSettingsKeyVault" -expectedValue $AppSettingsKeyVault.vaultName -apiValue $apiDict['configBuilders.builders.AppSettingsKeyVault']
}


# 2. ConnectionStringKeyVault

 if($apiDict.Keys -contains 'configBuilders.builders.ConnectionStringKeyVault'){

$ConnectionStringKeyVault = $xmlConfig.DocumentElement.configBuilders.builders.add | Where-Object { $_.name -eq "ConnectionStringKeyVault" }
Compare-Value -key "ConnectionStringKeyVault" -expectedValue $ConnectionStringKeyVault.vaultName -apiValue $apiDict['configBuilders.builders.ConnectionStringKeyVault']

}

# 3. AzureAppConfig

 if($apiDict.Keys -contains 'configBuilders.builders.AzureAppConfig'){

$azureAppConfigElement = $xmlConfig.DocumentElement.configBuilders.builders.add | Where-Object { $_.name -eq "AzureAppConfig" }
Compare-Value -key "AzureAppConfig" -expectedValue $azureAppConfigElement.labelFilter -apiValue $apiDict['configBuilders.builders.AzureAppConfig']
}

# 4. Environment
 if($apiDict.Keys -contains 'configBuilders.builders.Environment'){

$Environment = $xmlConfig.DocumentElement.configBuilders.builders.add | Where-Object { $_.name -eq "Environment" }
Compare-Value -key "Environment" -expectedValue $Environment.mode -apiValue $apiDict['configBuilders.builders.Environment']
}

# 5. SMTP Enable SSL

 if($apiDict.Keys -contains 'smtp.enableSsl'){

$smtpEnable = $xmlConfig.DocumentElement.'system.net'.mailSettings.smtp.network.enableSsl
Compare-Value -key "SMTP Enable SSL" -expectedValue $smtpEnable -apiValue $apiDict['smtp.enableSsl']
}

# 6. SMTP From
 if($apiDict.Keys -contains 'smtp.from'){
$smtpFrom = $xmlConfig.DocumentElement.'system.net'.mailSettings.smtp.from
Compare-Value -key "SMTP From" -expectedValue $smtpFrom -apiValue $apiDict['smtp.from']
}

# 7. Report URL 2005
 if($apiDict.Keys -contains 'Report.Service.URL'){

$reportURL2005 = $xmlConfig.DocumentElement.applicationSettings.'Lw.Domain.Base.Extension.Properties.Settings'.setting | Where-Object { $_.name -eq "Lw_Domain_Base_Extension_ReportExecutionService_ReportExecutionService" }
Compare-Value -key "Report URL 2005" -expectedValue $reportURL2005.value -apiValue $apiDict['Report.Service.URL']
}

# 8. Report URL 2010
 if($apiDict.Keys -contains 'Report.Service2010.URL'){

$reportURL2010 = $xmlConfig.DocumentElement.applicationSettings.'Lw.Domain.Base.Extension.Properties.Settings'.setting | Where-Object { $_.name -eq "Lw_Domain_Base_Extension_ReportingService_ReportingService2010" }
Compare-Value -key "Report URL 2010" -expectedValue $reportURL2010.value -apiValue $apiDict['Report.Service2010.URL']
}

# 9. TValue URL Check

 if($apiDict.Keys -contains 'client.endpoint.bindingConfiguration.Tvalue'){

$TValue = $xmlConfig.DocumentElement.'system.serviceModel'.bindings.basicHttpBinding.binding | Where-Object { $_.name -eq "BasicHttpBinding_ITValuePricingService" }

if ($TValue) {
    $TValueURL = $xmlConfig.DocumentElement.'system.serviceModel'.client.endpoint | Where-Object { $_.bindingConfiguration -eq "BasicHttpBinding_ITValuePricingService" }
    Compare-Value -key "TValue URL" -expectedValue $TValueURL.address -apiValue $apiDict['client.endpoint.bindingConfiguration.Tvalue']
}
else{
         $global:MailBody += "Hello Team,<br>" 
         $global:MailBody += "<br>The TValue binding is missing</br>"
         $global:MailBody += "<br>Please check the config file</br>"
         $global:MailBody += "Thank You,<br>"
         Send-Email 
         exit 1
}
}

# 10. Check all Vertex binding URLs

if($apiDict.Keys -contains 'client.endpoint.bindingConfiguration.vertex.LookupTaxAreasString' -and $apiDict.Keys -contains 'client.endpoint.bindingConfiguration.vertex.CalculateTaxString' -and $apiDict.Keys -contains 'client.endpoint.bindingConfiguration.vertex.customer'){

    $VertexBinding = $xmlConfig.DocumentElement.'system.serviceModel'.bindings.basicHttpBinding.binding | Where-Object { $_.name -eq "VertexBinding" }
#Write-Host 'VertexBindings ---' $VertexBinding

if ($VertexBinding) {
    Check-VertexEndpoint -contractName "VertexLookupTaxAreasWSService.LookupTaxAreasWS" -apiKey 'client.endpoint.bindingConfiguration.vertex.LookupTaxAreasString'
    Check-VertexEndpoint -contractName "VertexCalculateTaxWSService.CalculateTaxWS" -apiKey 'client.endpoint.bindingConfiguration.vertex.CalculateTaxString'
    Check-VertexEndpoint -contractName "VertexCustomerService.CustomerPortType" -apiKey 'client.endpoint.bindingConfiguration.vertex.customer'
}
else{
         $global:MailBody += "Hello Team,<br>" 
         $global:MailBody += "<br>The Vertex binding is missing</br>"
         $global:MailBody += "<br>Please check the config file</br>"
         $global:MailBody += "Thank You,<br>"
         Send-Email 
         exit 1
}


}

elseif($apiDict.Keys -contains 'client.endpoint.bindingConfiguration.vertex.LookupTaxAreasString' -or $apiDict.Keys -contains 'client.endpoint.bindingConfiguration.vertex.CalculateTaxString' -or $apiDict.Keys -contains 'client.endpoint.bindingConfiguration.vertex.customer'){

         Write-host "All Vertex endpoitns are not configured please check the Environment variables tab in Odessa Vision"
         $global:MailBody += "Hello Team,<br>" 
         $global:MailBody += "<br>All Vertex endpoitns are not configured please check the Environment variables tab in Odessa Vision</br>"
         $global:MailBody += "Thank You,<br>"
         Send-Email 
         exit 1
  
}
else{
    Write-host "Skipping Vertex Bind Check as its not Configured on the Odessa Vision Dashboard"

} 
     
    } else {
        Write-Host "No Env variables added for $EnvName $AppName $ConfigName in the Odessa Vision Portal."
    }
}

function Send-Email(){
    param(
        [string]$smtpServer = "mail.odessatech.in",
        [string]$ComputerName = $env:ComputerName,
        [string]$from = "Delivery-Devops@odessainc.com",
        [string]$to = $TechLeadMail    
		
		)
    
    try { 

        #Creating a Mail object
        $msg = new-object Net.Mail.MailMessage    

        #Creating SMTP server object
        $smtp = new-object Net.Mail.SmtpClient($smtpServer,25) 
        #$smtp.EnableSsl = $true 
        $smtp.Credentials = New-Object System.Net.NetworkCredential("no-reply@odessatech.in", "password-1"); 

        #Email structure 
        $msg.From = $from
        $msg.ReplyTo = "noreply@odessatech.in"
        $msg.To.Add($to)


        $msg.subject =$Projectname +' ' + $environmentname + ' Config Check Failure Notification'
        $msg.body = $global:MailBody
        $msg.IsBodyHtml = 1       

        #Sending email 
        write-host 'Email sending...'
        $smtp.Send($msg)
        write-host 'Email Sent...'
  } catch {
        Write-Warning $_
  }
}


$envDetailQuery = @"
select a.* from Releases a, Projects b, ProjectReleaseMappings c, ApplicationReleaseMappings arm, Applications d
where a.Id = arm.ReleaseId and arm.ApplicationId = d.Id and d.ApplicationName = '$Portal' and c.ProjectId = b.Id and a.Id = c.ReleaseId
and b.ProjectNickName = '$Proj' and a.ReleaseVersion = '$ReleaseVersion' and a.ReleaseStatus in ('Approved','Packaged','Completed')
"@
    $envDetailQuery
    $envDetails = Invoke-Sqlcmd -ServerInstance 'LWDELBUILD-001\SQL2019' -Database 'Odessa_Dashboard_Prod' -Query $envDetailQuery -QueryTimeout 65500 -ErrorAction Stop

    $envi = $envDetails.EnvName
Write-Host "Environment -> $envi"

 $environmentPaths = @{
        "Dev Int"             = @("DEV")
        "Sandbox"             = @("SAN")
        "Staging"             = @("STAGING", "UAT", "PROD")
        "Staging Hotfix"      = @("STAGING", "UAT", "PROD")
        "SIT"                 = @("SIT", "UAT", "PROD")
        "SIT Hotfix"          = @("SIT", "UAT", "PROD")
        "UAT"                 = @("UAT", "PROD");
        "UAT Hotfix"          = @("UAT", "PROD")
        "Production Hotfix"   = @("PROD")
    }

#if (![string]::IsNullOrEmpty($ProjRepoName)) {
    #$Proj = $ProjRepoName
#}

Invoke-EnvironmentSpecificConfigCheck -EnvironmentName $envi -ProjectName $Proj -WorkingDirectory $WorkingDirectory -EnvironmentPaths $environmentPaths -WebandJobConfig $WebandJobConfig
