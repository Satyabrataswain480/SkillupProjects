﻿Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$source,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$target

)

robocopy $source $target Lw.Domain*.dll /S /E /Z /B /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /XO /COPY:DT
if ($lastexitcode -lt 8) { $lastexitcode = 0 }

