﻿Param (

[parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
[string]$Release_Path,
[parameter (Mandatory=$true, position=1, ParameterSetName='Database')]
[string]$SQL_CurrentScripts,
[parameter (Mandatory=$true, position=2, ParameterSetName='Database')]
[string]$DBName,
[parameter (Mandatory=$true, position=3, ParameterSetName='Database')]
[string]$dbServer

)


$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir =  $Release_Path + $currentDate

$Dll_Version = $RelDir +'\LessorPortal\bin\Lw.Domain.Project.Extension.dll'

$TargetDB = $DBName

$ReleaseversionNumberT= (Get-Item $Dll_Version).VersionInfo.FileVersion
$version = $ReleaseversionNumberT.Replace('.','')
$Destination = $RelDir + "\Database\DBScripts\DML\3999_R${Version}_ReleaseVersion.sql"

$date=get-date -Format yyyy-MM-dd
$ReleaseScriptsFromFolder = $SQL_CurrentScripts
$DataBaseServer = $dbServer
clear all
$DBNameList = (Invoke-SQLCmd -query "Use $TargetDB;select ReleaseScriptName from ReleaseVersionDetails" -Server $DataBaseServer )
#Reads all Script name from release version table



$content1=”IF NOT EXISTS (SELECT 1 FROM [dbo].ReleaseVersions WHERE VersionNumber = '${ReleaseversionNumberT}')
BEGIN INSERT INTO [dbo].[ReleaseVersions] ([VersionNumber],[ShippedDate],[AppliedDate],[AppliedBy],[CreatedById],[CreatedTime],[UpdatedById],[UpdatedTime],[LatestDBScriptName]) VALUES('"+$ReleaseversionNumberT+"','"+$date+"',GETDATE(),'DevOps',1, GETDATE(),null,null,null)
END
GO"
write-host $content1
$content1 | set-Content $Destination

 

 

$content1="declare @versionid bigint"
Write-Host $content1
$content1 | Add-Content $Destination

 

 

$content1="Select @versionid = max( id )from [ReleaseVersions]"

 

 


Get-ChildItem $ReleaseScriptsFromFolder -Filter *.sql -Recurse -File |

 

 

Foreach-Object {
  $BseName = $_.BaseName
    if($_.BaseName -notin $DBNameList )
    {

 

 

    
   $content1 +="`r`n"
    $content1 +="IF NOT EXISTS (SELECT 1 FROM [dbo].[ReleaseVersionDetails] WHERE [ReleaseScriptName] = '${BseName}')
    BEGIN INSERT INTO [dbo].[ReleaseVersionDetails] ([ReleaseScriptName],[IsExecuted],[CreatedById],[CreatedTime],[UpdatedById],[UpdatedTime],[ReleaseVersionId]) VALUES('"+$BseName+"',1,1,GETDATE(),null,null,@versionid)
    END"
    $content1 +="`r`n"
   #write-host $content1
  }

  }
   $content1+="GO"


$content1 | Add-Content $Destination
