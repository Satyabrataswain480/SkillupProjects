﻿Param (

[parameter (Mandatory=$true, position=1, ParameterSetName='Version')]
[string]$Projectname,
[parameter (Mandatory=$true, position=2, ParameterSetName='Version')]
[string]$environmentname,
[parameter (Mandatory=$true, position=3, ParameterSetName='Version')]
[string]$ToEmail
)

function Send-Email(){
    param(
        [string]$smtpServer = "mail.odessatech.in",
        [string]$ComputerName = $env:ComputerName,
        [string]$from = "Delivery-Devops@odessainc.com",
        [string]$to = "Delivery-Devops@odessainc.com",
        [string]$coticketno = "N/A"
    )
    
    try { 

        #Creating a Mail object
        $msg = new-object Net.Mail.MailMessage    

        #Creating SMTP server object
        $smtp = new-object Net.Mail.SmtpClient($smtpServer,25) 
        #$smtp.EnableSsl = $true 
        $smtp.Credentials = New-Object System.Net.NetworkCredential("no-reply@odessatech.in", "password-1"); 

        #Email structure 
        $msg.From = $from
        $msg.ReplyTo = "noreply@odessatech.in"
        $msg.To.Add($to)


        $msg.subject =$Projectname +' ' + $environmentname + ' Release Completion Notification'
        $msg.body = $global:MailBody
        $msg.IsBodyHtml = 1       

        #Sending email 
        write-host 'Email sending...'
        $smtp.Send($msg)
        write-host 'Email Sent...'
  } catch {
        Write-Warning $_
  }
}

function GenerateReport
{
    $global:MailBody += "<br>Regards," 
    $global:MailBody += "<br>Delivery Devops Team</br><br>"
    Send-Email -To $ToEmail
}

write-host 'Report started...'


$global:MailBody += "Hello Team,<br>" 
$global:MailBody += "<br>The $Projectname deployment succeeded on $environmentname environment.</br>"

GenerateReport
 
$global:MailBody = ''
 
write-host 'Report Completed...'