﻿#$FilePath = '\\lwdelbuild-002\ADAgentWorkFolder\ADAgent-001\2700\s\SGF\Project\*.cs'

Param (

[parameter (Mandatory=$true, position=1, ParameterSetName='Database')]
[string]$ProjectName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Database')]
[string]$FilePath,
[parameter (Mandatory=$false, position=3, ParameterSetName='Database')]
[string]$realPrjName = "Default"
)


$Filename=Get-ChildItem -Path $FilePath -Recurse -Exclude 'AssemblyInfo.cs','.NETFramework,Version=v4.8.AssemblyAttributes.cs', 'Core.Project.*'
$CurrentDate= (Get-date).ToString("yyyy-MM-dd")
#$ProjectName='SGF'

$DatabaseName='Dashboard_Prod'
$SQLServer = 'lwdelbuild-001'


for ($i=0; $i -lt $Filename.Count; $i++) {
   $FileName1= $Filename[$i].name

   $Fullpath1= $Filename[$i].FullName
   
   $index = 0
   if($realPrjName -eq 'Default'){
    $index=$Fullpath1.IndexOf($ProjectName)
   }else{
    $index=$Fullpath1.IndexOf($realPrjName)
   }  #Remove initial path
   
   $projectPath=$Fullpath1.Substring($index)
  
    $line=Get-ChildItem -Path $Filename[$i].FullName | Get-Content | Measure-Object -line
    $Lines1=$line.Lines
   
    $Query1 = "select Id from projects where Name = '$ProjectName'"
    $Id = invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -Query $Query1 -QueryTimeout 65500
    $projectId = $Id.Id
    
    $Query="Insert into LinesOfCode(ProjectName,FileName,FileFullPath,LinesofCode,DateGeneration,ProjectID) values('" + $ProjectName + "','" + $FileName1 + "','" + $projectPath + "','" + $Lines1 + "','" + $CurrentDate+ "','" + $projectId + "')"
    write-host $Query
    invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -Query $Query -QueryTimeout 65500

}


