﻿Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$configSource,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Destination,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$IsLessorportal,
[parameter (Mandatory=$true, position=3, ParameterSetName='Release')]
[string]$IsPartnerportal
)

##  Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir = $Destination + $currentDate


## copy
if($IsLessorportal -eq '1')  #Lessorportal
{
    $LessorPortal = $RelDir + '\LessorPortal'
}
else
{
    $LessorPortal = $RelDir + '\WebApp'
}
    $WindowService = $RelDir + '\WindowsService' 
    $WebAPI = $RelDir + '\WebAPI' 

    $apiConfigFiles = @("AppSettings.config", "ConnectionStrings.config", "Web.config")  
    $windowsConfigFiles = @("AppSettings.config", "ConnectionStrings.config") 
    $windowsexeConfigFiles = @("Lw.WindowsServices.exe.config") 

    write-host 'Starting copying api config files.'

    # Copy each DLL file from the source to the destination
    foreach ($file in $apiConfigFiles) {
        $sourceFile = Join-Path $LessorPortal $file
        Copy-Item -Path $sourceFile -Destination $WebAPI -Force
    }  

    write-host 'Completed copying api config files.'

    write-host 'Starting copying windows config files.'

    # Copy each DLL file from the source to the destination
    foreach ($file in $windowsConfigFiles) {
        $sourceFile = Join-Path $LessorPortal $file
        Copy-Item -Path $sourceFile -Destination $WindowService -Force
    }

    foreach ($file in $windowsexeConfigFiles) {
        $sourceFile = Join-Path $configSource $file
        Copy-Item -Path $sourceFile -Destination $WindowService -Force
    }   

    write-host 'Completed copying windows config files.'


if (($lastexitcode -lt 8) -or ($lastexitcode -eq 16))
  { $lastexitcode = 0 }
