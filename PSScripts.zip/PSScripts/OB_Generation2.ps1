param(
$buildPath, # '$(Build.ArtifactStagingDirectory)\build\'
$domainPath, #  $(Build.Repository.LocalPath)\Lenovo\Project\Lw.Domain.Project\
$outputPath # script output path in shared path
)

#Clean outputPath
#Remove-Item -Path "$outputPath\*" -Force

Write-Host '-------------------------OB Generation Started------------------------------------'

Write-Host 'BuildPath ---' $buildPath
$stLocationPth = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin"
Write-Host 'stLocationpth---' $stLocationPth
Set-Location -Path $stLocationPth
$lf = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.System.Common.dll"
[System.Reflection.assembly]::LoadFile($lf)
$lf = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.System.Metamodel.dll"
$lf
[System.Reflection.assembly]::LoadFile($lf)
$lf = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.System.Tools.Common.dll"
$lf
[System.Reflection.assembly]::LoadFile($lf)
$lf = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.System.dll"
$lf
[System.Reflection.assembly]::LoadFile($lf)
$objBuildToolsService=New-Object Lw.Sys.Customization.BuildTools.BuildToolsServiceInvoker
$objBuildToolsService.GenerateDatabaseScripts($buildPath+"_PublishedWebsites\Lw.LessorPortal.Project",$domainPath,$buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\DomainAssemblies\Lw.Domain.dll",$outputPath,"Lw.Domain.LeasewaveRepository")

Write-Host '-------------------------OB Generation Completed------------------------------------'