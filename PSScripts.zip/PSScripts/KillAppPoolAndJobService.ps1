﻿param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='service')]
    [string]$jobServiceName,
    [parameter(Mandatory=$true, position=2, ParameterSetName='service')]
    [string]$jobServer,
     [parameter(Mandatory=$true, position=3, ParameterSetName='service')]
    [string]$appPoolName,
    [parameter(Mandatory=$true, position=4, ParameterSetName='service')]
    [string]$appServer     
    )
    
function KillService($jobServiceName)
{
 # Retrieve the process ID for the specific service
$serviceName = $jobServiceName 
$processId = Get-WmiObject -Class Win32_Service -Filter "Name = '$serviceName'" |
             Select-Object -ExpandProperty ProcessId

Write-Host 'Process ID' $processID



# Check if a valid process ID was retrieved

if(!([string]::IsNullOrEmpty($processId))) {
    try {
        # Attempt to terminate the process tree
        Stop-Process -Id $processId -Force
        Write-Output "Process tree with PID $processId has been terminated."
    } catch {
        Write-Error "Failed to terminate process tree with PID $processId. Error: $_"
    }
} else {
    Write-Output "No running process found for service '$serviceName'."
}
}

function KillAppPool($appPoolName)
{
 $process = gwmi -NS 'root\WebAdministration' -class 'WorkerProcess' | select AppPoolName,ProcessId | Where-Object {$_.AppPoolName -eq "$appPoolName"}
 $process
 $process.ProcessId
 
 if(!([string]::IsNullOrEmpty($process.ProcessId))){

 Stop-Process -Id $process.ProcessId -Force 
 Write-Host 'Process ID Found and Killed'

 }
 else{
  Write-Host 'No Process ID Found'
  } 
}

Invoke-Command -computername $jobServer -ScriptBlock ${function:KillService} -Args $jobServiceName
Invoke-Command -computername $appServer -ScriptBlock ${function:KillAppPool} -Args $AppPoolName
