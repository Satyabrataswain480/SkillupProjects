﻿##  This script will create Release contant
##  \\lwdelbuild-001\AgentWorkFolder\DelBuildAgent-001\53\s\$\MFM\Fx4.0\Core5.0\DEV\Project\
##  \\lwdelbuild-001\Backup\Release\MFM\
##  4.20.12.5
Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Build_Path,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Release_Path,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$Artifact_Build_Path,
[parameter (Mandatory=$false, position=3, ParameterSetName='Release')]
[string]$PackageReference,
[parameter (Mandatory=$false, position=4, ParameterSetName='Release')]
[string]$IsRegionLayer, 
[parameter (Mandatory=$false, position=5, ParameterSetName='Release')]
[string]$IsProjectCoreLayer,
[parameter (Mandatory=$false, position=6, ParameterSetName='Release')]
[string]$IsEMMLayer,
[parameter (Mandatory=$false, position=7, ParameterSetName='Release')]
[string]$IsLW5UpgradeLayer,
[parameter (Mandatory=$false, position=8, ParameterSetName='Release')]
[string]$IsDotNet7Upgraded = '0',
[parameter (Mandatory=$false, position=9, ParameterSetName='Release')]
[string]$IsDotNet7 = '0',
[parameter (Mandatory=$false, position=10, ParameterSetName='Release')]
[string]$isDirectoryOnlyRequired = '0'

)

##  Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir = $Release_Path + $currentDate

if($PackageReference -eq '1')
{    
  $packagePath = 'C:\Users\devops.admin\.nuget\packages'
  write-host 'Package Reference Path: ' $packagePath
}
else
{
  $packagePath = $Build_Path + '\Packages'
}

if($PackageReference -eq '1')
{
    #Get the Current Fx version configured for LeaseWave solution
    $BuildProjData = [xml]( Get-Content  "$Build_Path\Build.proj"); 
    $FrameworkVersion = $BuildProjData.Project.ChildNodes.Item(0).FrameworkVersion
    $FRWKFolders = $packagePath + '\odessa.framework\' + $FrameworkVersion
    $FRWKABSPath = $FRWKFolders
    write-host 'FRWK Path: ' $FRWKABSPath
}
else
{
    $FRWKFolders = Get-childitem -Path $packagePath -Filter 'lw.Framework*'
    $FRWKABSPath = $null
}

if($PackageReference -eq '0')
{
    if($FRWKFolders.count -gt 1)
    {
      write-host 'Multiple framework folders found. keep only latest one'
      throw
    }
    else
    {
      $FRWKABSPath = $FRWKFolders.FullName
      write-host $FRWKABSPath
    }
}


if(!(Test-path -Path $RelDir))
{
   New-Item -Name $currentDate -ItemType Directory -Path $Release_Path
} 
else
{
  Remove-Item -Path $RelDir -Recurse -Force
  New-Item -Name $currentDate -ItemType Directory -Path $Release_Path

}

##  Creating Root FOlder
New-Item -Name 'CustomerPortal'  -ItemType Directory -Path $RelDir
New-Item -Name 'Database'  -ItemType Directory -Path $RelDir
New-Item -Name 'DocPortal'  -ItemType Directory -Path $RelDir
New-Item -Name 'LessorPortal'  -ItemType Directory -Path $RelDir
New-Item -Name 'License'  -ItemType Directory -Path $RelDir
New-Item -Name 'PricingService'  -ItemType Directory -Path $RelDir
New-Item -Name 'Reports'  -ItemType Directory -Path $RelDir
New-Item -Name 'SqlServices'  -ItemType Directory -Path $RelDir
New-Item -Name 'TValueBinaries'  -ItemType Directory -Path $RelDir
New-Item -Name 'UserManual'  -ItemType Directory -Path $RelDir
New-Item -Name 'VendorPortal'  -ItemType Directory -Path $RelDir
New-Item -Name 'WebAPI'  -ItemType Directory -Path $RelDir
New-Item -Name 'WindowsService'  -ItemType Directory -Path $RelDir
New-Item -Name 'WebServices'  -ItemType Directory -Path $RelDir
New-Item -Name 'MigrationTool'  -ItemType Directory -Path $RelDir
New-Item -Name 'ReleaseNotes'  -ItemType Directory -Path $RelDir
   





### Creating Sub FOlders
$DBScripts = $RelDir + '\Database'
New-Item -Name 'DBScripts\DDL'  -ItemType Directory -Path $DBScripts
New-Item -Name 'DBScripts\DML'  -ItemType Directory -Path $DBScripts


$Reports = $RelDir + '\Reports'
New-Item -Name 'RDLs'  -ItemType Directory -Path  $Reports
New-Item -Name 'ReportHelper'  -ItemType Directory -Path  $Reports

if ( $isDirectoryOnlyRequired -eq 0){

### Creating Sub FOlders
$LP = $RelDir + '\LessorPortal'
New-Item -Name 'App_Data'  -ItemType Directory -Path $LP

### Creating WbAPI\DomainAssemblies
$WebAPI = $RelDir + '\WebAPI'
New-Item -Name 'DomainAssemblies'  -ItemType Directory -Path $WebAPI
New-Item -Name 'App_Data'  -ItemType Directory -Path $WebAPI

if($FRWK_Version -ne '0')
{
##   Fill FRWK folders
write-host 'Preparing WindowsService...'

if($IsDotNet7Upgraded -eq '1')
{
    if($IsDotNet7 -eq '1')
    {
        $SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\net7.0\'
    }
    else
    {
        $SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\net48\'
    }
}
else
{
    $SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\'
}

write-host 'WindowsService Source path: ' $SourceWindowService
$DestWindowService = $RelDir + '\WindowsService\'
if(Test-Path $SourceWindowService)
{
 robocopy $SourceWindowService $DestWindowService /E /copyall
}
##Copy Lw.Domain dll's
$Window0 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Extension.dll'
$Window1 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Project.Extension.dll'
$Window2 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Project.Resource.dll'
$Window3 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Resource.dll'

if($IsRegionLayer -eq '1')
{
    $Window4 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Region.Extension.dll'
    $Window5 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Region.Resource.dll'
    $Window6 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Odessa.Domain.Integration.dll'
}
elseif($IsProjectCoreLayer -eq '1')
{
    $Window4 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.ProjectCore.Extension.dll'
    $Window5 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.ProjectCore.Resource.dll'
}


if($IsLW5UpgradeLayer -eq '1')
{
    $Window4 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.ProjectCore.Extension.dll'
    $Window5 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.ProjectCore.Resource.dll'
}

## PDFSharpder & FastMember dll's to copy Lessorportal bin and job service bin
#if($IsProjectCoreLayer -eq '1')
#{
#$SourceFM= $packagePath = 'C:\Users\devops.admin\.nuget\packages\lw.productdependent\1.0.0\tools\FastMember.dll'
#$SourcePDF= $packagePath = 'C:\Users\devops.admin\.nuget\packages\lw.productdependent\1.0.0\tools\PdfSharp.dll'

#$LPBin= $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\'
#$Job =  $RelDir + '\WindowsService\'
#if(Test-path $SourceFM)
#{
#    Copy-Item $SourceFM $LPBin
#    Copy-Item $SourceFM $Job
#}
#if(Test-path $SourcePDF)
#{
#    Copy-Item $SourcePDF $LPBin
#    Copy-Item $SourcePDF $Job
#}
#}
##

if($IsEMMLayer -eq '1')
{
    $Window7 = $Artifact_Build_Path + '\Odessa.Domain.Integration.dll'
}

$Window8 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\System.Diagnostics.DiagnosticSource.dll'
$Window9 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.ApplicationInsights.dll'
if($IsProjectCoreLayer -eq '1')
{
    $Window10 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.ProjectCore\bin\PdfSharp.dll'
    $Window11 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.ProjectCore\bin\PdfSharp.Charting.dll'
}
else
{
    $Window10 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\PdfSharp.dll'
    $Window11 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\PdfSharp.Charting.dll'
}
$Window12 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\BouncyCastle.Crypto.dll'
$Window13 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Renci.SshNet.dll'
$Window14 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\PgpCore.dll'
$Window15 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.PowerBI.Api.dll'
$Window16 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Rest.ClientRuntime.dll'
$Window17 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Plugin.*.dll'

$Window18 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\FastMember.Signed.dll'
$Window19 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.GreatPlains.Data.Entities.dll'
$Window20 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Castle.Core.dll'
$Window21 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Syncfusion.Compression.Base.dll'

$Window22 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.DependencyCollector.dll'
$Window23 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.PerfCounterCollector.dll'
$Window24 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.Web.dll'
$Window25 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.WindowsServer.dll'
$Window26 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AspNet.TelemetryCorrelation.dll'
$Window27 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.ServerTelemetryChannel.dll'
$Window28 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Resources.dll'
$Window29 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Dynamics.GP.eConnect.dll'
$Window30 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Dynamics.GP.eConnect.Serialization.dll'
$Window31 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\WinSCP.exe'
$Window32 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\WinSCPnet.dll'
$Window33 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\PdfSharpCore.dll'
$Window34 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Base.dll'
$Window35 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Azure.dll'
$Window36 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.AzureAppConfiguration.dll'
$Window37 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Environment.dll'
$Window38 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.UserSecrets.dll'
$Window39 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\LocalizerAssemblies\Lw.Domain.Extension.Resources.dll'

if(Test-path $Window0){
    Copy-Item $Window0 $DestWindowService
}
if(Test-path $Window1){
    Copy-Item $Window1 $DestWindowService
}
if(Test-path $Window2){
    Copy-Item $Window2 $DestWindowService 
}
if(Test-path $Window3){
    Copy-Item $Window3 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window4)) -and (Test-path $Window4)){
    Copy-Item $Window4 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window5)) -and (Test-path $Window5)){
    Copy-Item $Window5 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window6)) -and (Test-path $Window6)){
    Copy-Item $Window6 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window7)) -and (Test-path $Window7)){
    Copy-Item $Window7 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window8)) -and (Test-path $Window8)){
    Copy-Item $Window8 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window9)) -and (Test-path $Window9)){
    Copy-Item $Window9 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window10)) -and (Test-path $Window10)){
    Copy-Item $Window10 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window11)) -and (Test-path $Window11)){
    Copy-Item $Window11 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window12)) -and (Test-path $Window12)){
    Copy-Item $Window12 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window13)) -and (Test-path $Window13)){
    Copy-Item $Window13 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window14)) -and (Test-path $Window14)){
    Copy-Item $Window14 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window15)) -and (Test-path $Window15)){
    Copy-Item $Window15 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window16)) -and (Test-path $Window16)){
    Copy-Item $Window16 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window17)) -and (Test-path $Window17)){
    Copy-Item $Window17 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window18)) -and (Test-path $Window18)){
    Copy-Item $Window18 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window19)) -and (Test-path $Window19)){
    Copy-Item $Window19 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window20)) -and (Test-path $Window20)){
    Copy-Item $Window20 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window21)) -and (Test-path $Window21)){
    Copy-Item $Window21 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window22)) -and (Test-path $Window22)){
    Copy-Item $Window22 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window23)) -and (Test-path $Window23)){
    Copy-Item $Window23 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window24)) -and (Test-path $Window24)){
    Copy-Item $Window24 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window25)) -and (Test-path $Window25)){
    Copy-Item $Window25 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window26)) -and (Test-path $Window26)){
    Copy-Item $Window26 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window27)) -and (Test-path $Window27)){
    Copy-Item $Window27 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window28)) -and (Test-path $Window28)){
    Copy-Item $Window28 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window29)) -and (Test-path $Window29)){
    Copy-Item $Window29 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window30)) -and (Test-path $Window30)){
    Copy-Item $Window30 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window31)) -and (Test-path $Window31)){
    Copy-Item $Window31 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window32)) -and (Test-path $Window32)){
    Copy-Item $Window32 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window33)) -and (Test-path $Window33)){
    Copy-Item $Window33 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window34)) -and (Test-path $Window34)){
    Copy-Item $Window34 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window35)) -and (Test-path $Window35)){
    Copy-Item $Window35 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window36)) -and (Test-path $Window36)){
    Copy-Item $Window36 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window37)) -and (Test-path $Window37)){
    Copy-Item $Window37 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window38)) -and (Test-path $Window38)){
    Copy-Item $Window38 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window39)) -and (Test-path $Window39)){
    Copy-Item $Window39 $DestWindowService 
}
##Copy Tavalue to WindowService bin folder

$SourceTValue1 = $Artifact_Build_Path + '\TValue6.dll'
$SourceTvalue2 = $Artifact_Build_Path + '\Tvalue6Engine2.dll'

if(!([string]::IsNullOrEmpty($SourceTValue1)) -and (Test-path $SourceTValue1))
{
    copy-item $SourceTValue1 $DestWindowService
}
if(!([string]::IsNullOrEmpty($SourceTValue2)) -and (Test-path $SourceTValue2))
{
    copy-item $SourceTValue2 $DestWindowService
}

write-host 'Completed WindowsService...'


##COpy Tvalue DLL to TValueBinaries folder
$TvaluePath = $RelDir + '\TValueBinaries\'

if(!([string]::IsNullOrEmpty($SourceTValue1)) -and (Test-path $SourceTValue1))
{
    copy-item $SourceTValue1 $TvaluePath
}
if(!([string]::IsNullOrEmpty($SourceTValue2)) -and (Test-path $SourceTValue2))
{
    copy-item $SourceTValue2 $TvaluePath
}

##

write-host 'Preparing DocPortal...'
$SourceDocportal = $FRWKABSPath + '\Tools\LW.Docportal\'
$DestDocportal = $RelDir + '\Docportal\'
if(Test-Path $SourceDocportal)
{
    robocopy $SourceDocportal $DestDocportal /E /copyall
}
write-host 'Completed Docportal...'

write-host 'Preparing WebAPI...'

if($IsDotNet7Upgraded -eq '1')
{
    if($IsDotNet7 -eq '1')
    {
        $SourceWebAPI = $FRWKABSPath + '\Tools\Lw.WebApi\net7.0\'
    }
    else
    {
        $SourceWebAPI = $FRWKABSPath + '\Tools\Lw.WebApi\net48\'
    }
}
else
{
    $SourceWebAPI = $FRWKABSPath + '\Tools\Lw.WebApi\'
}
$DestWebAPI = $RelDir + '\WebAPI\'
write-host 'Before RoboCopy Web API Source Path...' $SourceWebAPI
if(Test-Path $SourceWebAPI)
{
  robocopy $SourceWebAPI $DestWebAPI /E /copyall  
}
write-host 'After RoboCopy Web API Source Path...' $SourceWebAPI

##Copy LW.dll's
$SourceWebAPIDomain1 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Extension.dll'
$SourceWebAPIDomain2 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Resource.dll'
$SourceWebAPIDomain3 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Project.Extension.dll'
$SourceWebAPIDomain4 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Project.Resource.dll'

if($IsRegionLayer -eq '1')
{
    $SourceWebAPIDomain5 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Region.Extension.dll'
    $SourceWebAPIDomain6 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Region.Resource.dll'
}
elseif($IsProjectCoreLayer -eq '1')
{
    $SourceWebAPIDomain5 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.ProjectCore.Extension.dll'
    $SourceWebAPIDomain6 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.ProjectCore.Resource.dll'
}
elseif($IsLW5UpgradeLayer -eq '1')
{
     $SourceWebAPIDomain5 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.ProjectCore.Extension.dll'
     $SourceWebAPIDomain6 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.ProjectCore.Resource.dll'
}
if($IsProjectCoreLayer -eq '1')
{
    $SourceWebAPIDomain7 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.ProjectCore\bin\PdfSharp.dll'
    $SourceWebAPIDomain8 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.ProjectCore\bin\PdfSharp.Charting.dll'
}
else
{
    $SourceWebAPIDomain7 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\PdfSharp.dll'
    $SourceWebAPIDomain8 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\PdfSharp.Charting.dll'
}
$SourceWebAPIDomain9 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\BouncyCastle.Crypto.dll'
$SourceWebAPIDomain10 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Renci.SshNet.dll'
$SourceWebAPIDomain11 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\PgpCore.dll'
$SourceWebAPIDomain12 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\System.Diagnostics.DiagnosticSource.dll'
$SourceWebAPIDomain13 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.ApplicationInsights.dll'
$SourceWebAPIDomain14 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.PowerBI.Api.dll'
$SourceWebAPIDomain15 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Rest.ClientRuntime.dll'
$SourceWebAPIDomain16 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Plugin.*.dll'
$SourceWebAPIDomain17 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\FastMember.Signed.dll'
$SourceWebAPIDomain18 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.GreatPlains.Data.Entities.dll'
$SourceWebAPIDomain19 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Castle.Core.dll'
$SourceWebAPIDomain20 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Syncfusion.Compression.Base.dll'

$SourceWebAPIDomain21 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.DependencyCollector.dll'
$SourceWebAPIDomain22 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.PerfCounterCollector.dll'
$SourceWebAPIDomain23 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.Web.dll'
$SourceWebAPIDomain24 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.WindowsServer.dll'
$SourceWebAPIDomain25 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AspNet.TelemetryCorrelation.dll'
$SourceWebAPIDomain26 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.ServerTelemetryChannel.dll'
$SourceWebAPIDomain27 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Lw.Domain.Resources.dll'
$SourceWebAPIDomain28 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Dynamics.GP.eConnect.dll'
$SourceWebAPIDomain29 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Dynamics.GP.eConnect.Serialization.dll'
$SourceWebAPIDomain30 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\PdfSharpCore.dll'
$SourceWebAPIDomain31 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Base.dll'
$SourceWebAPIDomain32 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Azure.dll'
$SourceWebAPIDomain33 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.AzureAppConfiguration.dll'
$SourceWebAPIDomain34 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Environment.dll'
$SourceWebAPIDomain35 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.UserSecrets.dll'

if(Test-path $SourceTValue1){
$SourceTValue1 = $Artifact_Build_Path + '\TValue6.dll'
$SourceTvalue2 = $Artifact_Build_Path + '\Tvalue6Engine2.dll'
}
        

$DestWebAPI_bin = $DestWebAPI + 'bin\'

write-host $SourceWebAPIDomain1
write-host $DestWebAPI_bin

if(Test-path $SourceWebAPIDomain1){
   if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain1 $DestWebAPI_bin 
   }
}
if(Test-path $SourceWebAPIDomain2){
   if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain2 $DestWebAPI_bin 
   }
}
if(Test-path $SourceWebAPIDomain3){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain3 $DestWebAPI_bin 
    }
}
if(Test-path $SourceWebAPIDomain4){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain4 $DestWebAPI_bin 
   }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain5)) -and (Test-path $SourceWebAPIDomain5)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain5 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain6)) -and (Test-path $SourceWebAPIDomain6)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain6 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain7)) -and (Test-path $SourceWebAPIDomain7)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain7 $DestWebAPI_bin
    } 
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain8)) -and (Test-path $SourceWebAPIDomain8)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain8 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain9)) -and (Test-path $SourceWebAPIDomain9)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain9 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain10)) -and (Test-path $SourceWebAPIDomain10)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain10 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain11)) -and (Test-path $SourceWebAPIDomain11)){
    if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain11 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain12)) -and (Test-path $SourceWebAPIDomain12)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain12 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain13)) -and (Test-path $SourceWebAPIDomain13)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain13 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain14)) -and (Test-path $SourceWebAPIDomain14)){
    if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain14 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain15)) -and (Test-path $SourceWebAPIDomain15)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain15 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain16)) -and (Test-path $SourceWebAPIDomain16)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain16 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain17)) -and (Test-path $SourceWebAPIDomain17)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain17 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain18)) -and (Test-path $SourceWebAPIDomain18)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain18 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain19)) -and (Test-path $SourceWebAPIDomain19)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain19 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain20)) -and (Test-path $SourceWebAPIDomain20)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain20 $DestWebAPI_bin 
    }
}

if(!([string]::IsNullOrEmpty($SourceWebAPIDomain21)) -and (Test-path $SourceWebAPIDomain21)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain21 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain22)) -and (Test-path $SourceWebAPIDomain22)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain22 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain23)) -and (Test-path $SourceWebAPIDomain23)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain23 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain24)) -and (Test-path $SourceWebAPIDomain24)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain24 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain25)) -and (Test-path $SourceWebAPIDomain25)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain25 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain26)) -and (Test-path $SourceWebAPIDomain26)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain26 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain27)) -and (Test-path $SourceWebAPIDomain27)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain27 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain28)) -and (Test-path $SourceWebAPIDomain28)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain28 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain29)) -and (Test-path $SourceWebAPIDomain29)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain29 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain30)) -and (Test-path $SourceWebAPIDomain30)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain30 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain31)) -and (Test-path $SourceWebAPIDomain31)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain31 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain32)) -and (Test-path $SourceWebAPIDomain32)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain32 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain33)) -and (Test-path $SourceWebAPIDomain33)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain33 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain34)) -and (Test-path $SourceWebAPIDomain34)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain34 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceWebAPIDomain35)) -and (Test-path $SourceWebAPIDomain35)){
     if(Test-path $DestWebAPI_bin)
   {
    copy-item $SourceWebAPIDomain35 $DestWebAPI_bin 
    }
}
if(!([string]::IsNullOrEmpty($SourceTValue1)) -and (Test-path $SourceTValue1))
{
    if(Test-path $DestWebAPI_bin)
    {
        copy-item $SourceTValue1 $DestWebAPI_bin         
    }
}
if(!([string]::IsNullOrEmpty($SourceTValue2)) -and (Test-path $SourceTValue2))
{
    if(Test-path $DestWebAPI_bin)
    {
        copy-item $SourceTValue2 $DestWebAPI_bin 
    }
}

##Copy WebAPi \ DomainAssemblies
$SourceDomainAs1 = $Artifact_Build_Path + '\Lw.Domain.dll'
$SourceDomainAs2 = $Artifact_Build_Path + '\LW.Domain.PDB'
$WebAPIDestiation = $RelDir + '\WebAPI\DomainAssemblies\'

Copy-Item $SourceDomainAs1 $WebAPIDestiation
Copy-Item $SourceDomainAs2 $WebAPIDestiation

write-host 'Completed WebAPI...'

write-host 'Preparing WebServices...'

$SourceWebServices = $Artifact_Build_Path + '\_PublishedWebsites\Lw.WebServices\'
$DestWebServices = $RelDir + '\WebServices\'
if(!([string]::IsNullOrEmpty($SourceWebServices)) -and (Test-path $SourceWebServices))
{
    robocopy $SourceWebServices $DestWebServices /E /copyall
}
write-host 'Completed WebServices...'


write-host 'Preparing SqlServices...'
$SourceSqlServices = $FRWKABSPath + '\Tools\Lw.SqlServices\'
$DestSqlServices = $RelDir + '\SqlServices\'
if(Test-Path $SourceSqlServices)
{
  robocopy $SourceSqlServices $DestSqlServices /E /copyall
  write-host 'Completed SqlServices...'
}
write-host 'Preparing MigrationTool...'
$SourceMigrationTool = $FRWKABSPath + '\Tools\Lw.MigrationClient\'
$DestMigrationTool = $RelDir + '\MigrationTool\'

if(Test-Path $SourceMigrationTool)
{
    robocopy $SourceMigrationTool $DestMigrationTool /E /copyall

    ##Copy Lw.Domain dll's
    $LD = $Artifact_Build_Path + '\Lw.Domain.dll'
    $LDE = $Artifact_Build_Path + '\Lw.Domain.Extension.dll'
    $LDPE = $Artifact_Build_Path + '\Lw.Domain.Project.Extension.dll'
    $LDPR = $Artifact_Build_Path + '\Lw.Domain.Project.Resource.dll'
    $LDR = $Artifact_Build_Path + '\Lw.Domain.Resource.dll'
    $LM = $Artifact_Build_Path + '\Lw.Migration.dll'

    if($IsRegionLayer -eq '1')
    {
      $LDRE = $Artifact_Build_Path + '\Lw.Domain.Region.Extension.dll'
      $LDRR = $Artifact_Build_Path + '\Lw.Domain.Region.Resource.dll'
    }
    elseif($IsProjectCoreLayer -eq '1')
    {
      $LDRE = $Artifact_Build_Path + '\Lw.Domain.ProjectCore.Extension.dll'
      $LDRR = $Artifact_Build_Path + '\Lw.Domain.ProjectCore.Resource.dll'
    }


    if(Test-path $LD){
        Copy-Item $LD $DestMigrationTool
    }
    if(Test-path $LDE){
        Copy-Item $LDE $DestMigrationTool
    }
    if(Test-path $LDPE){
        Copy-Item $LDPE $DestMigrationTool 
    }
    if(Test-path $LDPR){
        Copy-Item $LDPR $DestMigrationTool 
    }
    if(Test-path $LDR){
        Copy-Item $LDR $DestMigrationTool 
    }
    if(!([string]::IsNullOrEmpty($LDRE)) -and (Test-path $LDRE)){
        Copy-Item $LDRE $DestMigrationTool 
    }
    if(!([string]::IsNullOrEmpty($LDRR)) -and (Test-path $LDRR)){
        Copy-Item $LDRR $DestMigrationTool 
    }

    if(Test-path $LM)
    {
      Copy-Item $LM $DestMigrationTool 
    }
}
##Copy Tavalue 

$STValue1 = $Artifact_Build_Path + '\TValue6.dll'
$STvalue2 = $Artifact_Build_Path + '\Tvalue6Engine2.dll'

if(!([string]::IsNullOrEmpty($STValue1)) -and (Test-path $STValue1))
{
    copy-item $STValue1 $DestMigrationTool
}
if(!([string]::IsNullOrEmpty($STvalue2)) -and (Test-path $STvalue2))
{
    copy-item $STvalue2 $DestMigrationTool
}

write-host 'Completed MigrationTool...'

if ($lastexitcode -lt 8) { $lastexitcode = 0 }

}
}