﻿param(
[parameter (Mandatory=$true, position=1, ParameterSetName='IIS')]
[string]$SrcPackagePath,
[parameter (Mandatory=$true, position=2, ParameterSetName='IIS')]
[string]$TarPackagePath,
[parameter (Mandatory=$true, position=3, ParameterSetName='IIS')]
[string]$TarPackageLocalPath,
[parameter (Mandatory=$true, position=4, ParameterSetName='IIS')]
[string]$TarServer,
[parameter (Mandatory=$true, position=5, ParameterSetName='IIS')]
[string]$ServicePath
)

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") + '.zip'
$SrcPackagePath = $SrcPackagePath + $currentDate
$SrcPackagePath

if((Test-Path $SrcPackagePath) -eq $false){
Write-Host "No package found $packagePath"
return
}

#Copying zip package to VM Cloud server Drop
write-host 'Starting zip copy'
copy-item $SrcPackagePath $TarPackagePath -Force
write-host 'Compelted zip copy'

#############################################################################################################

#Unzip the package on VM Cloud
    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd")
    $PackagePath = $TarPackageLocalPath + $currentDate
    $PackagePath
Invoke-Command -Computername $TarServer -ScriptBlock {
param ($Src,$Dest)

$Src = $Src + ".zip"
      
         write-host 'Starting Unziping'
         write-host $Src $Dest
         Expand-Archive -Path $Src -DestinationPath $Dest -Force
         write-host 'Completed Unziping'

} -ArgumentList $PackagePath,$TarPackageLocalPath

##############################################################################################################
Write-Host 'Starting Package Config Cleanup'
Invoke-Command -Computername $TarServer -ScriptBlock {
param ($PackagePath)
         $ttPath = $PackagePath + "\*.tt"
if ( Test-Path $ttPath)
{
    Remove-Item -Path $ttPath -Recurse -force
}

Remove-Item –path $PackagePath -include AppSettings.config –recurse
Remove-Item –path $PackagePath -include ConnectionStrings.config –recurse
Remove-Item –path $PackagePath -include Lw.WindowsServices.exe.config –recurse
Remove-Item –path $PackagePath -include Web.config –recurse
}-ArgumentList $PackagePath
Write-Host 'Completed Package Config Cleanup'

##############################################################################################################
#Patch to Windows Service
Invoke-Command -Computername $TarServer -ScriptBlock {
param ($PackagePath, $ServicePath)
        
         if((Test-Path $ServicePath) -eq $false){
         Write-Host "WindowsService path - $ServicePath not found"
              return
         }

         Remove-Item -Path $ServicePath -Exclude *.config,*.bat -Force -Recurse -Verbose

         Write-Host 'Starting WindowsService patch'
         $WindowsService = $PackagePath + '\WindowsService'
         Write-Host $WindowsService $ServicePath

         Robocopy $WindowsService $ServicePath /S /E /Z /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /XO /COPY:DT
         Write-Host 'WindowsService patch Done' 

} -ArgumentList $PackagePath, $ServicePath

##############################################################################################################

if ($lastexitcode -lt 8) { $lastexitcode = 0 }