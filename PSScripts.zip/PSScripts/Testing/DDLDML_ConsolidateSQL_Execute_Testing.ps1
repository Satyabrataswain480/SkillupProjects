﻿
Param (

#[parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
#[string]$SQLServer,
#[parameter (Mandatory=$true, position=1, ParameterSetName='Database')]
#[string]$DatabaseName,
[parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
[string]$FolderPath,
[parameter (Mandatory=$false, position=1, ParameterSetName='Database')]
[string]$ProjectName,
[parameter (Mandatory=$false, position=2, ParameterSetName='Database')]
[string]$IsDBOnlyReleaseForStaging = '0'

)

#$TargetDB="$ENV:DBName"
#$DataBaseServer="$ENV:DBSERVER"
#$FolderPath="$ENV:PackageExtractionPath\$ENV:Version\database\DBScripts"

if($IsDBOnlyReleaseForStaging -eq '0'){
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$FolderPath = $FolderPath + "\" + $currentDate + "\"
$FolderPath = $FolderPath + 'Database\DBScripts\'
}

Write-Host $IsDBOnlyReleaseForStaging
Write-Host $FolderPath

#Getting the script from DDL folder
Write-Host "Getting the scripts from DDL Folder"
$ScriptsArray=@()
$path = "$FolderPath\DDL\"

$content="SET XACT_ABORT ON; BEGIN TRANSACTION FinalOne;"
Get-ChildItem $path -Filter *.sql | 
Foreach-Object {
$ScriptsArray += $_.BaseName  
  }
   $mySortAsc = @{Expression={ [regex]::Replace($_ ,'\d+', { $args[0].Value.PadLeft(20,'0') }) };Descending=$false}    
    $nl = [Environment]::NewLine
  $ScriptsArray =   $ScriptsArray | Sort-Object | Sort-Object $mySortAsc
if($ReleaseScriptName -eq $null){$ReleaseScriptName = ""}
foreach($files in $ScriptsArray){
   if($Files -notin $ReleaseScriptName )
    {
    $FullName = "$path\$files.sql"
    $BseName = $Files
    write-host $BseName
    $content +="--------------------"+$BseName+"-------------------"
    $content +="`n" 
    $content +=[System.IO.File]::ReadAllText($FullName)
    $content +="`n"
    $content +="---------------------------------------" 
    $content +="`n"
   # $content +="INSERT INTO [dbo].[ReleaseVersionDetails] ([ReleaseScriptName],[IsExecuted],[CreatedById],[CreatedTime],[UpdatedById],[UpdatedTime],[ReleaseVersionId]) VALUES ('"+$BseName+"',1,1,GETDATE(),null,null,"+$ReleaseVersionNumber+")"
    $content +="`n"
    $content +="---------------------------------------" 
    $content +="`n"
  }
  }

  #Getting the script from DML folder
Write-Host "Getting the scripts from DML Folder"

$ScriptsArray=@()
$path = "$FolderPath\DML\"
Get-ChildItem $path -Filter *.sql | 
Foreach-Object {
$ScriptsArray += $_.BaseName  
  }
   $mySortAsc = @{Expression={ [regex]::Replace($_ ,'\d+', { $args[0].Value.PadLeft(20,'0') }) };Descending=$false}    
    $nl = [Environment]::NewLine
  $ScriptsArray =   $ScriptsArray | Sort-Object | Sort-Object $mySortAsc
if($ReleaseScriptName -eq $null){$ReleaseScriptName = ""}
foreach($files in $ScriptsArray){
   if($Files -notin $ReleaseScriptName )
    {
    $FullName = "$path\$files.sql"
    $BseName = $Files
    write-host $BseName
    $content +="--------------------"+$BseName+"-------------------"
    $content +="`n" 
    $content +=[System.IO.File]::ReadAllText($FullName)
    $content +="`n"
    $content +="---------------------------------------" 
    $content +="`n"
   # $content +="INSERT INTO [dbo].[ReleaseVersionDetails] ([ReleaseScriptName],[IsExecuted],[CreatedById],[CreatedTime],[UpdatedById],[UpdatedTime],[ReleaseVersionId]) VALUES ('"+$BseName+"',1,1,GETDATE(),null,null,"+$ReleaseVersionNumber+")"
    $content +="`n"
    $content +="---------------------------------------" 
    $content +="`n"
  }
  }


$content += "COMMIT TRANSACTION FinalOne;

GO
SELECT 1  as IsTransActionCompleted FROM sys.dm_tran_active_transactions where Name ='FinalOne'"
write-host '**************************************************************************************************************************************'
Write-Host 'Content to be Executed'
Write-host $content
$ConsolidatedFilePath = "$FolderPath\ConsolidateScripts.sql"
$content | Set-Content -Encoding UTF8 -path $ConsolidatedFilePath
#$val =  Invoke-Sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -InputFile $ConsolidatedFilePath -erroraction stop  -QueryTimeout 65500
#$IsTransActionCompleted = $val.IsTransActionCompleted 
#if($IsTransActionCompleted -eq "1") {
#Write-Host 'TransAction is not commited'
#Write-Host "##vso[task.complete result=Failed;]DONE" 
#}
#else
#{
#Write-Host 'Transction is completed'
#}



