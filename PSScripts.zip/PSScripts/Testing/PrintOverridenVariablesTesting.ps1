﻿Param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='release')]
    [string]$AppSettingsConfig,    
    [parameter(Mandatory=$true, position=2, ParameterSetName='release')]
    [string]$COTicket,   
    [parameter(Mandatory=$true, position=3, ParameterSetName='release')]
    [string]$CustomerPortal,    
    [parameter(Mandatory=$true, position=4, ParameterSetName='release')]
    [string]$Database,    
    [parameter(Mandatory=$true, position=5, ParameterSetName='release')]
    [string]$DocPortal,    
    [parameter(Mandatory=$true, position=6, ParameterSetName='release')]
    [string]$LessorPortal,    
    [parameter(Mandatory=$true, position=7, ParameterSetName='release')]
    [string]$License,   
    [parameter(Mandatory=$true, position=8, ParameterSetName='release')]
    [string]$MigrationTool,    
    [parameter(Mandatory=$true, position=9, ParameterSetName='release')]
    [string]$PricingService,    
    [parameter(Mandatory=$true, position=10, ParameterSetName='release')]
    [string]$ReleaseDate,    
    [parameter(Mandatory=$true, position=11, ParameterSetName='release')]
    [string]$ReleaseTime,    
    [parameter(Mandatory=$true, position=12, ParameterSetName='release')]
    [string]$ReleaseVersion,   
    [parameter(Mandatory=$true, position=13, ParameterSetName='release')]
    [string]$Reports,   
    [parameter(Mandatory=$true, position=14, ParameterSetName='release')]
    [string]$SqlServices,    
    [parameter(Mandatory=$true, position=15, ParameterSetName='release')]
    [string]$TValueBinaries,    
    [parameter(Mandatory=$true, position=16, ParameterSetName='release')]
    [string]$UserManual,  
    [parameter(Mandatory=$true, position=17, ParameterSetName='release')]
    [string]$VendorPortal,    
    [parameter(Mandatory=$true, position=18, ParameterSetName='release')]
    [string]$WebandJobConfig,   
    [parameter(Mandatory=$true, position=19, ParameterSetName='release')]
    [string]$WebAPI,    
    [parameter(Mandatory=$true, position=20, ParameterSetName='release')]
    [string]$WebAPIConfig,    
    [parameter(Mandatory=$true, position=21, ParameterSetName='release')]
    [string]$WebServices,    
    [parameter(Mandatory=$true, position=22, ParameterSetName='release')]
    [string]$WindowsService,
    [parameter(Mandatory=$true, position=23, ParameterSetName='release')]
    [string]$Portal,
    [parameter(Mandatory=$true, position=24, ParameterSetName='release')]
    [string]$IsHotFix,
    [parameter(Mandatory=$true, position=25, ParameterSetName='release')]
    [string]$IsDataFix,
    [parameter(Mandatory=$true, position=26, ParameterSetName='release')]
    [string]$IsRestartRequired
)

Write-Host "AppSettingsConfig -->" $AppSettingsConfig
Write-Host "COTicket -->" $COTicket
Write-Host "CustomerPortal -->" $CustomerPortal
Write-Host "Database -->" $Database
Write-Host "DocPortal -->" $DocPortal
Write-Host "LessorPortal -->" $LessorPortal
Write-Host "License -->" $License
Write-Host "MigrationTool -->" $MigrationTool
Write-Host "PricingService -->" $PricingService
Write-Host "ReleaseDate -->" $ReleaseDate
Write-Host "ReleaseTime -->" $ReleaseTime
Write-Host "ReleaseVersion -->" $ReleaseVersion
Write-Host "Reports -->" $Reports
Write-Host "SqlServices -->" $SqlServices
Write-Host "TValueBinaries -->" $TValueBinaries
Write-Host "UserManual -->" $UserManual
Write-Host "VendorPortal -->" $VendorPortal
Write-Host "WebandJobConfig -->" $WebandJobConfig
Write-Host "WebAPI -->" $WebAPI
Write-Host "WebAPIConfig -->" $WebAPIConfig
Write-Host "WebServices -->" $WebServices
Write-Host "WindowsService -->" $WindowsService
Write-Host "Portal -->" $Portal
Write-Host "IsHotFix -->" $IsHotFix
Write-Host "IsDataFix -->" $IsDataFix
Write-Host "IsRestartRequired -->" $IsRestartRequired