﻿param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='db')]
    [string]$dbName,
    [parameter(Mandatory=$true, position=2, ParameterSetName='db')]
    [string]$backupPath
)


  $SQLServer = 'use2intperftstdb01.a392e078d0e4.database.windows.net'
  $DB_UserName = 'cloudopsadmin'
  $DB_Password = 'CloudOde$$@2024#2025'
  $StorageAccountName = 'eus2intdevsa'
  $ContainerName = 'dbbackup'
  $StorageSASToken = 'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwlacupitfx&se=2025-06-30T16:55:44Z&st=2024-07-15T06:35:44Z&spr=https,http&sig=9pPR4ikZonCgUwu1sVmrZv205prkIClC8S7WGAnIC3g%3D'
  $url = 'https://eus2intdevsa.blob.core.windows.net'


Write-Host 'SQL MI Server - ' $SQLServer

if ($backupPath -notlike "*.bak") {
    Write-Output "The backup path is not correct. Please check the Backup Path if it has .bak extension."
} 

#If Db already exists 
$DbExistQuery = "SELECT COUNT(*) FROM sys.databases WHERE name = '$dbName'"
$DbExistQuery
$exist = invoke-sqlcmd -ServerInstance $SQLServer -Database 'master' -Username $DB_UserName -Password $DB_Password -Query $DbExistQuery  -QueryTimeout 65500 -ErrorAction Stop
#$ans.Column1

if($exist.Column1 -eq 1){

Write-Host '*** Db already Exist, Db will be deleted ***'

$dbDeleteQuery = "DROP Database $dbName
GO"
invoke-sqlcmd -ServerInstance $SQLServer -Database 'master' -Username $DB_UserName -Password $DB_Password -Query $dbDeleteQuery  -QueryTimeout 65500 -ErrorAction Stop

}
else{
Write-Host '*** Db Dont exsit. New Db will be restored ***'
}

#upload db backup to container

Import-Module Az

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

# Create the storage context using the SAS token
$StorageContext = New-AzStorageContext -StorageAccountName $StorageAccountName -SasToken $StorageSASToken 


# Get the blob name from the file name
$blobName = [System.IO.Path]::GetFileName($backupPath)

Write-Host 'Upload Started'

# Upload the file to the specified container
Set-AzStorageBlobContent -File $backupPath -Container $ContainerName -Context $StorageContext -Blob $blobName -Force -Properties @{"ContentType" = [System.Web.MimeMapping]::GetMimeMapping($backupPath)}

Write-Host 'Upload Done'

Write-Host 'Restore Started'

$dbRestoreQuery = "RESTORE DATABASE $dbName FROM URL =
  '$url/dbbackup/$BlobName'
GO"
$dbRestoreQuery

invoke-sqlcmd -ServerInstance $SQLServer -Database 'Master' -Username $DB_UserName -Password $DB_Password -Query $dbRestoreQuery  -QueryTimeout 65500 -ErrorAction Stop

Write-Host 'Restore Done'

