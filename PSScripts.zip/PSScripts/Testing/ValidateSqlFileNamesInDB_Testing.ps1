param(
    [parameter (Mandatory=$true, Position=0, ParameterSetName='Database')]
    [string]$sqlSource,
    [parameter (Mandatory=$true, Position=1, ParameterSetName='Database')]
    [string]$cloud_dbServer,
    [parameter (Mandatory=$true, Position=2, ParameterSetName='Database')]
    [string]$cloud_dbName,
    [parameter (Mandatory=$true, Position=3, ParameterSetName='Database')]
    [string]$cloud_dbusername,
    [parameter (Mandatory=$true, Position=4, ParameterSetName='Database')]
    [string]$cloud_dbpassword,
    [parameter (Mandatory=$false, Position=5, ParameterSetName='Database')]
    [string]$issqlmi
)

Write-Host "Server Name: "$cloud_dbServer
Write-Host "DB     Name: "$cloud_dbName
Write-Host "Package path: "$sqlSource

Import-Module SQLPS

class ScriptNameException : Exception {
    [string] $ScriptName

    ScriptNameException ($Message, $ScriptName) : base ($Message) {
        $this.ScriptName = $ScriptName
    }
}
## Get all Release Script Name present in ReleaseVersionDetails table
function global:GetScriptNamesInDB() {
    Write-Host "getting all script names in DB.."
    $GetDbScriptsQuery = "select ReleaseScriptName from ReleaseVersionDetails"

    if($issqlmi -eq '1')
    {
        $ScriptsInDB = Invoke-Sqlcmd -ErrorAction 'Stop' -querytimeout 0  -ServerInstance  $cloud_dbServer -Database  $cloud_dbName -Username $cloud_dbusername -Password $cloud_dbpassword -Query $GetDbScriptsQuery -ConnectionTimeout 77777
    }
    else
    {
        $ScriptsInDB = Invoke-Sqlcmd -ErrorAction 'Stop' -querytimeout 0  -ServerInstance  $cloud_dbServer -Database  $cloud_dbName -Query $GetDbScriptsQuery -ConnectionTimeout 77777
    }

    $ScriptNamesInDB = @($ScriptsInDB | select -ExpandProperty ReleaseScriptName)
  
    IF ([string]::IsNullOrEmpty($ScriptNamesInDB)) {            
        return $ScriptNamesInDB
    } 
    else {            
        return $ScriptNamesInDB.Trim()
    }  
    Write-Host "end of GetScriptNamesInDB.."
}

## Get all the scripts from package location and return after sorting the list(Precedence will be numbers then alphabet)
function global:GetAllScriptsNameInPackage {
    Write-Host "getting all scripts from Package.."
 
    $ScriptFiles = Get-ChildItem -Path "$sqlSource" -Filter "*.sql" -Recurse | Where-Object { $_.DirectoryName -match 'DDL|DML' } | Select-Object -ExpandProperty BaseName

    $versionList = New-Object System.Collections.ArrayList($null)

    foreach ($ScriptFile in $ScriptFiles) {               
        [void]$versionList.Add($ScriptFile)            
    }
  
    Write-host "sorting the scripts..."

    $versionList.sort()

    return $versionList

}

Try {
    $timeout = New-Object System.TimeSpan -ArgumentList @(5, 0, 0) # five hours
    $options = [System.Transactions.TransactionScopeOption]::Required
    $scope = New-Object -TypeName System.Transactions.TransactionScope -ArgumentList @($options, $timeout)

    $ScriptNamesinPackageList = GetAllScriptsNameInPackage
    $ScriptNamesinDBList = GetScriptNamesInDB

    # Check if both lists are not empty
    if ($ScriptNamesinPackageList.Count -gt 0 -and $ScriptNamesinDBList.Count -gt 0) {
        # Compare ScriptNamesinPackageList with ScriptNamesinDBList
        $differences = Compare-Object -ReferenceObject $ScriptNamesinPackageList -DifferenceObject $ScriptNamesinDBList -IncludeEqual -ExcludeDifferent

        # Check if all names in Package are not present in Database List
        if ($differences.Count -eq 0) {
            Write-Host "None of the script names in the Package are found in the DB. The execution will proceed."
        }
        else {
            Write-Host "Some of the Script Names in Package match the ones in the ReleaseVersionDetails Table in DB.:"
            $differences | ForEach-Object {
                # Throw a custom exception with the script name
                throw [ScriptNameException]::new($_.InputObject + " is already present in DB", $_.InputObject)
            }
        }
    }
    else {
        # Handle the case when one or both lists are empty
        Write-Host "No SQL scripts exist in either the Package or the DB."
    }
}

catch [ScriptNameException] {
    # Write the custom exception message and script name to the console
    Write-Host $_.Exception.Message
    throw "Script name: " + $_.Exception.ScriptName + " is already present in DB"
}
catch {
    throw $_.exception.message
    exit 1
}
finally {
    $scope.Dispose()
    Write-Host "Scope Disposed!"
}