﻿param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='status')]
    [string]$ProjectName,

    [parameter(Mandatory=$true, position=2, ParameterSetName='status')]
    [string]$name,
    
    [parameter(Mandatory=$true, position=3, ParameterSetName='status')]
    [string]$type,
    
    [parameter(Mandatory=$true, position=4, ParameterSetName='status')]
    [int]$stage
)

$releaseDate = (get-date).ToString("yyyy-MM-dd")
Write-Host 'Release Date == ' $releaseDate

# Pipeline Name
$pipelineName = $name
Write-Host 'Pipeline Name == ' $pipelineName

$Query1 = "select Id from projects where Name = '$ProjectName'"
$Id = invoke-sqlcmd –ServerInstance 'lwdelbuild-001' -Database 'Dashboard_Prod' -Query $Query1 -QueryTimeout 65500
$projectId = $Id.Id
Write-Host 'Project ID == ' $projectId

# Check if a record with the same ProjectId and ReleaseDate exists
$Query2 = "SELECT COUNT(*) as Count FROM BuildReleaseStatus WHERE ProjectId = '$projectId' AND ReleaseDate = '$releaseDate'"
$count = invoke-sqlcmd –ServerInstance 'lwdelbuild-001' -Database 'Dashboard_Prod' -Query $Query2 -QueryTimeout 65500
Write-Host $count.Count

# For Build pipeline
if ($type -eq 'Build') {
    # Build status updated to 0
    if ($stage -eq 0) {
        if ($count.Count -gt 0) {
            # Update the existing record
            $Query3 = "UPDATE BuildReleaseStatus SET BuildStatus = 0 WHERE ProjectId = '$projectId' AND ReleaseDate = '$releaseDate'"
            invoke-sqlcmd –ServerInstance 'lwdelbuild-001' -Database 'Dashboard_Prod' -Query $Query3 -QueryTimeout 65500
            Write-Host $Query3
        } else {
            # Insert a new record
            $Query4 = "INSERT INTO BuildReleaseStatus (ProjectId, ReleaseDate, BuildPipelineName , BuildStatus, ReleaseStatus)
                VALUES ('$projectId', '$releaseDate', '$pipelineName',0,0)"
            invoke-sqlcmd –ServerInstance 'lwdelbuild-001' -Database 'Dashboard_Prod' -Query $Query4 -QueryTimeout 65500
            Write-Host $Query4
        }
    } else {
        # Build status updated to 1
        $Query5 = "UPDATE BuildReleaseStatus SET BuildStatus = 1 WHERE ProjectId = '$projectId' AND ReleaseDate = '$releaseDate'"
        invoke-sqlcmd –ServerInstance 'lwdelbuild-001' -Database 'Dashboard_Prod' -Query $Query5 -QueryTimeout 65500
        Write-Host $Query5
    }
} else {
    # For Release pipeline
    if ($stage -eq 0) {
        # Release status updated to 0
        $Query6 = "UPDATE BuildReleaseStatus SET ReleaseStatus = 0, ReleasePipelinename = '$pipelineName' WHERE ProjectId = '$projectId' AND ReleaseDate = '$releaseDate'"
        invoke-sqlcmd –ServerInstance 'lwdelbuild-001' -Database 'Dashboard_Prod' -Query $Query6 -QueryTimeout 65500
        Write-Host $Query6
    } else {
        # Release status updated to 1
        $Query7 = "UPDATE BuildReleaseStatus SET ReleaseStatus = 1 WHERE ProjectId = '$projectId' AND ReleaseDate = '$releaseDate'"
        invoke-sqlcmd –ServerInstance 'lwdelbuild-001' -Database 'Dashboard_Prod' -Query $Query7 -QueryTimeout 65500
        Write-Host $Query7
    }
}
