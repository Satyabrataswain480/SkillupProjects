﻿#----------------------------
#  Script for Db backup
#----------------------------

param(
$dbname,
$DbServer,
$backupPath
)

$dateTime=get-date -Format _dd_MM_yyyy_HH_mm_ss
$backUpFileName=$dbname+$dateTime


Write-Host "Backup Path :" $backupPath -ForegroundColor Green
Write-Host "Backup File Name : "$backUpFileName".bak" -ForegroundColor Green

function global:DBBackup {

$query="USE master
BACKUP DATABASE [$dbname] TO  DISK = N'$backupPath\$backUpFileName.bak' WITH NOFORMAT, NOINIT,  NAME = N'$dbname Database Backup', SKIP, NOREWIND, NOUNLOAD,COMPRESSION,  STATS = 10
GO
"
Invoke-Sqlcmd -ServerInstance $DbServer -Database $dbname -Query $query -ConnectionTimeout 77777 -QueryTimeout 64444 -Verbose

}

DBBackup