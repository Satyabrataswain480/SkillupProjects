

Param (

[parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
[string]$SQLServer,
[parameter (Mandatory=$true, position=1, ParameterSetName='Database')]
[string]$DatabaseName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Database')]
[string]$FolderPath,
[parameter (Mandatory=$true, position=3, ParameterSetName='Database')]
[string]$Order

)

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$FolderPath = $FolderPath + "\" + $currentDate + "\"
$FolderPath = $FolderPath + 'Database\DBScripts'

##########  New folder structure  DDL\DML

if($Order -eq '4')
{

# Check if folder not available
if(!(Test-Path $FolderPath))
{
   return
}

  ##Validate Go Statement in SQL Scripts
    write-host "Starting to validate GO statement..."
    $SQLScriptPathDDL = $FolderPath + '\DDL\*.sql'
    write-host $SQLScriptPathDDL
    if(Test-Path $SQLScriptPathDDL)
    {
        $SQLFiles = Get-Item -Path $SQLScriptPathDDL
    }

   # for ($i=0; $i -lt $SQLFiles.Count; $i++) 
   # {
   #     $outfile = $SQLFiles[$i].FullName
   #     $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
   #     write-host 'Printing last line of file -' $outfile +" - " + $SQLFileContent
#
 #       if($SQLFileContent.contains('GO') -or $SQLFileContent.Contains('Go'))
  #      {
   #       write-host "Please add GO statement at the end of file.No blank row at the bottom - " + $outfile
   #       exit -1
   #     }
   # }

#DDL Execution
$DDLPath =  $FolderPath + '\DDL\'

    # Check if folder not available
    if((Test-Path $DDLPath))
    {
        if( (Get-ChildItem $DDLPath  |Measure-Object).Count -eq 0)
        {
                write-host "No DDL Files Found"
        }
        else
        {
            foreach ($filename in get-childitem -path $DDLPath -filter "*.sql")
            {
                try
                {
                    Write-Host 'Started Executing DDL SQL Scripts'
					write-host $filename.fullname
                    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -InputFile $filename.fullname -QueryTimeout 65500
                    
                    Write-Host 'Completed Executing DDL SQL Scripts'
                }
                catch
                {
                    Write-Host "Syntax Error: $_" -ForegroundColor Red
                   exit -1
                }       
            }
        }
    }
    else
    {
        write-host "No DDL Files Found"
    }

$DMLPath =   $FolderPath + '\DML\'

    ##Validate Go Statement in SQL Scripts
    write-host "Startging to validate GO statement..."
    $SQLScriptPathDML = $FolderPath + '\DML\*.sql'
    write-host $SQLScriptPathDML
   # if((Test-Path $SQLScriptPathDML))
   # {
        #$SQLFiles = Get-Item -Path $SQLScriptPathDML

       # for ($i=0; $i -lt $SQLFiles.Count; $i++) 
       # {
       #     $outfile = $SQLFiles[$i].FullName
       #    $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
       #     write-host 'Printing last line of file -' $outfile +" - " + $SQLFileContent

       #     if($SQLFileContent -ne 'GO' -or $SQLFileContent -ne 'Go')
       #     {
       #       write-host "Please add GO statement at the end of file.No blank row at the bottom - " + $outfile
       #       exit -1
       #     }
       # }
   # }
    
    if((Test-Path $DMLPath))
    {
        if( (Get-ChildItem $DMLPath  |Measure-Object).Count -eq 0)
        {
                write-host "No DML Files found"
        }
        else
        {
            foreach ($filename in get-childitem -path $DMLPath -filter "*.sql")
            {
                try
                {
                    Write-Host 'Started Executing DML SQL Scripts'
					write-host $filename.fullname
                    invoke-sqlcmd -ServerInstance $SQLServer -Database $DatabaseName -InputFile $filename.fullname -QueryTimeout 65500 
                    
                    Write-Host 'Completed Executing DML SQL Scripts'
                }
                catch 
                {
                    Write-Host "Syntax Error: $_" -ForegroundColor Red
                   exit -1
                }
       
             }
        }
    }
    else
    {
        write-host "No DML Files Found"
    }
}
