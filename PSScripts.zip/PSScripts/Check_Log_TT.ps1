﻿param(
    [parameter (Mandatory=$true, position=0, ParameterSetName='Build')]
    [string] $Path    
)

$targetWord = "--- Loader Error ---"


try {
    if (Test-Path $Path -PathType Leaf) {
        $fileContent = Get-Content $Path -Raw
        
        if ($fileContent -like "*$targetWord*") {
            Write-Host "Error: The word '$targetWord' was found in the file."
            Write-Host "File Content:"
            Write-Host $fileContent
            throw "Word '$targetWord' found in the file." # Throw an exception
        } else {
            Write-Host "No error: The word '$targetWord' was not found in the file."
        }
    } else {
        throw "File not found at $Path" # Throw an exception
    }
} catch {
    Write-Host "Error: $_"
    exit 1  # Exit with an error code
}
