﻿Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Destination,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$CustomDllsRequired

)

##  Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir = $Destination + $currentDate


##Lessorportal copy
if($CustomDllsRequired -eq '1')  #Lessorportal
{
    $LessorPortal = $RelDir + '\LessorPortal\bin'
    $WindowService = $RelDir + '\WindowsService' 
    $WebAPI = $RelDir + '\WebAPI\bin' 

     $dllFiles = @("ClosedXML.dll", "DocumentFormat.OpenXml.dll", "ExcelNumberFormat.dll", "SixLabors.Fonts.dll", "System.Buffers.dll",
                    "System.IO.Packaging.dll", "System.Memory.dll", "System.Net.Http.Formatting.dll", "XLParser.dll", "System.Numerics.Vectors.dll",
                    "BouncyCastle.Crypto.dll", "Renci.SshNet.dll", "PgpCore.dll", "PdfSharp.dll", "FastMember.Signed.dll", "Microsoft.AI.Agent.Intercept.dll", 
                    "Microsoft.AI.DependencyCollector.dll", "Microsoft.AI.DependencyCollector.pdb", "Microsoft.AI.PerfCounterCollector.dll", 
                    "Microsoft.AI.PerfCounterCollector.pdb", "Microsoft.AI.ServerTelemetryChannel.dll", "Microsoft.AI.ServerTelemetryChannel.pdb", "Microsoft.AI.Web.dll", 
                    "Microsoft.AI.Web.pdb", "Microsoft.AI.WindowsServer.dll", "Microsoft.AI.WindowsServer.pdb", "Microsoft.ApplicationInsights.dll", 
                    "Microsoft.ApplicationInsights.pdb", "Microsoft.AspNet.TelemetryCorrelation.dll")  
    
    write-host 'Starting copying custom binaries.'

    # Copy each DLL file from the source to the destination
    foreach ($file in $dllFiles) {
        $sourceFile = Join-Path $LessorPortal $file
        Copy-Item -Path $sourceFile -Destination $WindowService -Force
        Copy-Item -Path $sourceFile -Destination $WebAPI -Force
    }  

    write-host 'Completed copying custom binaries.'
}

if (($lastexitcode -lt 8) -or ($lastexitcode -eq 16))
  { $lastexitcode = 0 }
