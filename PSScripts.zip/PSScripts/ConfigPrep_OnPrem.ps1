﻿Param (
$configPath ,
$isClient, 
$ReleasePackagePath
)

if($isClient){
  $configPath = $configPath + '\Client'
}
else{
     $configPath = $configPath + '\Internal'

}

if(Test-path $ReleasePackagePath)
{    
    #Copy config folder to release package path
    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
    $RelDir = $ReleasePackagePath + $currentDate + '\Config'
    write-host $RelDir
    if(Test-Path($RelDir))
    {
        New-item -Path $RelDir -Force
    }
    write-host $configPath
    if(Test-path $configPath)
    {
        Copy-item -Path $configPath $RelDir -Recurse -Force
    } 
}