﻿##  This script will zip the folders using 7 Zip and paste it in a different folder. 
Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Package_Source_Path,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Package_Destination_Path,
[parameter (Mandatory=$false, position=2, ParameterSetName='Release')]
[string]$IsSlot,
[parameter (Mandatory=$false, position=3, ParameterSetName='Release')]
[string]$ProjCode

)

function ZipFolders([String] $SourcePath, [String] $DestPath){
    if (-not (test-path "$env:ProgramFiles\7-Zip\7z.exe")) {throw "$env:ProgramFiles\7-Zip\7z.exe needed"}
    [string]$7ZipExePath = "C:\Program Files\7-zip\7z.exe";
    [Array]$arguments = "a", "-tzip", "$DestPath", "$SourcePath";
    & $7ZipExePath $arguments;
}

## Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 

$RelDir = $Package_Source_Path + $currentDate

$DestDir = $Package_Destination_Path 

Write-Host "Source Directory" $RelDir

Write-Host "Destination Directory" $DestDir

$Include = "AppSettings.config", "ConnectionStrings.config", "Lw.WindowsServices.exe.config", "Web.config", "ApplicationInsights.config"

Get-ChildItem $RelDir -Include $Include -Recurse | Remove-Item -Recurse

if(Test-Path $DestDir)
{
   Get-ChildItem $DestDir -Recurse | Remove-Item -Force -Recurse 
} 
else
{
   New-Item -Name 'ReleasePackage' -ItemType Directory -Path $Package_Destination_Path
}

$CustomerPortal = $RelDir + '\CustomerPortal\*'

if(Test-Path $CustomerPortal)
{
    #Compress-Archive -Path $CustomerPortal -DestinationPath $DestDir\CustomerPortal.zip
    
    if($IsSlot -eq 1)
    {
        New-Item -Name '\CustomerPortal' -ItemType Directory -Path $DestDir
        $NewCPDestDir = $DestDir + '\CustomerPortal'

        Write-Host $NewCPDestDir

        if(Test-Path $NewCPDestDir)
        {
           Write-Host 'Copying Customer Portal'
           Copy-Item  $CustomerPortal $NewCPDestDir -Force -Recurse
           Write-Host 'Copying Customer Portal Completed'     
        }

        #Compress-Archive -Path $LessorPortal -DestinationPath $DestDir\LessorPortal.zip
    
        ZipFolders $NewCPDestDir $DestDir\CustomerPortal.zip

        Start-Sleep -Seconds 60

        if(Test-Path $NewCPDestDir)
        {
            Remove-Item $NewCPDestDir -Recurse -Force
        }
    }
    else
    {
        ZipFolders $CustomerPortal $DestDir\CustomerPortal.zip
    }
}

$Config = $RelDir + '\Config\'

if(Test-Path $Config)
{
    Copy-item -Path $Config $DestDir -Recurse -Force    
} 

$Database = $RelDir + '\Database\*'

if(Test-Path $Database)
{
    #Compress-Archive -Path $Database -DestinationPath $DestDir\Database.zip
    ZipFolders $Database $DestDir\Database.zip
}

$DocPortal = $RelDir + '\DocPortal\*'

if(Test-Path $DocPortal)
{
    #Compress-Archive -Path $DocPortal -DestinationPath $DestDir\DocPortal.zip
    
    if($IsSlot -eq 1)
    {
        New-Item -Name '\DocPortal' -ItemType Directory -Path $DestDir
        $NewDPDestDir = $DestDir + '\DocPortal'

        Write-Host $NewDPDestDir

        if(Test-Path $NewDPDestDir)
        {
           Write-Host 'Copying DocPortal'
           Copy-Item  $DocPortal $NewDPDestDir -Force -Recurse
           Write-Host 'Copying DocPortal Completed'     
        }

        #Compress-Archive -Path $LessorPortal -DestinationPath $DestDir\LessorPortal.zip
    
        ZipFolders $NewDPDestDir $DestDir\DocPortal.zip

        Start-Sleep -Seconds 60

        if(Test-Path $NewDPDestDir)
        {
            Remove-Item $NewDPDestDir -Recurse -Force
        }
    }
    else
    {
        ZipFolders $DocPortal $DestDir\DocPortal.zip
    }
}

$LessorPortal = $RelDir + '\LessorPortal\*'

if(Test-Path $LessorPortal)
{
    if($IsSlot -eq 1)
    {
        New-Item -Name '\LessorPortal' -ItemType Directory -Path $DestDir
        $NewLPDestDir = $DestDir + '\LessorPortal'

        Write-Host $NewLPDestDir

        if(Test-Path $NewLPDestDir)
        {
           Write-Host 'Copying Lessor Portal'
           Copy-Item  $LessorPortal $NewLPDestDir -Force -Recurse
           Write-Host 'Copying Lessor Portal Completed'     
        }

        #Compress-Archive -Path $LessorPortal -DestinationPath $DestDir\LessorPortal.zip
    
        ZipFolders $NewLPDestDir $DestDir\LessorPortal.zip

        Start-Sleep -Seconds 60

        if(Test-Path $NewLPDestDir)
        {
            Remove-Item $NewLPDestDir -Recurse -Force
        }
    }
    else
    {
        ZipFolders $LessorPortal $DestDir\LessorPortal.zip
    }
}

$License = $RelDir + '\License\*'

if(Test-Path $License)
{
    #Compress-Archive -Path $License -DestinationPath $DestDir\License.zip
    ZipFolders $License $DestDir\License.zip
}

$MigrationTool = $RelDir + '\MigrationTool\*'

if(Test-Path $MigrationTool)
{
    #Compress-Archive -Path $MigrationTool -DestinationPath $DestDir\MigrationTool.zip
    ZipFolders $MigrationTool $DestDir\MigrationTool.zip
}

$PricingService = $RelDir + '\PricingService\*'

if(Test-Path $PricingService)
{
    #Compress-Archive -Path $PricingService -DestinationPath $DestDir\PricingService.zip
    ZipFolders $PricingService $DestDir\PricingService.zip
}

$Reports = $RelDir + '\Reports\*'

if(Test-Path $Reports)
{
    #Compress-Archive -Path $Reports -DestinationPath $DestDir\Reports.zip
    ZipFolders $Reports $DestDir\Reports.zip
}

$SqlServices = $RelDir + '\SqlServices\*'

if(Test-Path $SqlServices)
{
    #Compress-Archive -Path $SqlServices -DestinationPath $DestDir\SqlServices.zip
    ZipFolders $SqlServices $DestDir\SqlServices.zip
}

$TValueBinaries = $RelDir + '\TValueBinaries\*'

if(Test-Path $TValueBinaries)
{
    #Compress-Archive -Path $TValueBinaries -DestinationPath $DestDir\TValueBinaries.zip
    ZipFolders $TValueBinaries $DestDir\TValueBinaries.zip
}

$UserManual = $RelDir + '\UserManual\*'

if(Test-Path $UserManual)
{
    #Compress-Archive -Path $UserManual -DestinationPath $DestDir\UserManual.zip
    ZipFolders $UserManual $DestDir\UserManual.zip
}

$VendorPortal = $RelDir + '\VendorPortal\*'

if(Test-Path $VendorPortal)
{
    #Compress-Archive -Path $VendorPortal -DestinationPath $DestDir\VendorPortal.zip
    ZipFolders $VendorPortal $DestDir\VendorPortal.zip
}

$WebAPI = $RelDir + '\WebAPI\*'

if(Test-Path $WebAPI)
{
    #Compress-Archive -Path $WebAPI -DestinationPath $DestDir\WebAPI.zip
    if($IsSlot -eq 1)
    {
        New-Item -Name '\WebAPI' -ItemType Directory -Path $DestDir
        $NewWADestDir = $DestDir + '\WebAPI'

        Write-Host $NewWADestDir

        if(Test-Path $NewWADestDir)
        {
           Write-Host 'Copying Web API'
           Copy-Item  $WebAPI $NewWADestDir -Force -Recurse
           Write-Host 'Copying Web API Completed'     
        }

        #Compress-Archive -Path $LessorPortal -DestinationPath $DestDir\LessorPortal.zip
    
        ZipFolders $NewWADestDir $DestDir\WebAPI.zip

        Start-Sleep -Seconds 60

        if(Test-Path $NewWADestDir)
        {
            Remove-Item $NewWADestDir -Recurse -Force
        }
    }
    else
    {
        ZipFolders $WebAPI $DestDir\WebAPI.zip
    }    
}

$WebServices = $RelDir + '\WebServices\*'

if(Test-Path $WebServices)
{
    if($IsSlot -eq 1)
    {
        New-Item -Name '\WebServices' -ItemType Directory -Path $DestDir
        $NewWSDestDir = $DestDir + '\WebServices'

        Write-Host $NewWSDestDir

        if(Test-Path $NewWSDestDir)
        {
           Write-Host 'Copying Web Services'
           Copy-Item  $WebServices $NewWSDestDir -Force -Recurse
           Write-Host 'Copying Web Services'     
        }

        #Compress-Archive -Path $LessorPortal -DestinationPath $DestDir\LessorPortal.zip
    
        ZipFolders $NewWSDestDir $DestDir\WebServices.zip

        Start-Sleep -Seconds 60

        if(Test-Path $NewWSDestDir)
        {
            Remove-Item $NewWSDestDir -Recurse -Force
        }
    }
    else
    {
        ZipFolders $WebServices $DestDir\WebServices.zip
    }    
}


$WindowsService = $RelDir + '\WindowsService\*'

if(Test-Path $WindowsService)
{
    #Compress-Archive -Path $WindowsService -DestinationPath $DestDir\App_Data\Jobs\Continuous\WindowsServices.zip

    New-Item -Name '\App_Data\Jobs\Continuous\WindowsServices' -ItemType Directory -Path $DestDir

    $NewDestDir = $DestDir + '\App_Data\Jobs\Continuous\WindowsServices'

    Write-Host $NewDestDir

    if(Test-Path $NewDestDir)
    {
       Write-Host 'Copying windows Services'
       Copy-Item  $WindowsService $NewDestDir -Force -Recurse
       Write-Host 'Copying windows Services Completed'     
       Get-ChildItem $NewDestDir -Filter *.bat -Recurse  | Remove-Item -Recurse  

       #Crete Temp Folder for copying Domain dll
       $DomainTempDestDir = $NewDestDir + '\DomainAssemblies'
       New-Item -Name 'temp' -ItemType Directory -Path $DomainTempDestDir
       $SourceTempPath = $RelDir + '\WindowsService\DomainAssemblies\*'
       $ActualTempPath = $DomainTempDestDir + '\temp'
       
       Write-Host 'Source Temp Path:' $SourceTempPath
       Write-Host 'Actual Temp Path:' $ActualTempPath
       if(Test-Path $ActualTempPath)
       {
            Copy-Item  $SourceTempPath $ActualTempPath -Force -Recurse
       }
    }    

    $FinalWindowsServices = $DestDir + '\App_Data'
    ZipFolders $FinalWindowsServices $DestDir\WindowsServices.zip

    Start-Sleep -Seconds 60    

    if(Test-Path $FinalWindowsServices)
    {
        Remove-Item $FinalWindowsServices -Recurse -Force
    }

    if($ProjCode -eq 'EMM')
    {
        New-Item -Name '\App_Data\Jobs\Continuous\WindowsServicesConfig' -ItemType Directory -Path $DestDir

        $NewDestDir = $DestDir + '\App_Data\Jobs\Continuous\WindowsServicesConfig'

        Write-Host $NewDestDir

        if(Test-Path $NewDestDir)
        {
           Write-Host 'Copying Config windows Services'
           Copy-Item  $WindowsService $NewDestDir -Force -Recurse
           Write-Host 'Copying Config windows Services Completed'     
           Get-ChildItem $NewDestDir -Filter *.bat -Recurse  | Remove-Item -Recurse  

           #Crete Temp Folder for copying Domain dll
           $DomainTempDestDir = $NewDestDir + '\DomainAssemblies'
           New-Item -Name 'temp' -ItemType Directory -Path $DomainTempDestDir
           $SourceTempPath = $RelDir + '\WindowsService\DomainAssemblies\*'
           $ActualTempPath = $DomainTempDestDir + '\temp'
       
           Write-Host 'Source Temp Path:' $SourceTempPath
           Write-Host 'Actual Temp Path:' $ActualTempPath
           if(Test-Path $ActualTempPath)
           {
                Copy-Item  $SourceTempPath $ActualTempPath -Force -Recurse
           }
        }    

        $FinalWindowsServices = $DestDir + '\App_Data'
        ZipFolders $FinalWindowsServices $DestDir\WindowsServicesConfig.zip

        Start-Sleep -Seconds 60    

        if(Test-Path $FinalWindowsServices)
        {
            Remove-Item $FinalWindowsServices -Recurse -Force
        }
    }


    if($ProjCode -eq 'CFL')
    {
        New-Item -Name '\App_Data\Jobs\Continuous\WindowsServices_Customerportal' -ItemType Directory -Path $DestDir

        $NewDestDir = $DestDir + '\App_Data\Jobs\Continuous\WindowsServices_Customerportal'

        Write-Host $NewDestDir

        if(Test-Path $NewDestDir)
        {
            Write-Host 'Copying Config windows Services'
            Copy-Item  $WindowsService $NewDestDir -Force -Recurse
            Write-Host 'Copying Config windows Services Completed'     
            Get-ChildItem $NewDestDir -Filter *.bat -Recurse  | Remove-Item -Recurse  

            #Crete Temp Folder for copying Domain dll
            $DomainTempDestDir = $NewDestDir + '\DomainAssemblies'
            New-Item -Name 'temp' -ItemType Directory -Path $DomainTempDestDir
            $SourceTempPath = $RelDir + '\WindowsService\DomainAssemblies\*'
            $ActualTempPath = $DomainTempDestDir + '\temp'
       
            Write-Host 'Source Temp Path:' $SourceTempPath
            Write-Host 'Actual Temp Path:' $ActualTempPath
            if(Test-Path $ActualTempPath)
            {
                Copy-Item  $SourceTempPath $ActualTempPath -Force -Recurse
            }
        }    

        $FinalWindowsServices = $DestDir + '\App_Data'
        ZipFolders $FinalWindowsServices $DestDir\WindowsServices_Customerportal.zip

        Start-Sleep -Seconds 60    

        if(Test-Path $FinalWindowsServices)
        {
            Remove-Item $FinalWindowsServices -Recurse -Force
        }
    }
}