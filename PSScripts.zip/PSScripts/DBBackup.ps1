﻿param(
$DB_Backup_Path,
$DBName,
$SQLInstance,
$dbServer = $null,
$psConfig = 'Devops'
)

write-host 'DB backup deleted started.'
Invoke-Command -ComputerName $dbServer -ScriptBlock{
    function deleteOldBackups{
        param([string]$DB_Backup_Path)
        if ( Test-Path -Path $DB_Backup_Path -PathType Container )
        {
            $DaysToKeep = "-2"
            $CurrentDate = Get-Date
            $DatetoDelete = $CurrentDate.AddDays($DaysToKeep)
            Get-ChildItem $DB_Backup_Path -Filter *.bak -Recurse  | Where-Object { $_.LastWriteTime -lt $DatetoDelete } | Remove-Item -Recurse
        }
        else
        {
            New-Item $DB_Backup_Path -ItemType Directory
        }
    }
    deleteOldBackups $using:DB_Backup_Path
    write-host 'DB backup deleted completed.'
} -ConfigurationName $psConfig


$timeStamp = Get-Date -format yyyy_MM_dd_HHmmss 

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null 

$srv = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $SQLInstance
 
$dbs = New-Object Microsoft.SqlServer.Management.Smo.Database 
$dbs = $srv.Databases 

foreach ($Database in $dbs) 
{ 
 $Database.name 

 if($Database.name -eq $DBName)
 {

   $bk = New-Object ("Microsoft.SqlServer.Management.Smo.Backup") 
   $bk.Action = [Microsoft.SqlServer.Management.Smo.BackupActionType]::Database 
   $bk.BackupSetName = $Database.Name + "_backup_" + $timeStamp 
   $bk.Database = $Database.Name 
   $bk.CompressionOption = 1 
   $bk.MediaDescription = "Disk" 
   $bk.Devices.AddDevice($DB_Backup_Path + "\" + $Database.Name + "_" + $timeStamp + ".bak", "File") 
   $bk.SqlBackup($srv)
   return
 }
} 