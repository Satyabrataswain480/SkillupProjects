﻿#Import-Module SQLPS -DisableNameChecking
#  'lwdeldb-002' 'Banorte_Test' '\\lwdeldb-002\Backup\DB\' 'Lwdelbuild-001' 'BNT_Gated' '\\LWDelbuild-001\DB\' 
Param(
$SQLInstance,
$DBName,
$DBBackup,
$RestoreServer,
$GatedDBName,
$BackupPath
)


#$timeStamp = Get-Date -format yyyy_MM_dd_HHmmss 

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null 
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended") | Out-Null 

$srv = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $SQLInstance 
$dbs = New-Object Microsoft.SqlServer.Management.Smo.Database 
$dbs = $srv.Databases 

#Added method to add slash [\] at the end if missing
if(-not ($DBBackup.EndsWith('\') -or $DBBackup.EndsWith('/')))
{
    if($DBBackup.Contains('\'))
    {
        $DBBackup = $DBBackup + '\'
    }
    if($DBBackup.Contains('/'))
    {
        $DBBackup = $DBBackup + '/'
    }
}

if(-not ($BackupPath.EndsWith('\') -or $BackupPath.EndsWith('/')))
{
    if($BackupPath.Contains('\'))
    {
        $BackupPath = $BackupPath + '\'
    }
    if($BackupPath.Contains('/'))
    {
        $BackupPath = $BackupPath + '/'
    }
}

$DBbackupPath = $DBBackup + $DBName + ".bak"
write-host $DBbackupPath

Write-host '************  DB Backup Started  **************'

Backup-SqlDatabase -ServerInstance $SQLInstance -Database $DBName -BackupFile $DBbackupPath

sleep -Seconds 10

Write-host '************  DB Backup Completed  **************'

Write-host '************  Copy Backup Started  **************'

Copy-Item -Path $DBbackupPath -Destination $BackupPath -Force 

Write-host '************  Copy Backup Completed  **************'

sleep -Seconds 20

$RestorePath = $BackupPath + $DBName + ".bak"
Write-Host  $RestorePath

Write-host '************  Taking DB Offline  **************'

# Get the database object
$database = $srv.Databases[$GatedDBName]

# Set the database offline with ROLLBACK IMMEDIATE option to force termination of all active connections
$offline = "ALTER DATABASE [$GatedDBName] SET OFFLINE WITH ROLLBACK IMMEDIATE;"

# Execute the ALTER statement
$database.ExecuteNonQuery($offline)
Write-host '************  Taking DB Offline completed  **************'

Write-host '************  DB Restore Started  **************'

Restore-SqlDatabase -ServerInstance $RestoreServer -Database $GatedDBName -BackupFile $RestorePath -ReplaceDatabase

Write-host '************  DB Restore Completed  **************'

sleep -Seconds 20

## Deleting backups

Remove-Item -Path $DBbackupPath -Force
Remove-Item -Path $RestorePath -Force

