﻿Param (
    [string]$buildPath,
    [string]$sqlServer,
    [string]$dbName
)


$configFilePath = $buildPath+"_PublishedWebsites\Lw.LessorPortal.Project\connectionstrings.config"

# Load the XML document
[xml]$xmlDoc = Get-Content -Path $configFilePath

# Find the <add> element with name="LeasewaveRepository"
$leasewaveRepositoryNode = $xmlDoc.connectionStrings.add | Where-Object { $_.name -eq "LeasewaveRepository" }

if ($leasewaveRepositoryNode) {
    # Update the attributes
    $leasewaveRepositoryNode.connectionString = "data source=$sqlServer;Initial Catalog=$dbName;Integrated Security=SSPI;MultipleActiveResultSets=True"
    $leasewaveRepositoryNode.providerName = "System.Data.SqlClient"

    # Save the updated XML back to the file
    $xmlDoc.Save($configFilePath)
    Write-Host "The LeasewaveRepository connection string has been updated successfully."
} else {
    Write-Host "The LeasewaveRepository connection string was not found."
}
