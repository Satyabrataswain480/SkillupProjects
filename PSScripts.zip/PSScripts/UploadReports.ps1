param(
    $packagePath,
    $url,
    $reportSharedPath,
	#$reportBinPath,
	$reportFolder
)


$url =  [System.Uri]$url
$Report_Server = $url.Host
$Report_ServerPort = $url.Port

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$packagePath = $packagePath + "\" + $currentDate + "\"
$ReportPath = $packagePath +'Reports'
$RDLPath = $ReportPath + '\RDLs'
if(Test-Path $RDLPath)
{
    if((Get-ChildItem $RDLPath -force | Select-Object -First 1 | Measure-Object).Count -gt 0)
    {    
        if(Test-Path $ReportPath)
        {
            Write-Host 'Starting uploading reports..'

            $path1 = $packagePath +'Reports\ReportHelper\*.dll'
            if(!(Test-Path $path1))
            {
                $packagePath
                write-host 'Skipping DLL replacement process, as no content found.'
            }
            else
            {
                Copy-Item -path $path1 -destination $reportSharedPath -Force -Recurse
            }

            $p = $reportSharedPath + '\*'
            $sb = {
                    param ($path, $binpath)
                    Copy-Item -path $path -destination $binpath -Force -Recurse -ErrorAction Ignore
                }


            ## restart SQLServerReportingService

            $Service = Get-WmiObject -ComputerName $Report_Server -Class Win32_Service -Filter "Name='SQLServerReportingServices'"
            $Service.stopservice()

            Start-Sleep 30

            $Service = Get-WmiObject -ComputerName $Report_Server -Class Win32_Service -Filter "Name='SQLServerReportingServices'"
            $Service.startservice()

            Start-Sleep 90

            #Invoke-Command -computername $Report_Server -scriptBlock $sb -ArgumentList $p,$reportBinPath

            $path2 = $packagePath+'Reports\RDLs'

            if(!(test-path $path2))
            {
                write-host 'Skipping RDL replacement process, as no content found.'
                return;
            }

            $report_serverwithport = $Report_Server + ':' + $Report_ServerPort

            #$reportServerUri = "http://{0}/Reports" -f $report_serverwithport

            $reportServerUri = "http://{0}/reportserver/ReportService2010.asmx?wsdl" -f $report_serverwithport

            $Service_Status = Get-Service -Name 'SQLServerReportingServices' -ComputerName $Report_Server
            if($Service_Status.status -eq "Running")  
            {
                $proxy = New-RsWebServiceProxy -ReportServerUri $reportServerUri
                Write-RsFolderContent -ReportServerUri $reportServerUri -Proxy $proxy -Path $path2 -Destination $reportFolder -OverWrite -Verbose
                Write-Host 'Report upload completed.'
            }
            else{
            write-host 'Service,SQLServerReportingServices is not Running ..'
            }
        }
        else
        {
        write-host 'Report folder not found..'
        }
    }
    else
    {
        Write-Host "No RDL files found..."
    }
}