﻿function GetSqlInstance{
Param(
 $ServerName
)

$Username = 'ODESSAPDC01\Devops.Admin'
$Password = ConvertTo-SecureString -AsPlainText 'Password@123' -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Username,$Password 

  $LocalInstances = @()
  [array]$Captions = Get-WmiObject win32_service -Credential $Credential -ComputerName $ServerName |
    where {
      $_.Name -match "mssql*" -and 
      $_.PathName -match "sqlservr.exe"
    } | foreach {$_.Caption}

  foreach ($Caption in $Captions) {
    if ($Caption -eq "MSSQLSERVER") {
      $LocalInstances += "MSSQLSERVER"
    } else {
      $Temp = $Caption |
        foreach {$_.split(" ")[-1]} |
          foreach {$_.trimStart("(")} |
            foreach {$_.trimEnd(")")}
      if($Temp -eq "MSSQLSERVER"){ $LocalInstances += "$ServerName" }
      else { $LocalInstances += "$ServerName\$Temp" }
    }
  }

  return $localInstances

}

function InsertDetails{
Param(
 $server,
 $User,
 $Password
)
    
   try{
    
    $queryMain = @"
with cte as (
SELECT 
	d.database_id,
  '$server' AS ServerName,
  db_name(d.database_id) AS DatabaseName,
  CAST(SUM(mf.size * 8 / 1024 / 1024) AS DECIMAL(10, 2)) AS DatabaseSizeGB
FROM sys.databases d
JOIN sys.master_files mf ON d.database_id = mf.database_id
WHERE 
  d.database_id > 4 
  AND d.state_desc = 'ONLINE'
GROUP BY d.database_id, d.name)

select cte.ServerName, cte.DatabaseName, cte.DatabaseSizeGB,
MAX(CAST( 
    COALESCE(
      CASE 
        WHEN last_user_scan > last_user_seek AND last_user_scan > last_user_update THEN last_user_scan
        WHEN last_user_seek > last_user_update THEN last_user_seek
        ELSE last_user_update
      END, '1900-01-01' 
    ) AS date)) AS LastUsed
from cte 
join sys.dm_db_index_usage_stats ius on ius.database_id = cte.database_id
where cte.DatabaseSizeGB > 0
GROUP BY cte.database_id, cte.DatabaseName, cte.ServerName, cte.DatabaseSizeGB
HAVING MAX(CAST( 
    COALESCE(
      CASE 
        WHEN last_user_scan > last_user_seek AND last_user_scan > last_user_update THEN last_user_scan
        WHEN last_user_seek > last_user_update THEN last_user_seek
        ELSE last_user_update
      END, '1900-01-01' 
    ) AS date)) <= DATEADD(month, -3, GETDATE()) 
  OR MAX(CAST( 
      CASE 
        WHEN last_user_scan > last_user_seek AND last_user_scan > last_user_update THEN last_user_scan
        WHEN last_user_seek > last_user_update THEN last_user_seek
        ELSE last_user_update
      END
     AS date)) IS NULL
;
"@
        $result = Invoke-Sqlcmd -Query $queryMain -Database master -ServerInstance $server -Username $User -Password $Password
        $result
        foreach($res in $result){
            $query = "Insert into UnusedDatabaseDistribution (LogDate, DbInstance, DbName, DbSize, LastUsed)
                    values(GETDATE(), '$($res.ServerName)', '$($res.DatabaseName)', '$($res.DatabaseSizeGB)', '$($res.LastUsed)')"
            $query
            Invoke-Sqlcmd -Query $query -Database Dashboard_Prod -ServerInstance LWDELBUILD-001 -Username DashboardDBUser -Password Samsung@1234

        }
    
    }
    catch{

      Write-Output $_
    
    }finally{
    
    }

    
}



$servers = @('LWDELDB-001', 'LWDELDB-002','LWDELDB-003', 'LWDELDB-004','LWDELDB-005')

$query = "delete from UnusedDatabaseDistribution"
Invoke-Sqlcmd -Query $query -Database Dashboard_Prod -ServerInstance LWDELBUILD-001 -Username DashboardDBUser -Password Samsung@1234

foreach($server in $servers){
    $instances = GetSqlInstance $server

    Write-Host "------------------------------"
    Write-Host "Starting with $($server)"
    
    foreach($instance in $instances){
        Write-Host "Instance Name: $($instance)"
        InsertDetails $instance 'DashboardDBUser' 'Samsung@1234'
    }

    Write-Host "------------Completed----------------"
}


