﻿##  This script will create Release contant
Param  (
[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Build_Path,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Release_Path,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$Artifact_Build_Path,
[parameter (Mandatory=$false, position=3, ParameterSetName='Release')]
[string]$PackageReference
) 

##  Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir = $Release_Path + $currentDate

if($PackageReference -eq '1')
{    
  $packagePath = 'C:\Users\devops.admin\.nuget\packages'
  write-host 'Package Reference Path: ' $packagePath

}
else
{
  $packagePath = $Build_Path + '\Packages'
}

if($PackageReference -eq '1')
{
    #Get the Current Fx version configured for LeaseWave solution
    $BuildProjData = [xml]( Get-Content  "$Build_Path\Build.proj"); 
    $FrameworkVersion = $BuildProjData.Project.ChildNodes.Item(0).FrameworkVersion
    $FRWKFolders = $packagePath + '\odessa.framework\' + $FrameworkVersion
    $FRWKABSPath = $FRWKFolders
    write-host 'FRWK Path: ' $FRWKABSPath
}
else
{
    $FRWKFolders = Get-childitem -Path $packagePath -Filter 'lw.Framework*'
    $FRWKABSPath = $null
}

if($PackageReference -eq '0')
{
    if($FRWKFolders.count -gt 1)
    {
      write-host 'Multiple framework folders found. keep only latest one'
      throw
    }
    else
    {
      $FRWKABSPath = $FRWKFolders.FullName
      write-host $FRWKABSPath
    }
}

if(!(Test-path -Path $RelDir))
{
   New-Item -Name $currentDate -ItemType Directory -Path $Release_Path
} 
else
{
  Remove-Item -Path $RelDir -Recurse -Force
  New-Item -Name $currentDate -ItemType Directory -Path $Release_Path
}

##  Creating Root FOlder
New-Item -Name 'CustomerPortal'  -ItemType Directory -Path $RelDir
New-Item -Name 'Database'  -ItemType Directory -Path $RelDir
New-Item -Name 'Reports'  -ItemType Directory -Path $RelDir
New-Item -Name 'WindowsService'  -ItemType Directory -Path $RelDir
New-Item -Name 'ReleaseNotes'  -ItemType Directory -Path $RelDir

### Creating Sub FOlders
$LP = $RelDir + '\CustomerPortal'
New-Item -Name 'App_Data'  -ItemType Directory -Path $LP

### Creating Sub FOlders
$DBScripts = $RelDir + '\Database'
New-Item -Name 'DBScripts\DDL'  -ItemType Directory -Path $DBScripts
New-Item -Name 'DBScripts\DML'  -ItemType Directory -Path $DBScripts
   
$Reports = $RelDir + '\Reports'
New-Item -Name 'RDLs'  -ItemType Directory -Path  $Reports
New-Item -Name 'ReportHelper'  -ItemType Directory -Path  $Reports


### Fill FRWK folders
write-host 'Preparing WindowsService...'
$SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\'

write-host 'WindowsService Source path: ' $SourceWindowService
$DestWindowService = $RelDir + '\WindowsService\'

robocopy $SourceWindowService $DestWindowService /E

##Copy Lw.Domain dll's
$Window0 = $Artifact_Build_Path + '\Lw.Domain.Extension.dll'
$Window1 = $Artifact_Build_Path + '\Lw.Domain.Project.Extension.dll'
$Window2 = $Artifact_Build_Path + '\Lw.Domain.Project.Resource.dll'
$Window3 = $Artifact_Build_Path + '\Lw.Domain.Resource.dll'


if(!([string]::IsNullOrEmpty($Window0)) -and (Test-path $Window0)){
    Copy-Item $Window0 $DestWindowService
}
if(!([string]::IsNullOrEmpty($Window1)) -and (Test-path $Window1)){
    Copy-Item $Window1 $DestWindowService
}
if(!([string]::IsNullOrEmpty($Window2)) -and (Test-path $Window2)){
    Copy-Item $Window2 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window3)) -and (Test-path $Window3)){
    Copy-Item $Window3 $DestWindowService 
}

##Copy Tavalue to WindowService bin folder

$SourceTValue1 = $Artifact_Build_Path + '\TValue6.dll'
$SourceTvalue2 = $Artifact_Build_Path + '\Tvalue6Engine2.dll'

if(!([string]::IsNullOrEmpty($SourceTValue1)) -and (Test-path $SourceTValue1)){
    copy-item $SourceTValue1 $DestWindowService
}
if(!([string]::IsNullOrEmpty($SourceTValue2)) -and (Test-path $SourceTValue2)){
    copy-item $SourceTValue2 $DestWindowService
}

write-host 'Completed WindowsService...'

if ($lastexitcode -lt 8) { $lastexitcode = 0 }

