param(
    $iisConfigPath,
    $configLocation,
    $sitePath,
    $siteName,
    $iisExpressPath,
    $outputPath,
    $dll,
    $projectName,
    $otConfigPath,
    $psTemplatePath,
    $otCollectionName
)

$path = $iisConfigPath
$targetName = $siteName
$outputPath = "$outputPath\$projectName\OT_Report"

[xml]$xml = Get-Content -Path $path
$targetNode = Select-Xml -Xml $xml -XPath "//site[@name='$targetName']"

function ChangeToLocalPath{
    param($path)
    $url = [System.Uri]::new($path)
    $p = $url.AbsolutePath.Remove(0,1).Replace("/","\").Replace("$",":")
    return $p
}

$sitePath = ChangeToLocalPath $sitePath

Write-Host "==============================================================================="
Write-Host "IIS Express configuration Started."
$targetNode
if($targetNode -ne $null){ 
    Write-Host "Site already configured."
    Write-Host "==============================================================================="
    return
}

$nodes = $xml.configuration.'system.applicationHost'.sites.ChildNodes
$maxId = 1
$maxport = 1

foreach ($node in $nodes) {
    [int]$id = $node.attributes['id'].value
        if($id -ne $null -and $id -gt $maxId) {
            $maxId = $id
            $ports = $node.bindings.binding.attributes['bindingInformation'].value
            foreach ($port in $ports)
            {
                [int]$portnumber = $port -replace "[^0-9]", ""
                if($portnumber -gt $maxport){
                    $maxport = $portnumber
                }

            }
        }
}

$xpathValue = "//site[@id='$maxid']"
$targetNode = Select-Xml -Xml $xml -XPath $xpathValue

$maxId++
$maxport++

$bindingInformation = "*:" + [string]$maxport + ":localhost"

$newNode = [xml]@"
<site name="$targetName" id="$maxId" serverAutoStart="true">
                <application path="/" applicationPool="Clr4IntegratedAppPool">
                    <virtualDirectory path="/" physicalPath="$sitePath" />
                </application>
                <bindings>
                    <binding protocol="http" bindingInformation="$bindingInformation" />
                </bindings>
            </site>	
"@

$newNode = $xml.ImportNode($newNode.site,$true)
$xml.configuration.'system.applicationHost'.sites.InsertAfter($newNode,$targetNode.Node) |out-null

$xml.Save($path)
Start-Sleep -Seconds 10

Write-Host "IIS express configured for site $targetName with portnumber: $maxport Id: $maxId"

[xml]$otxml = Get-Content -Path $otConfigPath

#$xpath = "//add[@"+ $SearchKey + "='$SearchValue']"
#$xpath
$TargetValue = "http://localhost:$maxport"
$TargetValue
$nodes = $otxml.SelectNodes("//add[@key='DeploymentUrl']")

if($nodes -ne $null){
    foreach($node in $nodes) {
        $node.SetAttribute("value", $TargetValue);
    }

    $otxml.Save($otConfigPath)
}

Write-Host "IIS Express configuration Completed."
Write-Host "==============================================================================="
Write-Host ""

Write-Host "==============================================================================="
Write-Host "Dotcover config genearation started."

$otconfigName = 'OT_Config.xml'
$otReportconfigName = 'OT_Report.xml'
$dcvrFileName = $projectName+"_OT_CoverageReport.dcvr"
$htmlFileName = $projectName+"_OT_CoverageReport.html"
$path1 = ChangeToLocalPath $path

$newNode = @"
<?xml version="1.0" encoding="utf-8"?>
<CoverageParams>
  <TargetExecutable>$iisExpressPath</TargetExecutable>
  <TargetArguments>/site:$targetName /systray:true /config:$path1</TargetArguments>
<CoverImmediately>True</CoverImmediately>
<Instance>15</Instance>
   <Output>$outputPath\$dcvrFileName</Output>
   <Filters>
    <IncludeFilters>
      <FilterEntry>
	   <ModuleMask>$dll</ModuleMask>
       </FilterEntry>
    </IncludeFilters>
  </Filters>
</CoverageParams>
"@

$file = Get-Item -Path "$configLocation\$otconfigName" -ErrorAction Ignore
if($file -eq $null){
    New-Item "$configLocation\$otconfigName" -ItemType File
    Set-Content "$configLocation\$otconfigName" $newNode
    Write-Host ""
    Write-Host "$otconfigName Generated..."
}else {
    Write-Host "$otconfigName already exists..."
}

$newNode = @"
<?xml version="1.0" encoding="utf-8"?>
<ReportParams>
  <Source>$outputPath\$dcvrFileName</Source>
  <Output>$outputPath\$htmlFileName</Output>
  <ReportType>html</ReportType>
</ReportParams>
"@

$file = Get-Item -Path "$configLocation\$otReportconfigName" -ErrorAction Ignore
if($file -eq $null){
    New-Item "$configLocation\$otReportconfigName" -ItemType File
    Set-Content "$configLocation\$otReportconfigName" $newNode
    Write-Host ""
    Write-Host "$otReportconfigName Generated..."
}else {
    Write-Host "$otReportconfigName already exists..."
}


Write-Host "Dotcover config genearation Completed."
Write-Host "==============================================================================="
Write-Host ""

$pspath = "$psTemplatePath\$projectName\Script\CodeCoverageTemplate.ps1"

$content = Get-Content -path $pspath
$localPath = ChangeToLocalPath $psTemplatePath
$configLocation = ChangeToLocalPath $configLocation
$iisConfigPath = ChangeToLocalPath $iisConfigPath

$content =$content -replace "##PROJECT##", "'$projectName'"
$content =$content -replace "##PORT##", "'$maxport'"
$content =$content -replace "##COLLECTIONNAME##", "'$otCollectionName'"
$content =$content -replace "##INSTANCEID##", "'$maxId'"
$content =$content -replace "##iisExpressConfigRoot##", "'$configLocation\$otconfigName'"
$content =$content -replace "##reportConfig_OT##", "'$configLocation\$otReportconfigName'"
$content =$content -replace "##OTWorkspace##", "'$localPath\$projectName\OT'"
$content =$content -replace "##OTEXE##", "'$localPath\$projectName\OT\Binaries\Odessa.exe'"
$content =$content -replace "##projectPath##", "'$iisConfigPath\$projectName\Site'"

Set-Content -Path $pspath -Value $content

#$pspath = ChangeToLocalPath $pspath
#$name = $projectName+"_DotCover"
#$arg= "-File $pspath"
#$task = Get-ScheduledTaskInfo -TaskName $name -ErrorAction Ignore

#if($task){
#      Unregister-ScheduledTask -TaskName $name -Confirm:$false
#}

#  $taskAction = New-ScheduledTaskAction -Execute "powershell" -Argument $arg
  #$taskTrigger = New-ScheduledTaskTrigger -Daily -At 10AM
#  Register-ScheduledTask -TaskName $name -Action $taskAction #-Trigger $taskTrigger
#  Start-ScheduledTask -TaskName $name