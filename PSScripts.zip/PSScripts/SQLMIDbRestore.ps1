﻿param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='db')]
    [string]$dbName,
    [parameter(Mandatory=$true, position=2, ParameterSetName='db')]
    [string]$backupPath,    
    [parameter(Mandatory=$true, position=3, ParameterSetName='db')]
    [int]$SQLMI
)

if($SQLMI -eq 1){
  
  $SQLServer = 'use2lwintprddb01.850f952d4987.database.windows.net'
  $DB_UserName = 'Delivery.devops'
  $DB_Password = 'BDGH765jgiN'
  $StorageAccountName = 'eus2intdevsa'
  $ContainerName = 'dbbackup'
  $StorageSASToken = 'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwlacupitfx&se=2025-06-30T16:55:44Z&st=2024-07-15T06:35:44Z&spr=https,http&sig=9pPR4ikZonCgUwu1sVmrZv205prkIClC8S7WGAnIC3g%3D'
  $url = 'https://eus2intdevsa.blob.core.windows.net'
}
elseif($SQLMI -eq 2){

  $SQLServer = 'use2lwintprddb02.51458e9cbabe.database.windows.net'
  $DB_UserName = 'CloudOpsAdmin'
  $DB_Password = 'InternalOdeCL0ud@2023'
  $StorageAccountName = 'eus2intdevsa'
  $ContainerName = 'dbbackup'
  $StorageSASToken = 'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwlacupitfx&se=2025-06-30T16:55:44Z&st=2024-07-15T06:35:44Z&spr=https,http&sig=9pPR4ikZonCgUwu1sVmrZv205prkIClC8S7WGAnIC3g%3D'
  $url = 'https://eus2intdevsa.blob.core.windows.net'
}
elseif($SQLMI -eq 3){
   
  $SQLServer = 'uksodehaddevsqlmi01.8ba07aed8c1d.database.windows.net'
  $DB_UserName = 'Delivery.devops'
  $DB_Password = 'BDGH765jgiN'
  $StorageAccountName = 'uksinternalonlyqasa'
  $ContainerName = 'dbbackup'
  $StorageSASToken = 'sv=2022-11-02&ss=b&srt=sco&sp=rwdlaciytfx&se=2025-01-31T13:45:09Z&st=2024-11-12T05:45:09Z&spr=https,http&sig=vbVHh8gEpfe6qb7hwrjjDKu7B48YW5mwe7BSHdlgkIM%3D'
  $url = 'https://uksinternalonlyqasa.blob.core.windows.net'

}
elseif($SQLMI -eq 4){
   
  $SQLServer = 'ceilwintprddb01.76a432477c99.database.windows.net'
  $DB_UserName = 'Delivery.devops'
  $DB_Password = 'BDGH765jgiN'
  $StorageAccountName = 'ceiintqasa'
  $ContainerName = 'dbbackup'
  $StorageSASToken = 'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2025-12-25T18:21:10Z&st=2024-09-05T10:21:10Z&spr=https,http&sig=ZdnYsz57S3kcpTZ%2BbPHbAlt4GtObuRVfQsTJFd6BIjI%3D'
  $url = 'https://ceiintqasa.blob.core.windows.net'

}
elseif($SQLMI -eq 5){
   
  $SQLServer = 'nelwintprddb01.e32710d6016b.database.windows.net'
  $DB_UserName = 'Delivery.devops'
  $DB_Password = 'BDGH765jgiN'
  $StorageAccountName = 'neintqasa'
  $ContainerName = 'dbbackup'
  $StorageSASToken = 'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2025-11-30T14:57:02Z&st=2024-09-27T06:57:02Z&spr=https&sig=wRDTUBHAV0QeIhfFcAdRmUZvMMLMSGhtnNg5OQ0wlkc%3D'
  $url = 'https://neintqasa.blob.core.windows.net'

}

elseif($SQLMI -eq 6){
   
  $SQLServer = 'auelwintprddb01.a1f1d3ce8f29.database.windows.net'
  $DB_UserName = 'Delivery.devops'
  $DB_Password = 'BDGH765jgiN'
  $StorageAccountName = 'aueintqasa'
  $ContainerName = 'dbbackup'
  $StorageSASToken = 'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2025-12-30T20:56:40Z&st=2024-10-24T12:56:40Z&spr=https,http&sig=SsYR%2BUoraqKFgKCb%2Fzd%2Ffa8lNULJVtJO2DDG3UG2rIo%3D'
  $url = 'https://aueintqasa.blob.core.windows.net'

}
elseif($SQLMI -eq 7){

  $SQLServer = 'uselwintprddb01.ca58c7a4d99b.database.windows.net'
  $DB_UserName = 'Delivery.devops'
  $DB_Password = 'BDGH765jgiN'
  $StorageAccountName = 'usintqasa'
  $ContainerName = 'dbbackup'
  $StorageSASToken = 'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwlacupitfx&se=2025-11-30T13:44:13Z&st=2024-11-21T03:44:13Z&spr=https,http&sig=CtL4iflq8E9RaFv0BcAGDzNue6aw55iny4JhQzxpAYY%3D'
  $url = 'https://usintqasa.blob.core.windows.net'

}
elseif($SQLMI -eq 8){
   
  $SQLServer = 'use2intperftstdb01.a392e078d0e4.database.windows.net'
  $DB_UserName = 'cloudopsadmin'
  $DB_Password = 'CloudOde$$@2024#2025'
  $StorageAccountName = 'eus2intdevsa'
  $ContainerName = 'dbbackup'
  $StorageSASToken = 'sv=2022-11-02&ss=bfqt&srt=sco&sp=rwlacupitfx&se=2025-06-30T16:55:44Z&st=2024-07-15T06:35:44Z&spr=https,http&sig=9pPR4ikZonCgUwu1sVmrZv205prkIClC8S7WGAnIC3g%3D'
  $url = 'https://eus2intdevsa.blob.core.windows.net'

}
elseif($SQLMI -eq 9){
   
  $SQLServer = 'sansasdevsqlmiint.72dd36ce097a.database.windows.net'
  $DB_UserName = 'clousopsadmin'
  $DB_Password = 'AzureMiSan2023Odessa'
  $StorageAccountName = ''
  $ContainerName = ''
  $StorageSASToken = ''
  $url = 'https://sansasdevsqlmiint.blob.core.windows.net'

}

Write-Host 'SQL MI Server - ' $SQLServer

if ($backupPath -notlike "*.bak") {
    Write-Output "The backup path is not correct. Please check the Backup Path if it has .bak extension."
} 

#If Db already exists 
$DbExistQuery = "SELECT COUNT(*) FROM sys.databases WHERE name = '$dbName'"
$DbExistQuery
$exist = invoke-sqlcmd -ServerInstance $SQLServer -Database 'master' -Username $DB_UserName -Password $DB_Password -Query $DbExistQuery  -QueryTimeout 65500 -ErrorAction Stop
#$ans.Column1

if($exist.Column1 -eq 1){

Write-Host '*** Db already Exist, Db will be deleted ***'

$dbDeleteQuery = "DROP Database $dbName
GO"
invoke-sqlcmd -ServerInstance $SQLServer -Database 'master' -Username $DB_UserName -Password $DB_Password -Query $dbDeleteQuery  -QueryTimeout 65500 -ErrorAction Stop

}
else{
Write-Host '*** Db Dont exsit. New Db will be restored ***'
}

#upload db backup to container

Import-Module Az

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

# Create the storage context using the SAS token
$StorageContext = New-AzStorageContext -StorageAccountName $StorageAccountName -SasToken $StorageSASToken 


# Get the blob name from the file name
$blobName = [System.IO.Path]::GetFileName($backupPath)

Write-Host 'Upload Started'

# Upload the file to the specified container
Set-AzStorageBlobContent -File $backupPath -Container $ContainerName -Context $StorageContext -Blob $blobName -Force -Properties @{"ContentType" = [System.Web.MimeMapping]::GetMimeMapping($backupPath)}

Write-Host 'Upload Done'

Write-Host 'Restore Started'

$dbRestoreQuery = "RESTORE DATABASE $dbName FROM URL =
  '$url/dbbackup/$BlobName'
GO"
$dbRestoreQuery

invoke-sqlcmd -ServerInstance $SQLServer -Database 'Master' -Username $DB_UserName -Password $DB_Password -Query $dbRestoreQuery  -QueryTimeout 65500 -ErrorAction Stop

Write-Host 'Restore Done'

