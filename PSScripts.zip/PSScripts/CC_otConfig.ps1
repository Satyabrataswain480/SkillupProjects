## OT CONFIG GENERATION ##
param(
$basePath,
$projectName,
$dll,
$iisExpressPath = "C:\Program Files\IIS Express\iisexpress.exe"
)
#$basePath = "D:\Test"
#$projectName = "CSI"
#$dll ="Lw.Domain.Project.Extension"

$sitePath = "$basePath\$projectName\Site"
$siteName = "DotCoverAutomation_$projectName"
$path = "$basePath\applicationhost.config"
$targetName = $siteName


function ChangeToLocalPath{
    param($path)
    $url = [System.Uri]::new($path)
    $p = $url.AbsolutePath.Remove(0,1).Replace("/","\").Replace("$",":")
    return $p
    #return $path
}
$outputPath = ChangeToLocalPath "$basePath\Output"

[xml]$xml = Get-Content -Path $path
$targetNode = Select-Xml -Xml $xml -XPath "//site[@name='$targetName']"
$id = $targetNode.Node.Attributes['id'].value
$port = $targetNode.Node.bindings.binding.Attributes["bindingInformation"].value -replace "[^0-9]", ""

Write-Host "==============================================================================="
Write-Host "Dotcover OT config genearation started."
Write-Host ""

$otconfigName = 'OT_Config.xml'
$otReportconfigName = 'OT_Report.xml'
$dcvrFileName = $projectName+"_OT_CoverageReport.dcvr"
$htmlFileName = $projectName+"_OT_CoverageReport.html"
$configLocation = "$basePath\$projectName\Configs"
$path = ChangeToLocalPath $path

$newNode = @"
<?xml version="1.0" encoding="utf-8"?>
<CoverageParams>
  <TargetExecutable>$iisExpressPath</TargetExecutable>
  <TargetArguments>/site:$siteName /systray:true /config:$path</TargetArguments>
<CoverImmediately>True</CoverImmediately>
<Instance>$id</Instance>
   <Output>$outputPath\$dcvrFileName</Output>
   <Filters>
    <IncludeFilters>
      <FilterEntry>
	   <ModuleMask>$dll</ModuleMask>
       </FilterEntry>
    </IncludeFilters>
  </Filters>
</CoverageParams>
"@

$file = Get-Item -Path "$configLocation\$otconfigName" -ErrorAction Ignore
if($file -eq $null){
    New-Item "$configLocation\$otconfigName" -ItemType File
    Set-Content "$configLocation\$otconfigName" $newNode
    Write-Host ""
    Write-Host "$otconfigName Generated..."
}else {
    Write-Host "$otconfigName already exists..."
}

Write-Host "==============================================================================="

$newNode = @"
<?xml version="1.0" encoding="utf-8"?>
<ReportParams>
  <Source>$outputPath\$dcvrFileName</Source>
  <Output>$outputPath\$htmlFileName</Output>
  <ReportType>html</ReportType>
</ReportParams>
"@

$file = Get-Item -Path "$configLocation\$otReportconfigName" -ErrorAction Ignore
if($file -eq $null){
    New-Item "$configLocation\$otReportconfigName" -ItemType File
    Set-Content "$configLocation\$otReportconfigName" $newNode
    Write-Host ""
    Write-Host "$otReportconfigName Generated..."
}else {
    Write-Host "$otReportconfigName already exists..."
}
Write-Host "==============================================================================="
Write-Host ""
Write-Host "Dotcover OT config genearation completed."
Write-Host "==============================================================================="