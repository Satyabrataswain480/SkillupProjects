﻿Param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='release')]
    [string]$AppSettingsConfig,    
    [parameter(Mandatory=$true, position=2, ParameterSetName='release')]
    [string]$COTicket,   
    [parameter(Mandatory=$true, position=3, ParameterSetName='release')]
    [string]$CustomerPortal,    
    [parameter(Mandatory=$true, position=4, ParameterSetName='release')]
    [string]$Database,    
    [parameter(Mandatory=$true, position=5, ParameterSetName='release')]
    [string]$ReleaseDate,    
    [parameter(Mandatory=$true, position=6, ParameterSetName='release')]
    [string]$ReleaseTime,    
    [parameter(Mandatory=$true, position=7, ParameterSetName='release')]
    [string]$ReleaseVersion,   
    [parameter(Mandatory=$true, position=8, ParameterSetName='release')]
    [string]$Reports,   
    [parameter(Mandatory=$true, position=9, ParameterSetName='release')]
    [string]$WebandJobConfig,      
    [parameter(Mandatory=$true, position=10, ParameterSetName='release')]
    [string]$WindowsService,
    [parameter(Mandatory=$false, position=11, ParameterSetName='release')]
    [string]$PartnerPortal
)

Write-Host "AppSettingsConfig -->" $AppSettingsConfig
Write-Host "COTicket -->" $COTicket
Write-Host "CustomerPortal -->" $CustomerPortal
Write-Host "Database -->" $Database
Write-Host "ReleaseDate -->" $ReleaseDate
Write-Host "ReleaseTime -->" $ReleaseTime
Write-Host "ReleaseVersion -->" $ReleaseVersion
Write-Host "Reports -->" $Reports
Write-Host "WebandJobConfig -->" $WebandJobConfig
Write-Host "WindowsService -->" $WindowsService
Write-Host "PartnerPortal -->" $PartnerPortal
