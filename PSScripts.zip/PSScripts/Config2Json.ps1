﻿#$xmlPath = 'E:\ADAgentWorkFolder\ADAgent-003\544\s\Project\Config';
Param (

[parameter (Mandatory=$true, position=0, ParameterSetName='Config')]
[string]$xmlPath,
[parameter (Mandatory=$true, position=1, ParameterSetName='Config')]
[string]$Flag,
[parameter (Mandatory=$true, position=2, ParameterSetName='Config')]
[string]$ReleasePackagePath
)

#$jsonPath = 'D:\AppSettings.Json' 

if($Flag -eq 'Y' -or $Flag -eq 'y')
{
    try
    { 
        if(Test-path $xmlPath)
        { 
            #UAT APP convert
            $ConfigPath = $xmlPath + '/UAT/App/AppSettings.config'
            $JsonPath = $xmlPath + '/UAT/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }

            #UAT JobService Convert
            $ConfigPathJob = $xmlPath + '/UAT/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/UAT/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }

            #UAT WebAPI Convert
            $ConfigPathJob = $xmlPath + '/UAT/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/UAT/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
        }

        if(Test-path $xmlPath)
        {
            #Prod APP convert
            $ConfigPath = $xmlPath + '/Prod/App/AppSettings.config'
            $JsonPath = $xmlPath + '/Prod/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Prod JobService Convert
            $ConfigPathJob = $xmlPath + '/Prod/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/Prod/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Prod WebAPI Convert
            $ConfigPathJob = $xmlPath + '/Prod/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/Prod/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
        }

        if(Test-path $xmlPath)
        {        
            #Sandbox APP convert
            $ConfigPath = $xmlPath + '/SAN/App/AppSettings.config'
            $JsonPath = $xmlPath + '/SAN/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Sandbox JobService Convert
            $ConfigPathJob = $xmlPath + '/SAN/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/SAN/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath  
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Sandbox WebAPI Convert
            $ConfigPathJob = $xmlPath + '/SAN/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/SAN/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
        }

         if(Test-path $xmlPath)
        {        
            #Migration APP convert
            $ConfigPath = $xmlPath + '/Migration/App/AppSettings.config'
            $JsonPath = $xmlPath + '/Migration/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Migration JobService Convert
            $ConfigPathJob = $xmlPath + '/Migration/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/Migration/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath  
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Migration WebAPI Convert
            $ConfigPathJob = $xmlPath + '/Migration/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/Migration/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
        }
        
        if(Test-path $xmlPath)
        {     

            #INTSTAGING APP convert
            $ConfigPath = $xmlPath + '/INTSTAGING/App/AppSettings.config'
            $JsonPath = $xmlPath + '/INTSTAGING/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #INTSTAGING JobService Convert
            $ConfigPathJob = $xmlPath + '/INTSTAGING/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/INTSTAGING/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath  
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #INTSTAGING WebAPI Convert
            $ConfigPathJob = $xmlPath + '/INTSTAGING/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/INTSTAGING/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
        }

        if(Test-path $xmlPath)
        {
            #QA APP convert
            $ConfigPath = $xmlPath + '/QA/App/AppSettings.config'
            $JsonPath = $xmlPath + '/QA/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #QA JobService Convert
            $ConfigPathJob = $xmlPath + '/QA/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/QA/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath 
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #QA WebAPI Convert
            $ConfigPathJob = $xmlPath + '/QA/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/QA/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
        }

        if(Test-path $xmlPath)
        {
            #Config APP convert
            $ConfigPath = $xmlPath + '/Config/App/AppSettings.config'
            $JsonPath = $xmlPath + '/Config/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Config JobService Convert
            $ConfigPathJob = $xmlPath + '/Config/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/Config/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath 
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Config WebAPI Convert
            $ConfigPathJob = $xmlPath + '/Config/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/Config/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath 
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            
        }

        if(Test-path $xmlPath)
        {
            #Dev APP convert
            $ConfigPath = $xmlPath + '/Dev/App/AppSettings.config'
            $JsonPath = $xmlPath + '/Dev/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Dev JobService Convert
            $ConfigPathJob = $xmlPath + '/Dev/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/Dev/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath 
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Dev WebAPI Convert
            $ConfigPathJob = $xmlPath + '/Dev/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/Dev/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath 
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }            
        }

        if(Test-path $xmlPath)
        {
            #SIT APP convert
            $ConfigPath = $xmlPath + '/SIT/App/AppSettings.config'
            $JsonPath = $xmlPath + '/SIT/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #SIT JobService Convert
            $ConfigPathJob = $xmlPath + '/SIT/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/SIT/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath 
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #SIT WebAPI Convert
            $ConfigPathJob = $xmlPath + '/SIT/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/SIT/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath 
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
        }     

        if(Test-path $xmlPath)
        {
            #Staging APP convert
            $ConfigPath = $xmlPath + '/Staging/App/AppSettings.config'
            $JsonPath = $xmlPath + '/Staging/App/AppSettings.Json'
            if(Test-path $ConfigPath)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPath -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Staging JobService Convert
            $ConfigPathJob = $xmlPath + '/Staging/JobServices/AppSettings.config'
            $JsonPath = $xmlPath + '/Staging/JobServices/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath 
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
            #Staging WebAPI Convert
            $ConfigPathJob = $xmlPath + '/Staging/WebAPI/AppSettings.config'
            $JsonPath = $xmlPath + '/Staging/WebAPI/AppSettings.Json'
            if(Test-path $ConfigPathJob)
            {
                $keyValuePair = @{};
                Select-Xml -Path $ConfigPathJob -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
                $json = $keyValuePair | ConvertTo-JSON
                $json = $json | Out-File $jsonPath 
                $utf8 = New-Object System.Text.UTF8Encoding $false
                $LatestFile = Get-Content $jsonPath -Raw
                Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $jsonPath
            }
        }   

        if(Test-path $xmlPath)
        {
            ##Deleting Appsettings.config file
            Remove-Item -Path $xmlPath -Include 'AppSettings.config' -Recurse -Force 
        }        
    }
    catch 
    {
        throw $_.Exception.Message
    }
}
else
{
    if(Test-path $xmlPath)
    {
        $Include = "AppSettings.config", "AppSettings.json"
        Get-ChildItem $xmlPath -Include $Include -Recurse | Remove-Item -Recurse    
    
        $DefaultXMLFile = $xmlPath + '\AppSettings.xml'
        Remove-Item -Path $DefaultXMLFile -Include 'AppSettings.xml'
        New-Item $DefaultXMLFile -ItemType File 

        $XMLBody='<?xml version="1.0" encoding="utf-8"?>
        <appSettings>
        </appSettings>'

        if(Test-Path $DefaultXMLFile)
        {
            Set-Content $DefaultXMLFile $XMLBody
            $JsonPath = $xmlPath + '/AppSettings.json'

            $keyValuePair = @{};
            Select-Xml -Path $DefaultXMLFile -XPath '/appSettings/add' | ForEach-Object { $keyValuePair.Add($_.Node.key,$_.Node.value) }
            $json = $keyValuePair | ConvertTo-JSON
            $json = $json | Out-File $JsonPath
            $utf8 = New-Object System.Text.UTF8Encoding $false
            $LatestFile = Get-Content $JsonPath -Raw
            Set-Content -Value $utf8.GetBytes($LatestFile) -Encoding Byte -Path $JsonPath

            
            #UAT
            $UATApp = $xmlPath + '/UAT/App/'
            if(Test-Path $UATApp)
            {
                Copy-item -Path $JsonPath $UATApp -Recurse -Force
            }
            $UATJob = $xmlPath + '/UAT/JobServices/'
            if(Test-Path $UATJob)
            {
                Copy-item -Path $JsonPath $UATJob -Recurse -Force
            }
            $UATWebAPI = $xmlPath + '/UAT/WebAPI/'
            if(Test-Path $UATWebAPI)
            {
                Copy-item -Path $JsonPath $UATWebAPI -Recurse -Force
            }
            #Prod
            $ProdApp = $xmlPath + '/Prod/App/'
            if(Test-Path $ProdApp)
            {
                Copy-item -Path $JsonPath $ProdApp -Recurse -Force
            }
            $ProdJob = $xmlPath + '/Prod/JobServices/'
            if(Test-Path $ProdJob)
            {
                Copy-item -Path $JsonPath $ProdJob -Recurse -Force
            }
            $ProdWebAPI = $xmlPath + '/Prod/WebAPI/'
            if(Test-Path $ProdWebAPI)
            {
                Copy-item -Path $JsonPath $ProdWebAPI -Recurse -Force
            }
            #Sandbox
            $SANApp = $xmlPath + '/SAN/App/'
            if(Test-Path $SANApp)
            {
                Copy-item -Path $JsonPath $SANApp -Recurse -Force
            }
            $SANJob = $xmlPath + '/SAN/JobServices/'
            if(Test-Path $SANJob)
            {
                Copy-item -Path $JsonPath $SANJob -Recurse -Force
            }
            $SANWebAPI = $xmlPath + '/SAN/WebAPI/'
            if(Test-Path $SANWebAPI)
            {
                Copy-item -Path $JsonPath $SANWebAPI -Recurse -Force
            }
            #INTSTAGING
            $INTSTAGINGApp = $xmlPath + '/INTSTAGING/App/'
            if(Test-Path $INTSTAGINGApp)
            {
                Copy-item -Path $JsonPath $INTSTAGINGApp -Recurse -Force
            }
            $INTSTAGINGJob = $xmlPath + '/INTSTAGING/JobServices/'
            if(Test-Path $INTSTAGINGJob)
            {
                Copy-item -Path $JsonPath $INTSTAGINGJob -Recurse -Force
            }
            $INTSTAGINGWebAPI = $xmlPath + '/INTSTAGING/WebAPI/'
            if(Test-Path $INTSTAGINGWebAPI)
            {
                Copy-item -Path $JsonPath $INTSTAGINGWebAPI -Recurse -Force
            }
            #QA
            $QAApp = $xmlPath + '/QA/App/'
            if(Test-Path $QAApp)
            {
                Copy-item -Path $JsonPath $QAApp -Recurse -Force
            }
            $QAJob = $xmlPath + '/QA/JobServices/'
            if(Test-Path $QAJob)
            {
                Copy-item -Path $JsonPath $QAJob -Recurse -Force
            }
            $QAWebAPI = $xmlPath + '/QA/WebAPI/'
            if(Test-Path $QAWebAPI)
            {
                Copy-item -Path $JsonPath $QAWebAPI -Recurse -Force
            }
            #Config
            $ConfigApp = $xmlPath + '/Config/App/'
            if(Test-Path $ConfigApp)
            {
                Copy-item -Path $JsonPath $ConfigApp -Recurse -Force
            }
            $ConfigJob = $xmlPath + '/Config/JobServices/'
            if(Test-Path $ConfigJob)
            {
                Copy-item -Path $JsonPath $ConfigJob -Recurse -Force
            }
            $ConfigWebAPI = $xmlPath + '/Config/WebAPI/'
            if(Test-Path $ConfigWebAPI)
            {
                Copy-item -Path $JsonPath $ConfigWebAPI -Recurse -Force
            }
            #Dev
            $DevApp = $xmlPath + '/Dev/App/'
            if(Test-Path $DevApp)
            {
                Copy-item -Path $JsonPath $DevApp -Recurse -Force
            }
            $DevJob = $xmlPath + '/Dev/JobServices/'
            if(Test-Path $DevJob)
            {
                Copy-item -Path $JsonPath $DevJob -Recurse -Force
            }
            $DevWebAPI = $xmlPath + '/Dev/WebAPI/'
            if(Test-Path $DevWebAPI)
            {
                Copy-item -Path $JsonPath $DevWebAPI -Recurse -Force
            }
            #SIT
            $SITApp = $xmlPath + '/SIT/App/'
            if(Test-Path $SITApp)
            {
                Copy-item -Path $JsonPath $SITApp -Recurse -Force
            }
            $SITJob = $xmlPath + '/SIT/JobServices/'
            if(Test-Path $SITJob)
            {
                Copy-item -Path $JsonPath $SITJob -Recurse -Force
            }
            $SITWebAPI = $xmlPath + '/SIT/WebAPI/'
            if(Test-Path $SITWebAPI)
            {
                Copy-item -Path $JsonPath $SITWebAPI -Recurse -Force
            }
            #Staging
            $StagingApp = $xmlPath + '/Staging/App/'
            if(Test-Path $StagingApp)
            {
                Copy-item -Path $JsonPath $StagingApp -Recurse -Force
            }
            $StagingJob = $xmlPath + '/Staging/JobServices/'
            if(Test-Path $StagingJob)
            {
                Copy-item -Path $JsonPath $StagingJob -Recurse -Force
            }
            $StagingWebAPI = $xmlPath + '/Staging/WebAPI/'
            if(Test-Path $StagingWebAPI)
            {
                Copy-item -Path $JsonPath $StagingWebAPI -Recurse -Force
            }

            if(Test-Path $xmlPath)
            {
                Write-Host "Final Config Path:" $xmlPath
                $Include = "AppSettings.xml", "AppSettings.json"
                $tempXML = $xmlPath + '\*'
                Remove-Item -Path $tempXML -Include $Include -Force 
            }
        }        
    }
}

if(Test-path $ReleasePackagePath)
{    
    #Copy config folder to release package path
    $currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
    $RelDir = $ReleasePackagePath + $currentDate + '\Config'
    write-host $RelDir
    if(Test-Path($RelDir))
    {
        New-item -Path $RelDir
    }
    write-host $xmlPath
    if(Test-path $xmlPath)
    {
        Copy-item -Path $xmlPath $RelDir -Recurse -Force
    } 
}
