﻿param
(
    [parameter(Mandatory=$false, Position=0, ParameterSetName='Release')]
    [string]$PackagePath,
    [parameter(Mandatory=$false, Position=1, ParameterSetName='Release')]
    [string]$SitePath,
    [parameter(Mandatory=$false, Position=2, ParameterSetName='Release')]
    [string]$Id,
    [parameter(Mandatory=$false, Position=3, ParameterSetName='Release')]
    [string]$Clear = '1'
)

#function to HandleOpenFolders
function Handle-OpenFolders {
    param(
        [Parameter(Mandatory = $true)]
        [string]$sitePath
    )
    
    try {
        # Get all open files related to the sitePath
        $openFiles = Get-SmbOpenFile | Where-Object { $_.Path -like "$sitePath*" }
        
        if ($null -ne $openFiles -and $openFiles.Count -gt 0) {        
            Write-Host "`nClosing all open file sessions for $sitePath..." -ForegroundColor Yellow

            foreach ($file in $openFiles) {
                try {
                    if ($null -ne $file.SessionId) {
                        Close-SmbOpenFile -SessionId $file.SessionId -Force
                        Write-Host "Session with ID $($file.SessionId) for path $($file.Path) has been closed successfully." -ForegroundColor Green
                    } else {
                        Write-Host "Invalid session ID for file path $($file.Path)." -ForegroundColor Red
                    }
                } catch {
                    Write-Host "Failed to close session for file path $($file.Path). Error: $($_.Exception.Message)" -ForegroundColor Red
                }
            }
        } else {
            Write-Host "No open file sessions found for $sitePath." -ForegroundColor Green
        }
    } catch {
        Write-Host "An error occurred while fetching open files. Error: $($_.Exception.Message)" -ForegroundColor Red
    }
}

if ($Id -ne 'na' -or $Id -ne 'NA') {
    $currentDate = 'Release_' + (Get-Date).ToString("yyyy-MM-dd")
    $PackagePath = $PackagePath + "\" + $currentDate + "\" + $Id + "\"
}
$PackagePath
$SitePath
$Clear

if ((Test-Path $PackagePath) -eq $false) {
    Write-Host "No package found $PackagePath" -ForegroundColor Red
    return
} elseif ((Test-Path $SitePath) -eq $false) {
    Write-Host "Destination $SitePath not found" -ForegroundColor Red
    return
}

$PackageServer = ($PackagePath -split '\\')[2]
$SiteServer = ($SitePath -split '\\')[2]

Write-Host "Package Server: $PackageServer"
Write-Host "Site Server: $SiteServer"

# Use Invoke-Command to handle open files on both servers
Invoke-Command -ComputerName $PackageServer -ScriptBlock ${function:Handle-OpenFolders} -ArgumentList $PackagePath
Invoke-Command -ComputerName $SiteServer -ScriptBlock ${function:Handle-OpenFolders} -ArgumentList $SitePath

if ($Clear -eq '1') {
    Remove-Item -Path $SitePath -Exclude *.config,*.bat -Force -Recurse -Verbose
}
#Copy-Item -Path $PackagePath -Destination $SitePath -Force -Recurse -Verbose
#robocopy $PackagePath $SitePath /S /E /Z /B /ZB /R:5 /W:5 /TBD /NP /V /MT:32 /copyall
robocopy $PackagePath $SitePath /S /E /R:5 /W:15 /NP /V /COPY:DATSO

Write-Host "Successfully completed $Id site folder..." -ForegroundColor Green

if ($LASTEXITCODE -lt 8) { $LASTEXITCODE = 0 }