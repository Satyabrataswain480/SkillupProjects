﻿Param(
[parameter (Mandatory=$true, position=0, ParameterSetName='RDL')]
[string]$PackagePath,
[parameter (Mandatory=$true, position=1, ParameterSetName='RDL')]
[string]$ReportServerSharedPath,
[parameter (Mandatory=$true, position=2, ParameterSetName='RDL')]
[string]$ExePath,
[parameter (Mandatory=$true, position=3, ParameterSetName='RDL')]
[string]$RDLBackupPath,
[parameter (Mandatory=$true, position=4, ParameterSetName='RDL')]
[string]$ReportServerURL,
[parameter (Mandatory=$true, position=5, ParameterSetName='RDL')]
[string]$ReportServer,
[parameter (Mandatory=$true, position=6, ParameterSetName='RDL')]
[string]$ReportFolderName
)

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$packagePath = $PackagePath + "\" + $currentDate + "\"
$ReportPath = $packagePath +'Reports'
$RDLPath = $ReportPath + '\RDLs'

if(Test-Path $RDLPath)
{
    if((Get-ChildItem $RDLPath -force | Select-Object -First 1 | Measure-Object).Count -gt 0)
    {    
        if(Test-Path $ReportPath)
        {
            $ReportHelper = $packagePath +'Reports\ReportHelper\*.dll'
            if(!(Test-Path $ReportHelper))
            {
                $packagePath
                write-host 'Skipping DLL replacement process, as no content found.'
            }
            else
            {
                Write-Host 'Report ReportHelper dll copy started'
                Copy-Item -path $ReportHelper -destination $ReportServerSharedPath -Force -Recurse -ErrorAction Ignore
                Write-Host 'Report helper dll copy completed'
            }

            ## restart SQLServerReportingService

            $Service = Get-WmiObject -ComputerName $ReportServer -Class Win32_Service -Filter "Name='SQLServerReportingServices'"
            $Service.stopservice()

            Start-Sleep 30

            $Service = Get-WmiObject -ComputerName $ReportServer -Class Win32_Service -Filter "Name='SQLServerReportingServices'"
            $Service.startservice()

            Start-Sleep 90

            $RDLSourcePath = $packagePath +'Reports\RDLs'

            $Service_Status = Get-Service -Name 'SQLServerReportingServices' -ComputerName $ReportServer
            if($Service_Status.status -eq "Running")  
            {                
                if(Test-Path $RDLSourcePath)
                {
                    Write-Host $RDLSourcePath
                    Write-Host 'Report upload Started.'
                    Set-Location -Path $ExePath
                    .\ReportAutomation.exe 1 $RDLSourcePath $RDLBackupPath $ReportServerURL /$ReportFolderName
                    Write-Host 'Report upload Completed.'
                }                
            }
            else{
                write-host 'Service,SQLServerReportingServices is not Running ..'
            }
        }
        else
        {
            write-host 'Report folder not found..'
        }
    }
    else
    {
        Write-Host "No RDL files found..."
    }
}




