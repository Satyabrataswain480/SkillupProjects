param(
    $server,
    $projectName,
    $basePath,
    $filenmae = 'CodeCoverageTemplate.ps1'
)

#$server = 'LWDELBUILD-002'
#$projectName = 'AAG'
#$basePath = '\\lwdelbuild-002\e$\DoNotDelete\DotCover'
#$filenmae = 'CodeCoverageTemplate_New_Test.ps1'
Invoke-Command -ComputerName $server -ScriptBlock{
    function ChangeToLocalPath{
        param($path)
        Write-Host $path
        $url = [System.Uri]::new($path)
        $p = $url.AbsolutePath.Remove(0,1).Replace("/","\").Replace("$",":")
        return $p
        #return $path
    }

    function CreateNRunScheduledTask{
        param([string]$projectName, [string]$basePath, [string]$filenmae)

        $taskName = "DotCoverAutomation_$projectName"
        $exe = 'powershell'
        $basePath = ChangeToLocalPath $basePath
        $arg = "$basePath\$projectName\Script\$filenmae"

        $task = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Ignore

        if($task){
        if($task.State -eq "Running")
        {
            throw "Task is already running"
            exit -1 
        }
              Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        }
        
        $taskAction = New-ScheduledTaskAction -Execute $exe -Argument "-File $arg"
        
        Register-ScheduledTask -TaskName $taskName -Action $taskAction -User 'ODESSAPDC01\devops.admin' -Password 'Password@123'
        
        
        Start-ScheduledTask -TaskName $taskName
    }

    CreateNRunScheduledTask $using:projectName $using:basePath $using:filenmae

}