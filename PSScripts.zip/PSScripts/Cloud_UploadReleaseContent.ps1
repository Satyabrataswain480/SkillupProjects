##  This script will upload release contents to storage account.


Param  (

[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$StorageAccountName,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$StorageContainerName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$SASToken,
[parameter (Mandatory=$true, position=3, ParameterSetName='Release')]
[string]$Package_Destination_Path,
[parameter (Mandatory=$true, position=4, ParameterSetName='Release')]
[string]$Package_Version,
[parameter (Mandatory=$true, position=5, ParameterSetName='Release')]
[string]$ReleaseFolder

)

Import-Module Az

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;

$StorageContext = New-AzStorageContext -StorageAccountName $StorageAccountName -SasToken $SASToken 

$PackageFile = $Package_Destination_Path + $Package_Version + ".zip"

#$SourceDir = $Package_Destination_Path 

Write-Host "Package Path:" $PackageFile

$blobname = $ReleaseFolder + '\' + $Package_Version + ".zip"

#$blobs = Get-AzStorageBlob -Container $StorageContainerName
 
Set-AzStorageBlobContent -File $PackageFile -Container $StorageContainerName -Context $StorageContext -Blob $blobname -Force -Properties @{"ContentType" = [System.Web.MimeMapping]::GetMimeMapping($PackageFile); } 

   

