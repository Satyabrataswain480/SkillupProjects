﻿param(
$IIS_Path,
$Publish_Path
)

$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$Publish_Path = $Publish_Path + $currentDate + "\"
$Publish_Path
$ttPath = $Publish_Path + "\*.tt"
if ( Test-Path $ttPath)
{
    Remove-Item -Path $ttPath -Recurse -force
}

Remove-Item –path $Publish_Path -include AppSettings.config –recurse
Remove-Item –path $Publish_Path -include ConnectionStrings.config –recurse
Remove-Item –path $Publish_Path -include Lw.WindowsServices.exe.config –recurse
Remove-Item –path $Publish_Path -include Web.config –recurse

#$ConfigPath = $Publish_Path + "\LessorPortal\*.Config"
#if ( Test-Path $ConfigPath)
#{
#    Remove-Item -Path $ConfigPath -Recurse -force
#}

$DBContext = $IIS_Path + "\DomainAssemblies\LeasewaveRepositoryDbContext.Views"
if ( Test-Path $DBContext)
{
    Remove-Item -Path $DBContext -Recurse -force
    Write-Host "Deleted" $DBContext
}

$DTMPPath = $IIS_Path + "\DomainAssemblies\temp"
if ( Test-Path $DTMPPath)
{
    Remove-Item -Path $DTMPPath -Recurse -force -ErrorAction Ignore
    Write-Host "Deleted" $DTMPPath

}