﻿##  This script will create Release contant
Param  (
[parameter (Mandatory=$true, position=0, ParameterSetName='Release')]
[string]$Build_Path,
[parameter (Mandatory=$true, position=1, ParameterSetName='Release')]
[string]$Release_Path,
[parameter (Mandatory=$true, position=2, ParameterSetName='Release')]
[string]$Artifact_Build_Path,
[parameter (Mandatory=$false, position=3, ParameterSetName='Release')]
[string]$PackageReference,
[parameter (Mandatory=$false, position=4, ParameterSetName='Release')]
[string]$IsCustomerPortal,
[parameter (Mandatory=$false, position=5, ParameterSetName='Release')]
[string]$IsDotNet7Upgraded = '0',
[parameter (Mandatory=$false, position=6, ParameterSetName='Release')]
[string]$IsDotNet7 = '0'
)

##  Create Date folder for release
$currentDate = 'Release_' + (Get-date).ToString("yyyy-MM-dd") 
$RelDir = $Release_Path + $currentDate

if($PackageReference -eq '1')
{    
  $packagePath = 'C:\Users\devops.admin\.nuget\packages'
  write-host 'Package Reference Path: ' $packagePath

}
else
{
  $packagePath = $Build_Path + '\Packages'
}

if($PackageReference -eq '1')
{
    #Get the Current Fx version configured for LeaseWave solution
    $BuildProjData = [xml]( Get-Content  "$Build_Path\Build.proj"); 
    $FrameworkVersion = $BuildProjData.Project.ChildNodes.Item(0).FrameworkVersion
    $FRWKFolders = $packagePath + '\odessa.framework\' + $FrameworkVersion
    $FRWKABSPath = $FRWKFolders
    write-host 'FRWK Path: ' $FRWKABSPath
}
else
{
    $FRWKFolders = Get-childitem -Path $packagePath -Filter 'lw.Framework*'
    $FRWKABSPath = $null
}

if($PackageReference -eq '0')
{
    if($FRWKFolders.count -gt 1)
    {
      write-host 'Multiple framework folders found. keep only latest one'
      throw
    }
    else
    {
      $FRWKABSPath = $FRWKFolders.FullName
      write-host $FRWKABSPath
    }
}

if(!(Test-path -Path $RelDir))
{
   New-Item -Name $currentDate -ItemType Directory -Path $Release_Path
} 
else
{
  Remove-Item -Path $RelDir -Recurse -Force
  New-Item -Name $currentDate -ItemType Directory -Path $Release_Path
}

##  Creating Root FOlder
if($IsCustomerPortal -eq '1')
{
    New-Item -Name 'CustomerPortal'  -ItemType Directory -Path $RelDir
}
else
{
    New-Item -Name 'PartnerPortal'  -ItemType Directory -Path $RelDir
}
New-Item -Name 'Database'  -ItemType Directory -Path $RelDir
New-Item -Name 'Reports'  -ItemType Directory -Path $RelDir
New-Item -Name 'WindowsService'  -ItemType Directory -Path $RelDir
New-Item -Name 'ReleaseNotes'  -ItemType Directory -Path $RelDir

### Creating Sub FOlders
if($IsCustomerPortal -eq '1')
{
    $LP = $RelDir + '\CustomerPortal'
}
else
{
    $LP = $RelDir + '\PartnerPortal'
}
New-Item -Name 'App_Data'  -ItemType Directory -Path $LP

### Creating Sub FOlders
$DBScripts = $RelDir + '\Database'
New-Item -Name 'DBScripts\DDL'  -ItemType Directory -Path $DBScripts
New-Item -Name 'DBScripts\DML'  -ItemType Directory -Path $DBScripts
   
$Reports = $RelDir + '\Reports'
New-Item -Name 'RDLs'  -ItemType Directory -Path  $Reports
New-Item -Name 'ReportHelper'  -ItemType Directory -Path  $Reports


### Fill FRWK folders
write-host 'Preparing WindowsService...'
if($IsDotNet7Upgraded -eq '1')
{
    if($IsDotNet7 -eq '1')
    {
        $SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\net7.0\'
    }
    else
    {
        $SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\net48\'
    }
}
else
{
    $SourceWindowService = $FRWKABSPath + '\Tools\Lw.WindowsServices\'
}

write-host 'WindowsService Source path: ' $SourceWindowService
$DestWindowService = $RelDir + '\WindowsService\'

robocopy $SourceWindowService $DestWindowService /E /copyall

##Copy Lw.Domain dll's
$Window0 = $Artifact_Build_Path + '\Lw.Domain.Extension.dll'
$Window1 = $Artifact_Build_Path + '\Lw.Domain.Project.Extension.dll'
$Window2 = $Artifact_Build_Path + '\Lw.Domain.Project.Resource.dll'
$Window3 = $Artifact_Build_Path + '\Lw.Domain.Resource.dll'

$Window4 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.ApplicationInsights.dll'
$Window5 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.DependencyCollector.dll'
$Window6 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.PerfCounterCollector.dll'
$Window7 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.Web.dll'
$Window8 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.WindowsServer.dll'
$Window9 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AI.ServerTelemetryChannel.dll'
$Window10 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.AspNet.TelemetryCorrelation.dll'

$Window11 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\System.Diagnostics.DiagnosticSource.dll'
$Window12 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Azure.dll'
$Window13 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.AzureAppConfiguration.dll'
$Window14 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Base.dll'
$Window15 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.Environment.dll'
$Window16 = $Artifact_Build_Path + '\_PublishedWebsites\Lw.LessorPortal.Project\bin\Microsoft.Configuration.ConfigurationBuilders.UserSecrets.dll'



if(!([string]::IsNullOrEmpty($Window0)) -and (Test-path $Window0)){
    Copy-Item $Window0 $DestWindowService
}
if(!([string]::IsNullOrEmpty($Window1)) -and (Test-path $Window1)){
    Copy-Item $Window1 $DestWindowService
}
if(!([string]::IsNullOrEmpty($Window2)) -and (Test-path $Window2)){
    Copy-Item $Window2 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window3)) -and (Test-path $Window3)){
    Copy-Item $Window3 $DestWindowService 
}


if(!([string]::IsNullOrEmpty($Window4)) -and (Test-path $Window4)){
    Copy-Item $Window4 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window5)) -and (Test-path $Window5)){
    Copy-Item $Window5 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window6)) -and (Test-path $Window6)){
    Copy-Item $Window6 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window7)) -and (Test-path $Window7)){
    Copy-Item $Window7 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window8)) -and (Test-path $Window8)){
    Copy-Item $Window8 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window9)) -and (Test-path $Window9)){
    Copy-Item $Window9 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window10)) -and (Test-path $Window10)){
    Copy-Item $Window10 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window11)) -and (Test-path $Window11)){
    Copy-Item $Window11 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window12)) -and (Test-path $Window12)){
    Copy-Item $Window12 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window13)) -and (Test-path $Window13)){
    Copy-Item $Window13 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window14)) -and (Test-path $Window14)){
    Copy-Item $Window14 $DestWindowService 
}

if(!([string]::IsNullOrEmpty($Window15)) -and (Test-path $Window15)){
    Copy-Item $Window15 $DestWindowService 
}
if(!([string]::IsNullOrEmpty($Window16)) -and (Test-path $Window16)){
    Copy-Item $Window16 $DestWindowService 
}


##Copy Tavalue to WindowService bin folder

$SourceTValue1 = $Artifact_Build_Path + '\TValue6.dll'
$SourceTvalue2 = $Artifact_Build_Path + '\Tvalue6Engine2.dll'

if(!([string]::IsNullOrEmpty($SourceTValue1)) -and (Test-path $SourceTValue1)){
    copy-item $SourceTValue1 $DestWindowService
}
if(!([string]::IsNullOrEmpty($SourceTValue2)) -and (Test-path $SourceTValue2)){
    copy-item $SourceTValue2 $DestWindowService
}

write-host 'Completed WindowsService...'

if ($lastexitcode -lt 8) { $lastexitcode = 0 }

