﻿
Param (
    [Parameter(Mandatory = $true, Position = 0, ParameterSetName = 'Reports')]
    [string]$ProjectName
)

# Construct the API URL
$apiUrl = "http://lwdelbuild-001:8090/codecoverage/getCurrent/$ProjectName"
Write-Output "API URL: $apiUrl"

# Send request to API
$response = Invoke-WebRequest -Headers @{ "Content-Type" = "application/json" } -Uri $apiUrl -Method POST

# Parse the JSON response
$jsonContent = $response.Content | ConvertFrom-Json

# Extract the code coverage percentage
$percentage = $jsonContent[0].percentage

# Output the code coverage percentage
Write-Host "Code Coverage Percentage: $percentage"

# Check if the percentage is below the threshold
if ($percentage -lt 60) {
    Write-Error "Code coverage percentage is less than 60%. Kindly get approval from Vedapuri to proceed with the release. Thanks!"
}
