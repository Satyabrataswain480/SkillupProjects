﻿param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='db')]
    [string]$dbBackup,
    [parameter(Mandatory=$true, position=2, ParameterSetName='db')]
    [string]$TargetDbName,
    [parameter(Mandatory=$true, position=3, ParameterSetName='db')]
    [string]$RestoreServer,
    [parameter(Mandatory=$true, position=4, ParameterSetName='db')]
    [string]$IsSizeCheckRequired
)

if ($dbBackup -notlike "*.bak") {
    Write-Output "The backup path is not correct. Please check the Backup Path if it has .bak extension."
    exit 1
}

if($IsSizeCheckRequired -eq 'true'){ 

$fileInfo = Get-Item $dbBackup
$fileSizeGB = [math]::Round($fileInfo.Length / 1GB, 2)

Write-Output "The size of the database backup is: $fileSizeGB GB"

if($fileSizeGB -gt '50'){

  Write-Host 'Db Size is Greater that 50 GB. Please Check with Kirubakarn G and Shiv Shankar'
  exit 1

}
}


#If Db already exists 
$DbExistQuery = "SELECT COUNT(*) FROM sys.databases WHERE name = '$TargetDbName'"
$DbExistQuery
$exist = invoke-sqlcmd -ServerInstance $RestoreServer -Database 'master' -Query $DbExistQuery  -QueryTimeout 65500 -ErrorAction Stop
#$ans.Column1

if($exist.Column1 -eq 1){

Write-Host '*** Db already Exist, Sessions will be killed and Db will be taken offline ***'

$databaseStatus = (invoke-sqlcmd -ServerInstance $RestoreServer -Database 'master' -Query "SELECT state_desc FROM sys.databases WHERE name = '$TargetDbName';"  -QueryTimeout 65500 -ErrorAction Stop
).state_desc

if($databaseStatus -eq 'OFFLINE'){ 

$query = "ALTER DATABASE $TargetDbName SET ONLINE WITH NO_WAIT;"
$query
invoke-sqlcmd -ServerInstance $RestoreServer -Database 'master' -Query $query  -QueryTimeout 65500 -ErrorAction Stop

}

#Kill Session
$InsertQuery = "USE master;
DECLARE @DatabaseName NVARCHAR(100)
SET @DatabaseName = '$TargetDbName'

DECLARE @KillConnections NVARCHAR(MAX) = ''
SELECT @KillConnections = @KillConnections + 'Kill ' + CAST(spid AS NVARCHAR) + ';'
FROM sys.sysprocesses
WHERE DBID = DB_ID(@DatabaseName)

EXEC (@KillConnections)
GO"
$InsertQuery

invoke-sqlcmd -ServerInstance $RestoreServer -Database $TargetDbName -Query $InsertQuery  -QueryTimeout 65500 -ErrorAction Stop
Write-Host '*** Sessions are Killed Now ***'

$query = "ALTER DATABASE $TargetDbName SET OFFLINE WITH NO_WAIT"
$query
invoke-sqlcmd -ServerInstance $RestoreServer -Database $TargetDbName -Query $query  -QueryTimeout 65500 -ErrorAction Stop
Write-Host '*** $TargetDbName is now OFFLINE ***'

}
else{Write-Host '*** Db Dont exsit. New Db will be restored *** '}

#######################################################################################################################################

$ServerDefaultPath = "SELECT 
SERVERPROPERTY('InstanceDefaultDataPath') AS InstanceDefaultDataPath,
SERVERPROPERTY('InstanceDefaultLogPath') AS InstanceDefaultLogPath"

$defaultPath=Invoke-Sqlcmd -ServerInstance $RestoreServer -Query $ServerDefaultPath -QueryTimeout 65500 -ErrorAction Stop

$InstanceDefaultDataPath = $defaultPath.InstanceDefaultDataPath + $TargetDbName + '.mdf'
Write-host '*** DATA Path -- ' $InstanceDefaultDataPath ' ***'

$InstanceDefaultLogPath = $defaultPath.InstanceDefaultLogPath + $TargetDbName + '.ldf'
Write-host '*** LOG Path -- ' $InstanceDefaultLogPath ' ***'

$XTPDefaultPath = $defaultPath.InstanceDefaultDataPath + $TargetDbName + '.ndf'
Write-host '*** XTP Path -- ' $XTPDefaultPath ' ***'

#######################################################################################################################################
#Getting the Logical Data,Log and XTP File name

$logicalNameQuery = "RESTORE FILELISTONLY FROM DISK = '$dbBackup';"

$logicalNamefromBackup = Invoke-Sqlcmd -ServerInstance $RestoreServer -Query $logicalNameQuery -QueryTimeout 65500 -ErrorAction Stop


$LogicalDataFileNameFromBackup = $logicalNamefromBackup | Where-Object { $_.Type -eq 'D' }
$LogicalDataFileNameFromBackup = $LogicalDataFileNameFromBackup.LogicalName
Write-host '*** LogicalDataFileNameFromBackup --' $LogicalDataFileNameFromBackup ' ***'

$LogicalLogFileNameFromBackup = $logicalNamefromBackup | Where-Object { $_.Type -eq 'L' }
$LogicalLogFileNameFromBackup = $LogicalLogFileNameFromBackup.LogicalName
Write-host '*** LogicalLogFileNameFromBackup --' $LogicalLogFileNameFromBackup ' ***'

$AdditionalLogicalFileNameFromBackup = $logicalNamefromBackup | Where-Object { $_.Type -eq 'S' }
$AdditionalLogicalFileNameFromBackup = $AdditionalLogicalFileNameFromBackup.LogicalName
Write-host '*** AdditionalLogicalFileNameFromBackup --' $AdditionalLogicalFileNameFromBackup ' ***'

########################################################################################################################################
#Framing the Restore Query
if (!([string]::IsNullOrEmpty($AdditionalLogicalFileNameFromBackup))) {
    Write-Host "*** Its 2022 Instance ***"

    $RestoreScript = "USE master;
RESTORE DATABASE $TargetDbName
FROM DISK = '$dbBackup'
WITH
    MOVE '$LogicalDataFileNameFromBackup' TO '$InstanceDefaultDataPath',
    MOVE '$LogicalLogFileNameFromBackup' TO '$InstanceDefaultLogPath',
    MOVE '$AdditionalLogicalFileNameFromBackup' TO '$XTPDefaultPath',
    REPLACE,keep_cdc;
"
} else {
    $RestoreScript = "USE master;
RESTORE DATABASE $TargetDbName
FROM DISK = '$dbBackup'
WITH
    MOVE '$LogicalDataFileNameFromBackup' TO '$InstanceDefaultDataPath',
    MOVE '$LogicalLogFileNameFromBackup' TO '$InstanceDefaultLogPath',
    REPLACE;
"
}


Write-host '*** Restore Query --' $RestoreScript ' ***'

Invoke-Sqlcmd -ServerInstance $RestoreServer -Query $RestoreScript -QueryTimeout 65500 -ErrorAction Stop

