param(
	
    [parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
    [string]$FolderPath,
    [parameter (Mandatory=$false, position=1, ParameterSetName='Database')]
    [string]$NameCheckRequired,
    [parameter (Mandatory=$false, position=2, ParameterSetName='Database')]
    [string]$IsConsolidated  = '0'
)
#$FolderPath = 'D:\Random\'#"D:\temp\"

Function checkCharacter([string]$filepath)
{
    #ASCII characters (code points 32 through 127 == [\x20-\x7F]) [^\x00-\x7F\xA3] 
    
    $nonASCII = "[^\x00-\x7F-[��]]"
    $linenumber = 0
    $haserror = 0
    foreach ($m in [System.IO.File]::ReadLines($filepath)){
        $linenumber++
        if ($m -cmatch $nonASCII){
            write-output "line number: $linenumber contains invalid character(s) $m" 
            $haserror = 1   
        }
    }
    if($haserror -eq 1)
    {
        throw "Invalid Character found: filename=$filepath"
    } 
 
}
$DbScriptSource =  $FolderPath
    if(!(Test-path $DbScriptSource))
    {
        $FolderPath
        write-host "No sql scripts found under $DbScriptSource"

    }
    else{
            foreach ($filename in get-childitem -path $DbScriptSource -filter "*.sql")
            {
               $SQLFile=$filename.fullname
               write-host "SQL File executing - " $SQLFile
               checkCharacter($SQLFile)
               if($NameCheckRequired -eq '1')
               {
                   $regex = '^[1-3][0-9]{3}_.{1,31}\.sql$'
                   $found = $filename -match $regex
                   #Write-Host "$filename : $found"
                   if($found -eq $false)
                   {
                     throw "$filename have incorrect filename. Please follow the naming convention mentioned in readme file."
                   }  
               }  
            }
    }

##Check DDL
    if($IsConsolidated -eq 0){
        $DbScriptSource =  $FolderPath +  '\DDL\'
    }
    else{
        $DbScriptSource =  $FolderPath + '\DDL\Consolidated\'
    }
    if(!(Test-path $DbScriptSource))
    {
        $FolderPath
        write-host "No sql scripts found under $DbScriptSource"

    }
    else
    {
            foreach ($filename in get-childitem -path $DbScriptSource -filter "*.sql")
            {
               $SQLFile=$filename.fullname
               write-host "SQL File executing - " $SQLFile
               checkCharacter($SQLFile)
               if($NameCheckRequired -eq '1')
               {
                   $regex = '^[1-3][0-9]{3}_.{1,31}\.sql$'
                   $found = $filename -match $regex
                   #Write-Host "$filename : $found"
                   if($found -eq $false)
                   {
                     throw "$filename have incorrect filename. Please follow the naming convention mentioned in readme file."
                   }  
               }
            }
    }

 ## Validate DDL Go statement
    $SQLScriptDDLPath = $FolderPath +  '\DDL\*.sql'
    if(Test-Path $SQLScriptDDLPath)
    {
        $SQLFiles = Get-Item -Path $SQLScriptDDLPath

        for ($i=0; $i -lt $SQLFiles.Count; $i++) 
        {
            $outfile = $SQLFiles[$i].FullName
            $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
            write-host $outfile +" - " + $SQLFileContent

            if($SQLFileContent -ne 'GO' -or $SQLFileContent -ne 'Go')
            {
              write-host "Please add GO statement at the end of file.No blank row at the bottom - " + $outfile
              exit -1
            }
        }
    }   

##Check DML

    if($IsConsolidated -eq 0){
        $DbScriptSource =  $FolderPath +  '\DML\'
    }
    else{
        $DbScriptSource =  $FolderPath + '\DML\Consolidated\'
    }

    if(!(Test-path $DbScriptSource))
    {
        $FolderPath
        write-host "No sql scripts found under $DbScriptSource"

    }
    else
    {
            foreach ($filename in get-childitem -path $DbScriptSource -filter "*.sql")
            {
                $SQLFile=$filename.fullname
                write-host "SQL File executing - " $SQLFile
                checkCharacter($SQLFile)  
                if($NameCheckRequired -eq '1')
                {
                   $regex = '^[1-3][0-9]{3}_.{1,31}\.sql$'
                   $found = $filename -match $regex
                   #Write-Host "$filename : $found"
                   if($found -eq $false)
                   {
                     throw "$filename have incorrect filename. Please follow the naming convention mentioned in readme file."
                   }  
                }    
            }
     }
    

 ## Validate DML Go statement

    $SQLScriptDMLPath = $FolderPath +  '\DML\*.sql'
    if(Test-Path $SQLScriptDMLPath)
    {
        $SQLFiles = Get-Item -Path $SQLScriptDMLPath
        for ($i=0; $i -lt $SQLFiles.Count; $i++) 
        {
            $outfile = $SQLFiles[$i].FullName
            $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
            write-host $outfile +" - " + $SQLFileContent

            if($SQLFileContent -ne 'GO' -or $SQLFileContent -ne 'Go')
            {
              write-host "Please add GO statement at the end of file.No blank row at the bottom - " + $outfile
              exit -1
            }  
        }
    }