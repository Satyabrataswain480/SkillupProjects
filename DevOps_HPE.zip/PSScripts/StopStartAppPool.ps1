﻿param(
    $Server,
    $AppPoolName,
    $Order
)

function StartStopAppPool($appPoolName, $Order)
{
  Import-Module WebAdministration
   
   if($Order -eq '0')
   {
        if((Get-WebAppPoolState $appPoolName).Value -ne 'Stopped')
        {
            Stop-WebAppPool -Name $appPoolName
        }
   }
   else
   {
       if((Get-WebAppPoolState $appPoolName).Value -eq 'Stopped')
        {
            Start-WebAppPool -Name $appPoolName
        }
   }
}

function KillAppPool($appPoolName)
{
 $process = gwmi -NS 'root\WebAdministration' -class 'WorkerProcess' | select AppPoolName,ProcessId | Where-Object {$_.AppPoolName -eq "$appPoolName"}
 $process
 Write-host 'Process ID: ' $process.ProcessId
 
 if(!([string]::IsNullOrEmpty($process.ProcessId))) {
 Stop-Process -Id $process.ProcessId -Force 
 Write-Host 'Process ID Found and Killed'

 }
 else{
  Write-Host 'No Process ID Found'
  } 
}

$Server
$AppPoolName
Invoke-Command -computername $Server -ScriptBlock ${function:StartStopAppPool} -Args $AppPoolName, $Order

if($Order -eq '0'){
Invoke-Command -computername $Server -ScriptBlock ${function:KillAppPool} -Args $AppPoolName
}
