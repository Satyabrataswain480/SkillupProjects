﻿

Param (

[parameter (Mandatory=$true, position=0, ParameterSetName='Database')]
[string]$SQLServer,
[parameter (Mandatory=$true, position=1, ParameterSetName='Database')]
[string]$DatabaseName,
[parameter (Mandatory=$true, position=2, ParameterSetName='Database')]
[string]$FolderPath,
[parameter (Mandatory=$true, position=3, ParameterSetName='Database')]
[string]$Order

)

$SFlag=0

##########   Execute drop object Stored Proc
if($Order -eq '0')
{
       Write-Host 'SQL Command'
        try
        {
            Write-Host 'Started Executing Drop All Objects Stored Proc'
            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -Query 'exec dropobjects 1,0,1' -QueryTimeout 65500 
             #-ParseOnly -OutputSqlErrors $true failOnStderr: true
            Write-Host 'Completed Executing Drop All Objects Stored Proc' 
        }
         catch [system.data.sqlclient.SQLExeception]
        {
           
          exit -1
        }
}



###########  Execute SQL scripts from the Folder Path ##################
if($Order -eq '1')
{

    # Check if folder not available
    if(!(Test-Path $FolderPath))
    {
        return
    }

    #Loop through the .sql files and run them
    if( (Get-ChildItem $FolderPath  |Measure-Object).Count -eq 0)
    {
            write-host "No DDL/DML Folders/Files found"
    }
    else
    {
        foreach ($filename in get-childitem -path $FolderPath -filter "*.sql")
        {
            try
            {
                Write-Host 'Started Executing DDL/DML SQL Scripts'
                invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -InputFile $filename.fullname -QueryTimeout 65500 
               # -ParseOnly -OutputSqlErrors $true failOnStderr: true
                #Print file name which is executed
                write-host $filename.fullname
                Write-Host 'Completed Executing DDL/DML SQL Scripts'
            }
            catch 
            {                
                throw $_.Exception.Message               
            }
       
        }
    }
}


###########   Execute Constrains and Release script ################
if($Order -eq '2')
{

        $ReleaseFile = $FolderPath + '\Core.Project.ReleaseScripts.sql'
        try
        {
            Write-Host 'Started Executing Core.Project.ReleaseScripts'
            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -InputFile $ReleaseFile -QueryTimeout 65500 
            # -ParseOnly -OutputSqlErrors $true failOnStderr: true
            Write-Host 'Completed Executing Core.Project.ReleaseScripts'
        }
        catch [system.data.sqlclient.SQLExeception]
        {
           
           exit -1
        }

        $ConstFile =  $FolderPath + '\Core.Project.Constraints.sql'   
        try
        {
            Write-Host 'Started Executing Core.Project.Constraints'
            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -InputFile $ConstFile -QueryTimeout 65500 
            #-ParseOnly -OutputSqlErrors $true failOnStderr: true
            Write-Host 'Completed Executing Core.Project.Constraints'
        }
        catch [system.data.sqlclient.SQLExeception]
        {
          
           exit -1
        } 

}
if($Order -eq '3')
{
		$ConstFile =  $FolderPath + '\Core.Project.Constraints.sql'   
       
      
            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -InputFile $ConstFile -QueryTimeout 65500 
            #-ParseOnly -OutputSqlErrors $true failOnStderr: true
            #Print file name which is executed
            $filename 

        $ReleaseFile = $FolderPath + '\Core.Project.ReleaseScripts.sql'

      
            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -InputFile $ReleaseFile -QueryTimeout 65500 
            #-ParseOnly -OutputSqlErrors $true   failOnStderr: true
            #Print file name which is executed
            $filename  
     
}

##########  New folder structure  DDL\DML

if($Order -eq '4')
{

# Check if folder not available
if(!(Test-Path $FolderPath))
{
   return
}

  ##Validate Go Statement in SQL Scripts
    write-host "Starting to validate GO statement..."
    $SQLScriptPathDDL = $FolderPath + '\DDL\*.sql'
    write-host $SQLScriptPathDDL
    if(Test-Path $SQLScriptPathDDL)
    {
        $SQLFiles = Get-Item -Path $SQLScriptPathDDL
    }

   # for ($i=0; $i -lt $SQLFiles.Count; $i++) 
   # {
   #     $outfile = $SQLFiles[$i].FullName
   #     $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
   #     write-host 'Printing last line of file -' $outfile +" - " + $SQLFileContent
#
 #       if($SQLFileContent.contains('GO') -or $SQLFileContent.Contains('Go'))
  #      {
   #       write-host "Please add GO statement at the end of file.No blank row at the bottom - " + $outfile
   #       exit -1
   #     }
   # }

#DDL Execution
$DDLPath =  $FolderPath + '\DDL\'

    # Check if folder not available
    if((Test-Path $DDLPath))
    {
        if( (Get-ChildItem $DDLPath  |Measure-Object).Count -eq 0)
        {
                write-host "No DDL Files Found"
        }
        else
        {
            foreach ($filename in get-childitem -path $DDLPath -filter "*.sql")
            {
                try
                {
                    Write-Host 'Started Executing DDL SQL Scripts'
					write-host $filename.fullname
                    invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -InputFile $filename.fullname -QueryTimeout 65500
                    
                    Write-Host 'Completed Executing DDL SQL Scripts'
                }
                catch
                {
                    Write-Host "Syntax Error: $_" -ForegroundColor Red
                   exit -1
                }       
            }
        }
    }
    else
    {
        write-host "No DDL Files Found"
    }

$DMLPath =   $FolderPath + '\DML\'

    ##Validate Go Statement in SQL Scripts
    write-host "Startging to validate GO statement..."
    $SQLScriptPathDML = $FolderPath + '\DML\*.sql'
    write-host $SQLScriptPathDML
   # if((Test-Path $SQLScriptPathDML))
   # {
        #$SQLFiles = Get-Item -Path $SQLScriptPathDML

       # for ($i=0; $i -lt $SQLFiles.Count; $i++) 
       # {
       #     $outfile = $SQLFiles[$i].FullName
       #    $SQLFileContent= Get-Content $SQLFiles[$i].FullName -Tail 1 
       #     write-host 'Printing last line of file -' $outfile +" - " + $SQLFileContent

       #     if($SQLFileContent -ne 'GO' -or $SQLFileContent -ne 'Go')
       #     {
       #       write-host "Please add GO statement at the end of file.No blank row at the bottom - " + $outfile
       #       exit -1
       #     }
       # }
   # }
    
    if((Test-Path $DMLPath))
    {
        if( (Get-ChildItem $DMLPath  |Measure-Object).Count -eq 0)
        {
                write-host "No DML Files found"
        }
        else
        {
            foreach ($filename in get-childitem -path $DMLPath -filter "*.sql")
            {
                try
                {
                    Write-Host 'Started Executing DML SQL Scripts'
					write-host $filename.fullname
                    invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -InputFile $filename.fullname -QueryTimeout 65500 
                    
                    Write-Host 'Completed Executing DML SQL Scripts'
                }
                catch 
                {
                    Write-Host "Syntax Error: $_" -ForegroundColor Red
                   exit -1
                }
       
             }
        }
    }
    else
    {
        write-host "No DML Files Found"
    }
}

##########   Sync Development User in SQL Server 
if($Order -eq '5')
{
        try
        {
            Write-Host 'Started Executing Sync DB Users'

            $SyncUser = "EXEC sp_change_users_login 'Auto_Fix', 'Development'"
            $GrantPermission = "GRANT CONNECT,EXECUTE,VIEW DEFINITION,REFERENCES TO " + "Development"

            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -Query $SyncUser -QueryTimeout 65500
            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -Query $GrantPermission -QueryTimeout 65500
            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -Query "EXEC sp_addrolemember 'db_datareader', 'Development'" -QueryTimeout 65500
            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -Query "EXEC sp_addrolemember 'db_datawriter', 'Development'" -QueryTimeout 65500
            invoke-sqlcmd –ServerInstance $SQLServer -Database $DatabaseName -Query "EXEC sp_addrolemember 'db_ddladmin', 'Development'" -QueryTimeout 65500
            
            Write-Host 'Completed Executing Sync DB Users' 
        }
        catch [system.data.sqlclient.SQLExeception]
        {           
          exit -1
        }
}

################################################


