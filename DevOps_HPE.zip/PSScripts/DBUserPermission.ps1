﻿param (
    [parameter(Mandatory=$true, position=1, ParameterSetName='db')]
    [string]$dbname,
    [parameter(Mandatory=$true, position=2, ParameterSetName='db')]
    [string]$dbserver,
    [parameter(Mandatory=$true, position=3, ParameterSetName='db')]
    [string]$dbusername
)

# Check if dbname contains "PP"
if ($dbname -like "*PP*") {
    # Additional SQL commands or logic for databases containing "PP"
    $UserPermission = @"
    USE $dbname;

    --Password is updated to a
    Update Users
    set LoginName = 'security.admin', Password = '4d4586c564d0f8aaccdee194051e27a72a007d3e49ad93d8604f4ff2f223c97e',
    Email = 'Rajadeepan.S@odessainc.com',
    ApprovalStatus = 'Approved'
    where Id = 2
    GO
 
    --Change password for PartnerPortal Integration user
    --PartnerPortal Integration,Password@123
 
    update APIGatewayConfigs 
    set BaseUrl = 'http://hpemvpstg.webapi.gec1.odessadev.local/api/component',
    AuthenticationType = 'Basic',
    UserName_CT = 0xBB79A8B71B6C0102550557BADB3283559E645E12BC2DD3D09D80BB2026BC6BF6B7C5BEC5DD7B162549AEB6072A80ADF9,
    Password_CT = 0x62E93B43304F8FB3D7D37067314DAE964E4F93903280FE6FB90C5DB28212E899
    GO

    IF EXISTS(SELECT * FROM sys.database_principals WHERE NAME='OdessaCore_PP')  
    BEGIN
    DROP USER [OdessaCore_PP]
    END
    GO

    IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME='OdessaCore_PP')  
    BEGIN 
    CREATE USER [OdessaCore_PP] FOR LOGIN [OdessaCore_PP] WITH DEFAULT_SCHEMA=[dbo]
    GRANT CONNECT,EXECUTE,UnMask TO [OdessaCore_PP]  
    ALTER ROLE [db_datareader] ADD MEMBER [OdessaCore_PP] 
    ALTER ROLE [db_datawriter] ADD MEMBER [OdessaCore_PP] 
    ALTER ROLE [db_ddladmin] ADD MEMBER [OdessaCore_PP]
    END
    GO

    --Synonym Script to connect with core
    Exec InitializeSynonyms 'HPEFS_PRD', 'LessorPortal'
    GO

    IF EXISTS(SELECT * FROM sys.database_principals WHERE NAME='OdessaCore')  
    BEGIN
    DROP USER [OdessaCore]
    END
    GO

    IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME='OdessaCore')  
    BEGIN 
    CREATE USER [OdessaCore] FOR LOGIN [OdessaCore] WITH DEFAULT_SCHEMA=[dbo]
    GRANT CONNECT,EXECUTE,UnMask TO [OdessaCore]  
    ALTER ROLE [db_datareader] ADD MEMBER [OdessaCore] 
    ALTER ROLE [db_datawriter] ADD MEMBER [OdessaCore] 
    ALTER ROLE [db_ddladmin] ADD MEMBER [OdessaCore]
    END
    GO
"@
} else {
    $UserPermission = @"
    USE $dbname;

    -- Regular logic for other databases
    IF EXISTS(SELECT 1 FROM SystemConfigFiles WHERE IsActive = 1)
    BEGIN
        UPDATE SystemConfigFiles 
        SET IsActive = 0, UpdatedById = 1, UpdatedTime = SYSDATETIMEOFFSET() 
        WHERE IsActive = 1;
    END;

    IF EXISTS(SELECT 1 FROM Users WHERE LoginName = 'Security.Admin' AND ApprovalStatus = 'Inactive')
    BEGIN
        UPDATE Users 
        SET ApprovalStatus = 'Approved', UpdatedById = 1, UpdatedTime = SYSDATETIMEOFFSET() 
        WHERE LoginName = 'Security.Admin' AND ApprovalStatus = 'Inactive';
    END;

    IF EXISTS(SELECT * FROM sys.database_principals WHERE NAME = 'OdessaCore')  
    BEGIN 
        DROP USER [OdessaCore]; 
    END;

    IF EXISTS(SELECT * FROM sys.database_principals WHERE NAME = 'OdessaCore_PP')  
    BEGIN 
        DROP USER [OdessaCore_PP]; 
    END;

    IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME = 'OdessaCore')  
    BEGIN 
        CREATE USER [OdessaCore] FOR LOGIN [OdessaCore] WITH DEFAULT_SCHEMA=[dbo];
        GRANT CONNECT, EXECUTE, UNMASK TO [OdessaCore];  
        ALTER ROLE [db_datareader] ADD MEMBER [OdessaCore];  
        ALTER ROLE [db_datawriter] ADD MEMBER [OdessaCore];
        ALTER ROLE [db_ddladmin] ADD MEMBER [OdessaCore];
    END;

    IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME = 'OdessaCore_PP')  
    BEGIN 
        CREATE USER [OdessaCore_PP] FOR LOGIN [OdessaCore_PP] WITH DEFAULT_SCHEMA=[dbo];
        GRANT CONNECT, EXECUTE, UNMASK TO [OdessaCore_PP];  
        ALTER ROLE [db_datareader] ADD MEMBER [OdessaCore_PP]; 
        ALTER ROLE [db_datawriter] ADD MEMBER [OdessaCore_PP]; 
        ALTER ROLE [db_ddladmin] ADD MEMBER [OdessaCore_PP];
    END;

    EXEC CreateSynonymForJobs 1;
    EXEC CreateExtractTables;
    EXEC [dbo].[AlterUserAssignPermissions] @dbUserName = N'$dbusername';

    DECLARE @DatabaseName SYSNAME = DB_NAME();
    DECLARE @LoginName NVARCHAR(1000) = N'$dbusername';
    EXEC CreateSQLJobToCreateExtractTable @DatabaseName, @LoginName;
"@
}

# Execute the SQL commands
Invoke-Sqlcmd -ServerInstance $dbserver -Database 'master' -Query $UserPermission -QueryTimeout 65500 -ErrorAction Continue