param(
[string]$jobServer,
[int]$jobServiceCount,
[string]$jobName,
[int]$stop = '1'
)

function StartStopService {
    param(
        [string]$serviceName,
        [string]$jobServer,
        [int]$startStop
    )
    
    try {
        $Service = Get-WmiObject -ComputerName $jobServer -Class Win32_Service -Filter "Name='$serviceName'"
        if ($null -eq $Service) {
            Write-Host "Service $serviceName not found on server $jobServer." -ForegroundColor Red
            return
        }
    } catch {
        Write-Host "Failed to get service $serviceName on server $jobServer. Error: $_" -ForegroundColor Red
        return
    }
    
    Write-Host "Service $serviceName found on server $jobServer with state: $($Service.State)" -ForegroundColor Yellow
    
    if ($startStop -eq 1 -and $Service.State -ne 'Started') {
        Write-Host "Starting service $serviceName..."
        try {
            Invoke-Command -ComputerName $jobServer -ScriptBlock { param($serviceName) Start-Service -Name $serviceName } -ArgumentList $serviceName
            Write-Host "Service named $serviceName started" -ForegroundColor Green
        } catch {
            Write-Host "Failed to start service $serviceName. Error: $_" -ForegroundColor Red
        }
    } elseif ($startStop -eq 0 -and $Service.State -ne 'Stopped') {
        Write-Host "Stopping service $serviceName..."
        try {
            Invoke-Command -ComputerName $jobServer -ScriptBlock { param($serviceName) Stop-Service -Name $serviceName -Force } -ArgumentList $serviceName
            Write-Host "Service named $serviceName stopped" -ForegroundColor Green
        } catch {
            Write-Host "Failed to stop service $serviceName. Error: $_" -ForegroundColor Red
        }
    } else {
        Write-Host "Service named $serviceName already in the expected state."
    }
}

function KillService {
    param(
        [string]$serviceName
    )
    
    # Retrieve the process ID for the specific service
    $processId = (Get-WmiObject -Class Win32_Service -Filter "Name='$serviceName'" | Select-Object -ExpandProperty ProcessId)
    
    Write-Host "Process ID: $processId"
    
    # Check if a valid process ID was retrieved
    if (![string]::IsNullOrEmpty($processId) -and $processId -ne 0) {
        try {
            # Attempt to terminate the process
            Stop-Process -Id $processId -Force
            Write-Output "Process with PID $processId has been terminated."
        } catch {
            Write-Error "Failed to terminate process with PID $processId. Error: $_"
        }
    } else {
        Write-Output "No running process found for service '$serviceName'."
    }
}

for ($i = 0; $i -lt $jobServiceCount; $i++) {
    $j = $i + 1
    $name = if ($i -eq 0) { $jobName } else { "$jobName$j" }
    if ($jobServer -eq 'default') {
        Write-Host "Job server is set to default. Exiting."
        return
    }
    StartStopService -serviceName $name -jobServer $jobServer -startStop $stop
    
    if ($stop -eq 0) {
        Invoke-Command -ComputerName $jobServer -ScriptBlock ${function:KillService} -ArgumentList $name
    }
}
